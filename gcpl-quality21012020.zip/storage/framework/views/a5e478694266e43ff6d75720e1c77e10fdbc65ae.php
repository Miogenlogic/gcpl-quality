
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="QMS Dashboard">
    <meta name="author" content="rK">
    <title>Branch Office | QMS Dashboard - Gainwell</title>
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(URL::asset('public/assets/img/brand/favicon.png?v=1.1.0')); ?>">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900&display=swap" rel="stylesheet">
    <!-- Icons -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/assets/vendor/nucleo/css/nucleo.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>">
    <!-- Page plugins -->

    <link rel="stylesheet" href="<?php echo e(URL::asset('public/assets/vendor/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/assets/vendor/quill/dist/quill.core.css')); ?>">
    <!-- Argon CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/assets/css/main-style.css?v=1.1.0')); ?>">


    <?php echo $__env->yieldContent('after_styles'); ?>
</head>


<body>
    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content" id="panel">

        <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="header bg-primary pb-6">
            <?php echo $__env->yieldContent('head'); ?>

        </div>

        <div class="container-fluid mt--6">
            <?php echo $__env->yieldContent('body'); ?>

            <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <!-- Argon Scripts -->
    <!-- Core -->
    <script src="<?php echo e(URL::asset('public/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
    <!-- Optional JS -->
    <script src="<?php echo e(URL::asset('public/assets/vendor/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
    <!-- Argon JS -->
    <script src="<?php echo e(URL::asset('public/assets/js/main.js?v=1.1.0')); ?>"></script>
    <!-- Demo JS - remove this in your project -->
    <script src="<?php echo e(URL::asset('public/assets/js/demo.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('after_script'); ?>

</body>

</html>


<?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/include/layout.blade.php ENDPATH**/ ?>