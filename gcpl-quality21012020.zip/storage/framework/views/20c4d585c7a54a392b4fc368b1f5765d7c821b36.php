<!-- Project List -->


<?php $__env->startSection('head'); ?>

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Create new service request</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/branch-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service requeust</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="<?php echo e(url('admin/service-request-add-save')); ?>" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Service Request Number</label>
                            <input type="text" name="service_request_no" class="form-control" id="service" value="" readonly>
                            <?php if($errors->has('service_request_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('service_request_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
					
					
					
					<div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Description</label>
							<textarea name="description" class="form-control" id="service" value=""></textarea>
                     </div>
                    </div>
					
					
					
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Employee Responsibly</label>
                            <select name="empres" id="empres" class="form-control">
                                
                               <option selected="selected">
							  
                                  <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option selected="" value="<?php echo e($emp->id); ?>">
                                        <?php echo e($emp->name); ?>

										</option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </option>
                          </select>

                        </div>
                    </div>
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Status</label>
                           <select name="cc_status" id="cc_status" class="form-control">
                                <option selected="selected">
                               
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option selected="" value="<?php echo e($stat->id); ?>">
                                        <?php echo e($stat->status); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </option>
                          </select>

                        </div>
                    </div>
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Impact/Urgency</label>
                            <input type="text" name="impact" class="form-control" id="service" value="" >

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="customer">Select customer</label>
                            <select name="customer" class="form-control">
                                <option selected="selected" disabled="disabled">--Select customer--</option>
                                <?php
                                    $customer=App\Helpers\UserHelper::customer();
                                ?>

                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($cus->name); ?>"><?php echo e($cus->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('customer')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('customer')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="job">Job number</label>
                            <input type="text" name="job_no" class="form-control" id="" placeholder="">
                            <?php if($errors->has('job_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('job_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">AR number</label>
                            <input type="text" name="ar_no" class="form-control" id="" placeholder="AR number" value="">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Model number</label>
                            <select name="machine_modelno" id="machmodel" class="form-control">
                                <option selected="selected" disabled="disabled">--Select model number--</option>

                                <?php
                                    $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                ?>

                                <?php $__currentLoopData = $mchmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($cmodel->id); ?>"><?php echo e($cmodel->model_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                            <?php if($errors->has('model_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('model_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label machserial" for="model">Machine Serial number</label>
                            <select name="machine_serialno" id="machserial" class="form-control">


                            </select>

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compmodel" for="model">Component Model number</label>
                            <select name="comp_model_no" id="compmodel" class="form-control">


                            </select>

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Component Serial Number</label>
                            <select name="component_serial_no" id="compserial" class="form-control">

                            </select>

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compname" for="Component">Component name</label>
                            <select name="component_name" id="compname" class="form-control">
                                <option selected="selected" disabled="disabled">--Select component--</option>
                                <?php
                                    $comptype=App\Helpers\UserHelper::componenttype();
                                ?>

                                <?php $__currentLoopData = $comptype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($ctype->type); ?>"><?php echo e($ctype->type); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('component_name')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('component_name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Branch Name</label>
                            <select name="branch_name" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Branch name--</option>

                                <?php
                                    $branchnme=App\Helpers\UserHelper::branchname();
                                ?>

                                <?php $__currentLoopData = $branchnme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($bname->sales_ofc); ?>"><?php echo e($bname->sales_ofc); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('branch_name')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('branch_name')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Segment</label>
                            <select name="segment" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Segment--</option>

                                <?php
                                    $segment=App\Helpers\UserHelper::segment();
                                ?>

                                <?php $__currentLoopData = $segment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($seg->name); ?>"><?php echo e($seg->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                            <?php if($errors->has('segment')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('segment')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Branch Location</label>
                            <input type="text" name="branch_location" class="form-control" id="" placeholder="Branch Location" value="">
                            <?php if($errors->has('branch_location')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('branch_location')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Work order no</label>
                            <input type="text" name="work_orderno" class="form-control" id="service" value="" >

                        </div>
                    </div>
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="servicedate" class="form-control-label">Service Request Date</label>

                            <input class="form-control" name="date" type="date" value="" id="servicedate">
                        </div>
                        
                    </div>
                  <div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Recomendation</label>
							<textarea name="recom" class="form-control" id="service" value=""></textarea>
                         

                        </div>
                    </div>
                    

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload pre-history</label>
                            <div class="custom-file">
                                <input type="file" name="import_file" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                        </div>
                    </div>


                </div><!-- /row -->
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button class="btn btn-primary" type="submit">Save</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="<?php echo e(url('admin/service-request-list')); ?>"'>Cancel</button>
            </form>
            <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="<?php echo e(URL::asset('public/assets/download/sampleexcel.xlsx')); ?>">Sample excel File</a></div>
        </div>

    </div>
    <!-- Project List -->




<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_script'); ?>

    <!-- Optional JS -->
    
    <script src="<?php echo e(URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/machine-serial-list-show")); ?>',

                type: 'POST',

                data: {model:model,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/component-model-list-show")); ?>',

                type: 'POST',

                data: {commodel:commodel,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/component-serial-list-show")); ?>',

                type: 'POST',

                data: {coserial:coserial,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/branchengineer/newserviceRequest.blade.php ENDPATH**/ ?>