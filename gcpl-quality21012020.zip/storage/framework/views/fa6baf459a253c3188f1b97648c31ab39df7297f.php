<!-- Project List -->


<?php $__env->startSection('head'); ?>

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Upload Quotation</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/super-admin-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New Component Name</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="<?php echo e(url('admin/support-quotation-add-save')); ?>" enctype="multipart/form-data">



                <div class="row">

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="question">Quotation Upload</label>
                            <input type="file" class="form-control" id="" placeholder="" name="quotation">
                            <?php if($errors->has('quotation')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('quotation')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>



                <!-- /row -->
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
                <button class="btn btn-primary" type="submit">Submit</button>
                <button class="btn btn-warning" type="cancel">Cancel</button>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_script'); ?>

    <!-- Optional JS -->
    <script src="<?php echo e(URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/support/addQuotation.blade.php ENDPATH**/ ?>