<?php $__env->startSection('head'); ?>

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0"> Edit service request</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/branch-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service request</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php
//print_r($servicerequest);
//die;
?>

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="<?php echo e(url('/admin/update-servicerequest')); ?>" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Service Request Number</label>
                            <input type="text" name="service_request_no" class="form-control" id="service" value="<?php echo e(old('service_request_no')?old('service_request_no'):$servicerequest->service_request_no); ?>" readonly>
                            <?php if($errors->has('service_request_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('service_request_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
					<div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Description</label>
                           <input type="text" name="description" class="form-control" id="service" value="<?php echo e(old('description')?old('description'):$servicerequest->description); ?>">
							
                            <?php if($errors->has('description')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('description')); ?></div>
                            <?php endif; ?>
							
                        </div>
                    </div>
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Employee Responsible</label>
                            <select name="empres" id="empres" class="form-control">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option selected="selected" value="<?php echo e(old('empres')?old('empres'):$servicerequest->empres); ?>">

                                    
                                    <?php echo e($emp->name); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                                
                        </div>
                    </div>
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Status</label>
                            <select name="cc_status" id="cc_status" class="form-control">
							<?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option selected="selected" value="<?php echo e(old('cc_status')?old('cc_status'):$servicerequest->cc_status); ?>">

                                    
                                    <?php echo e($stat->status); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                                
                        </div>
                    </div>
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Impact</label>
                            <input type="text" name="impact" class="form-control" id="service" value="<?php echo e(old('impact')?old('impact'):$servicerequest->impact); ?>" >
                            <?php if($errors->has('impact')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('impact')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Customer Name</label>

                            <input type="text" name="customer" class="form-control" id="service" value="<?php echo e(old('customer')?old('customer'):$servicerequest->customer); ?>">
                            <?php if($errors->has('customer')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('customer')); ?></div>
                            <?php endif; ?>



                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Job No</label>
                            <input type="text" name="job_no" class="form-control" id="service" value="<?php echo e(old('job_no')?old('job_no'):$servicerequest->job_no); ?>" >
                            <?php if($errors->has('job_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('job_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Ar No</label>
                            <input type="text" name="ar_no" class="form-control" id="service" value="<?php echo e(old('ar_no')?old('ar_no'):$servicerequest->ar_no); ?>" >
                            <?php if($errors->has('ar_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('ar_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Model number</label>
                            <select name="machine_modelno" id="machmodel" class="form-control">
                                

                                    <?php $__currentLoopData = $machinemodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option selected="selected" value="<?php echo e($mod->id); ?>" >
                                        <?php echo e($mod->model_no); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               
                                <?php
                                    $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                ?>

                                <?php $__currentLoopData = $mchmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($cmodel->id); ?>"><?php echo e($cmodel->model_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php if($errors->has('model_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('model_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Serial number</label>
                            <select name="machine_serialno" id="compserial" class="form-control">
							<?php $__currentLoopData = $machserial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $macserial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option selected="selected" value="<?php echo e($macserial->id); ?>">

                                    
                                    <?php echo e($macserial->serial_no); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </option>
                                <?php
                                    $mchserial=App\Helpers\UserHelper::mastermachineserialno();
                                ?>

                                <?php $__currentLoopData = $mchserial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mserial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option selected="selected" value="<?php echo e($mserial->id); ?>"><?php echo e($mserial->serial_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php if($errors->has('serial_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('serial_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Component Model number</label>
                            <select name="comp_model_no" id="compmodel" class="form-control">
                                <option selected="selected">

                                    <?php $__currentLoopData = $compmodelno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compmodno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option selected="selected" value="<?php echo e($compmodno->id); ?>">
                                        <?php echo e($compmodno->model_no); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </option>
                                <?php
                                     $compmodel=App\Helpers\UserHelper::componentmodelno();
                                ?>

                                <?php $__currentLoopData = $compmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($cmodel->id); ?>"><?php echo e($cmodel->model_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php if($errors->has('model_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('model_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Component Serial number</label>
                            <select name="component_serial_no" id="compserial" class="form-control">
                                <option selected="selected" >

                                    <?php $__currentLoopData = $compserialno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coserial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option selected="selected" value=<?php echo e("$coserial->id"); ?>>
                                        <?php echo e($coserial->serial_no); ?>

										</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </option>
                                <?php
                                   $compserial =App\Helpers\UserHelper::componentserialno();
                                ?>

                                <?php $__currentLoopData = $compserial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comserial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($comserial->id); ?>"><?php echo e($comserial->serial_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php if($errors->has('serial_no')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('serial_no')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Component Name</label>
                            <select name="component_name" id="compname" class="form-control"  >
                                <option selected="selected" id="service" >
                                    <?php echo e(old('component_name')?old('component_name'):$servicerequest->component_name); ?>

                                    </option>
                            <?php if($errors->has('component_name')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('component_name')); ?></div>
                            <?php endif; ?>
                            <?php
                                $comptype=App\Helpers\UserHelper::componenttype();
                            ?>

                            <?php $__currentLoopData = $comptype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($ctype->type); ?>"><?php echo e($ctype->type); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Branch Name</label>
                            <select name="branch_name" id="branch_name" class="form-control"  >
                                <option>
                             <?php echo e(old('branch_name')?old('branch_name'):$servicerequest->branch_name); ?>

                                    </option>
                                <?php if($errors->has('branch_name')): ?>
                                    <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('branch_name')); ?></div>
                                <?php endif; ?>

                                <?php
                                    $branch=App\Helpers\UserHelper:: branchname();
                                ?>


                                <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($bran->sales_ofc); ?>"><?php echo e($bran->sales_ofc); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Segment</label>
                            <select name="segment" id="segment" class="form-control"  >
                                <option selected="selected" id="service" >
                             <?php echo e(old('segment')?old('segment'):$servicerequest->segment); ?>

                                 </option>
                            <?php if($errors->has('segment')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('segment')); ?></div>
                            <?php endif; ?>

                            <?php
                                $segment=App\Helpers\UserHelper::segment();
                            ?>


                            <?php $__currentLoopData = $segment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($seg->name); ?>"><?php echo e($seg->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                    </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Branch location</label>
                            <input type="text" name="branch_location" class="form-control" id="service" value="<?php echo e(old('branch_location')?old('branch_location'):$servicerequest->branch_location); ?>" >
                            <?php if($errors->has('branch_location')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('branch_location')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Work order no</label>
                            <input type="text" name="work_orderno" class="form-control" id="service" value="" >

                        </div>
                    </div>
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">date</label>
                            <input type="text" name="date" class="form-control" id="service" value="<?php echo e(old('date')?old('date'):$servicerequest->date); ?>" >
                            <?php if($errors->has('date')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('date')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
              <div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Recomendation</label>
                            <input type="text" name="recom" class="form-control" id="recom" value="<?php echo e(old('recom')?old('recom'):$servicerequest->recom); ?>">
                            <?php if($errors->has('recom')): ?>
                                <div class="invalid-feedback" style="display:block;"><?php echo e($errors->first('recom')); ?></div>
                            <?php endif; ?>
							
                        </div>
                    </div>

                   

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload pre-history</label>
                            <div class="custom-file">
                                <input type="file" name="import_file" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                        </div>
                    </div>

                    <!--<div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload PO</label>
                            <div class="custom-file">
                                <input type="file" name="po_upload" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                            <h6>upload pdf file</h6>
                        </div>
                    </div>-->


                </div><!-- /row -->
                <input type="hidden" name="id" value="<?php echo e($servicerequest->id); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button class="btn btn-primary" type="submit">Edit</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="<?php echo e(url('admin/service-request-list')); ?>"'>Cancel</button>
            </form>
            <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="<?php echo e(URL::asset('public/assets/download/sampleexcel.xlsx')); ?>">Sample excel File</a></div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_script'); ?>

    <!-- Optional JS -->
    
    <script src="<?php echo e(URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/machine-serial-list-show")); ?>',

                type: 'POST',

                data: {model:model,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/component-model-list-show")); ?>',

                type: 'POST',

                data: {commodel:commodel,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '<?php echo e(url("/admin/component-serial-list-show")); ?>',

                type: 'POST',

                data: {coserial:coserial,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });

    </script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/branchengineer/servicerequestlisting.blade.php ENDPATH**/ ?>