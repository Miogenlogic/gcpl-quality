<nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header d-flex align-items-center">
            <a class="navbar-brand" href="<?php echo e(url('admin/admin-dashboard')); ?>">
                <img src="<?php echo e(URL::asset('public/assets/img/brand/blue.png')); ?>" class="navbar-brand-img" alt="Logo">
            </a>
            <div class="ml-auto">
                <!-- Sidenav toggler -->
                <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
                    <div class="sidenav-toggler-inner">
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                    </div>
                </div>
            </div>
        </div>
        <ul class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((Request::is('*/admin/*dashboard*')) ?'active':''); ?>" href="

                            <?php if(request()->session()->get('user')['section_id'] == '20'): ?> <?php echo e(url('admin/super-admin-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '1'): ?>  <?php echo e(url('admin/branch-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '2'): ?>  <?php echo e(url('admin/support-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '3'): ?>  <?php echo e(url('admin/receiving-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '4'): ?>  <?php echo e(url('admin/engine-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '5'): ?>  <?php echo e(url('admin/trans-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '13'): ?>  <?php echo e(url('admin/hyd-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '6'): ?>  <?php echo e(url('admin/mor-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '7'): ?>  <?php echo e(url('admin/undercarg-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '8'): ?>  <?php echo e(url('admin/spc-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '9'): ?>  <?php echo e(url('admin/store-manager-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '10'): ?>  <?php echo e(url('admin/engine-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '11'): ?>  <?php echo e(url('admin/trans-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '12'): ?>  <?php echo e(url('admin/hyd-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '14'): ?>  <?php echo e(url('admin/mor-dashboard')); ?> <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '15'): ?>  <?php echo e(url('admin/undercarg-dashboard')); ?> <?php endif; ?>

                                <?php if(auth()->check() && auth()->user()->hasRole('crc_head')): ?>  <?php echo e(url('admin/crc-head-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('section_supervisor')): ?>  <?php echo e(url('admin/section-supervisor-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('section_engineer')): ?>  <?php echo e(url('admin/section-engineer-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('qa_qc')): ?> <?php echo e(url('admin/qaqc-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('planning_supervisor')): ?>  <?php echo e(url('admin/planning-supervisor-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('store_manager')): ?> <?php echo e(url('admin/store-manager-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('despatch_manager')): ?>  <?php echo e(url('admin/despatch-manager-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('service_engineer')): ?>  <?php echo e(url('admin/service-engineer-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('dept_eng')): ?>  <?php echo e(url('admin/engine-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('dept_trans')): ?>  <?php echo e(url('admin/trans-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('eng_head')): ?>  <?php echo e(url('admin/eng-head-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('dept_mor')): ?>  <?php echo e(url('admin/mor-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('dept_hyd')): ?>  <?php echo e(url('admin/hyd-dashboard')); ?> <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('dept_undercarriage')): ?>  <?php echo e(url('admin/undercarg-dashboard')); ?> <?php endif; ?>


                            ">
                            <i class="ni ni-shop text-primary"></i>
                            <span class="nav-link-text">Dashboards</span>
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e((Request::is('admin/service-request')) ?'active':''); ?>" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="<?php echo e((Request::is('admin/service-request*')) ?'true':'false'); ?>"
                           aria-controls="navbar-examples">
                            <i class="ni ni-briefcase-24 text-orange"></i>
                            <span class="nav-link-text">Menu</span>
                        </a>

                        <!-- Menu structure -->
                        <div class="collapse <?php echo e((Request::is('admin/service-request*')) ?'show':''); ?>" id="navbar-examples">
                            <!--- THIS IS FOR BRANCH -->
                            <ul class="nav nav-sm flex-column">
                                <?php if(request()->session()->get('user')['section_id'] == '1'): ?>

                                    <?php if(request()->session()->get('user')['role_id'] == '1'): ?>
                                        
                                        
                                        
                                    <?php endif; ?>

                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/service-request-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Service Request</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/support-quotation-list'))  )?'active':''); ?>">Download Quatation & view Quatation</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/spc-dashboard')); ?>" class="nav-link <?php echo e(url('admin/showchecksheet')); ?>" class="nav-link <?php echo e(((Request::is('admin/showchecksheet'))  )?'active':''); ?>">Upload PO</a>
                                    </li>

                                <?php endif; ?>
                            </ul>
                            <!--- END OF BRANCH MENU -->

                            <!--- THIS IS FOR SUPPORT -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '2'): ?><!--all-->

                            <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--engineer-->
                                <li class="nav-item">
                                    <a href="<?php echo e(url('admin/service-request-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Service request</a>
                                </li>
                                <?php endif; ?>
                                
                                
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">SPC Upload Quotation</a>
                                </li>

                                <?php endif; ?>
                            </ul>
                            <!--- END OF SUPPORT MENU -->

                            <!--- THIS IS FOR RECEIVING -->
                            <ul class="nav nav-sm flex-column">
                                <?php if(request()->session()->get('user')['section_id'] == '3'): ?>

                                    <?php if(request()->session()->get('user')['role_id'] == '1'): ?>
                                        <li class="nav-item">
                                            <a href="<?php echo e(url('admin/servicedashboard-checkgateone')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Create Check Gate One</a>
                                        </li>
                                    <?php endif; ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/check-gate-form-one-listing/{id}')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate One</a>
                                    </li>

                                <?php endif; ?>
                            </ul>
                            <!--- END OF RECEIVING MENU -->

                            <!--- THIS IS FOR ENG. DISASSEMBLY -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '4'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Create / Update Quotation in SAP</a>
                                    </li>
                                <?php endif; ?>

                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!-- Head -->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Disassembly Checklist</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF ENG. DISASSEMBLY MENU -->

                            <!--- THIS IS FOR TRAN. DISASSEMBLY -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '5'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgateone')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Create / Update Quotation in SAP</a>
                                    </li>
                                <?php endif; ?>

                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!-- Head -->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Disassembly Checklist</a>
                                    </li>
                                <?php endif; ?>
                                <!-- NOT Confirmed YET-->

                                <?php endif; ?>
                            </ul>
                            <!--- END OF TRAN. DISASSEMBLY MENU -->

                            <!--- THIS IS FOR HYD. COMP. DISASSEMBLY -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '13'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Download Checklist in Excel</a>
                                    </li>
                                
                                
                                
                                <?php endif; ?>

                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!-- Head -->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Disassembly Checklist</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF HYD. COMP. DISASSEMBLY MENU -->

                            <!--- THIS IS FOR MOR(DISASSEMBLY) -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '6'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Create / Update Quotation in SAP</a>
                                    </li>
                                <?php endif; ?>

                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!-- Head -->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Disassembly Checklist</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF MOR MENU -->

                            <!--- THIS IS FOR UNDERCARRIGE(DISASSEMBLY) -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '7'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgateone')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/support-quotation-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Create / Update Quotation in SAP</a>
                                    </li>
                                <?php endif; ?>

                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!-- Head -->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/servicedashboard-checkgatetwo')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Disassembly Checklist</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF UNDERCARRIGE MENU -->

                            <!--- THIS IS FOR SPC -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '20'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '3'): ?><!--Engineer-->
                                    
                                    
                                    
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/projects-open-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Project Plan</a>
                                    </li>
                                    <?php endif; ?>

                                <?php endif; ?>
                            </ul>
                            <!--- END OF SPC MENU -->

                            <!--- THIS IS FOR STORE -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '9'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                
                                
                                
                                
                                
                                
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/fetchmodelwisetask')); ?>" class="nav-link <?php echo e(((Request::is('admin/fetchmodelwisetask')) || (Request::is('admin/fetchmodelwisetask')) )?'active':''); ?>">Task Listing</a>
                                    </li>
                                    <?php endif; ?>

                                <?php endif; ?>
                            </ul>
                            <!--- END OF STORE MENU -->

                            <!--- THIS IS FOR ENG ASSEMBLY & TESTING SECTION -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '10'): ?>

                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-ass-list')) || (Request::is('admin/engine-ass-list')) )?'active':''); ?>">Enter / Update Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">Enter BIS Report</a>
                                    </li>
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">View BIS Report</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF ENG ASSEMBLY & TESTING SECTION MENU -->

                            <!--- THIS IS FOR TRAN ASSEMBLY & TESTING SECTION -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '11'): ?>
                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-diss-list')) || (Request::is('admin/engine-diss-list')) )?'active':''); ?>">Enter / Update Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter BIS Report</a>
                                    </li>
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View BIS Report</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF ENG ASSEMBLY & TESTING SECTION MENU -->

                            <!--- THIS IS FOR HYD. COMP. ASSEMBLY & TESTING SECTION -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '12'): ?>
                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-diss-list')) || (Request::is('admin/engine-diss-list')) )?'active':''); ?>">Enter / Update Assembly Checklist</a>
                                    </li>
                                <!-- <li class="nav-item">
                                <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Checkgate Three & Update Task Status</a>
                            </li>-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">Enter BIS Report</a>
                                    </li>
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-diss-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View BIS Report</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF HYD. COMP. ASSEMBLY & TESTING SECTION MENU -->

                            <!--- THIS IS FOR MOR ASSEMBLY SECTION -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '14'): ?>
                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-ass-list')) || (Request::is('admin/engine-ass-list')) )?'active':''); ?>">Enter / Update Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">Enter Testing Report(BIS)</a>
                                    </li>
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-ass-list')) || (Request::is('admin/engine-ass-list')) )?'active':''); ?>">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">View Testing Report(BIS)</a>
                                    </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF MOR ASSEMBLY SECTION MENU -->

                            <!--- THIS IS FOR UNDERCARRIAGE ASSEMBLY SECTION -->
                            <ul class="nav nav-sm flex-column">
                            <?php if(request()->session()->get('user')['section_id'] == '15'): ?>
                                <?php if(request()->session()->get('user')['role_id'] == '1'): ?><!--Engineer-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-ass-list')) || (Request::is('admin/engine-ass-list')) )?'active':''); ?>">Enter / Update Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">Enter Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">Enter Testing Report(BIS)</a>
                                    </li>
                                <?php endif; ?>
                                <?php if(request()->session()->get('user')['role_id'] == '2'): ?><!--Head-->
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/engine-ass-list')); ?>" class="nav-link <?php echo e(((Request::is('admin/engine-ass-list')) || (Request::is('admin/engine-ass-list')) )?'active':''); ?>">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link <?php echo e(((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''); ?>">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('admin/bis-listing')); ?>" class="nav-link <?php echo e(((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''); ?>">View Testing Report(BIS)</a>
                                    </li>>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                            <!--- END OF UNDERCARRIAGE ASSEMBLY SECTION MENU -->

                        </div>
                        <!-- Menu structure end -->
                    </li>
                </ul>
            </div>
        </ul>
    </div>
</nav>





























































































































































































































































































































































































<?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/include/sidebar.blade.php ENDPATH**/ ?>