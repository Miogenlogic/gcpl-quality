<!-- Project List -->

<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('public/assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">All service requests</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/branch-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">All service requests</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- Project List -->
    <div class="row">
        <div class="col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <!-- Card header -->
                        <div class="card-header border-0">
                            <h3 class="mb-0">Service Request List</h3>
                        </div>
						<div>
						<a href="<?php echo e(url('admin/service-request-add')); ?>" class="btn btn-info" style="    float: right;margin-right: 25px;margin-bottom: 12px;">Create</a>
						</div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush" id="tabe1">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort" data-sort="number">#</th>
                                    <th scope="col" class="sort" data-sort="name">Service Request No</th>
									 <th scope="col" class="sort" data-sort="name">Description</th>
									  <th scope="col" class="sort" data-sort="name">Employee Respnsible</th>
									  <th scope="col" class="sort" data-sort="name">Impact</th>
									   <th scope="col" class="sort" data-sort="name">Status</th>
                                    <th scope="col" class="sort" data-sort="name">Customer</th>
                                    <th scope="col" class="sort" data-sort="name">Branch</th>
                                    <th scope="col" class="sort" data-sort="name">Component Name</th>
                                    <th scope="col" class="sort" data-sort="name">Segment</th>
                                      <th scope="col" class="sort" data-sort="name">Recomendation</th>
                                    <th scope="col" class="sort" data-sort="name">Action</th>
                                </tr>
                                </thead>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>

    <script src="<?php echo e(URL::asset('public/assets/vendor/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#tabe1').DataTable({
                processing: true,
                serverSide: true,
                ajax:{
                    url: '<?php echo e(url("admin/service-request-get-table")); ?>',
                },
                columns: [
                    {data: 'id', name: 'id',orderable: false, searchable: false},
                    {data: 'service_request_no', name: 'service_request_no'},
					 {data: 'description', name: 'description'},
					  {data: 'empres', name: 'empres'},
					   
                    {data: 'impact', name: 'impact'},
					 {data: 'cc_status', name: 'cc_status'},
					  {data: 'customer', name: 'customer'},
                    {data: 'branch_name', name: 'branch_name'},
                    {data: 'component_name', name: 'component_name'},
                    {data: 'segment', name: 'segment'},
					   {data: 'recom', name: 'recom'},
                    //{data: 'created_at', name: 'created_at'},
                    {data: 'action', name: 'action', orderable: false, searchable: false} ,
                ],
                // pageLength: 25,
                // order: [[ 2, "asc" ]]
            });

        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/branchengineer/allserviceRequest.blade.php ENDPATH**/ ?>