<!-- Project List -->
<?php
    $i=0;
    //$v=0;

?>


<?php $__env->startSection('head'); ?>

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Check sheet entry</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/service-engineer-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Check sheet</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php
        //$i=0;
        $v=0;

    ?>


    <?php

            //print_r($service);exit;
            // echo '<pre>';print_r($mcSerial[0]['serial_no']);die;
            $exterwash=App\Helpers\UserHelper::ccinspexternalwash();
            $commercial=App\Helpers\UserHelper::commertciallogistic();
            $ccpartclean=App\Helpers\UserHelper::ccpartclean();
            $basicengine=App\Helpers\UserHelper::partothercompbasicengine();
            $lubri=App\Helpers\UserHelper::partothercomplubrication();
            $cooler=App\Helpers\UserHelper::partothercompcooler();
            $fuel=App\Helpers\UserHelper::partothercompfuel();
            $cylinderhead=App\Helpers\UserHelper::partinspectioncylinderhead();
            $conrod=App\Helpers\UserHelper::partconnectingrod();
            $cylinhed=App\Helpers\UserHelper::partcylinderhead();
            $camshaft=App\Helpers\UserHelper::partcrankshaft();
            $cmsftdetails=App\Helpers\UserHelper::partcamshaftdetails();
             $beforestart=App\Helpers\UserHelper::beforestartassembly();
             $cominspreport=App\Helpers\UserHelper::ComponentInspectionReport();
            $fandri=App\Helpers\UserHelper::partsfandrive();
            $oilpump=App\Helpers\UserHelper::partsoilpump();
            $aircompressor=App\Helpers\UserHelper::partaircompressor();
            $waterpump=App\Helpers\UserHelper::partwaterpump();
            $conrodbush=App\Helpers\UserHelper::conrodbushreplacemnt();
            $engineassembly=App\Helpers\UserHelper::assemblychecksheet();
            $compdet=App\Helpers\UserHelper::dynamicchkshtdemo($service['machine_modelno']);
            $childsec=App\Helpers\UserHelper::dynamicchildsec($service['machine_modelno']);
           // $columnsection=App\Helpers\UserHelper::columndynamic($service['machine_modelno']);

        //echo "<pre>";print_r($childsec);exit;
            //$sec=App\Helpers\UserHelper::sectionname();
    ?>

    <div class="accordion" id="checkSheet">

        <div class="text-right mb-1" style="padding-right: 70px">

            <?php if(isset($agrregate->id) && $agrregate->work_done ==1): ?>
                <form method="post" action="<?php echo e(url('admin/excel-download')); ?>" enctype="multipart/form-data">
                    <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <!--  <a href="<?php echo e(url('admin/excel-download')); ?>">Excel Download </a>-->
                    <input class="btn btn-primary" type="submit" value="Excel Download">
                </form>
            <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('eng_head')): ?>
                <div class="col-md-4">
                    <?php if($service->status=='Rejected'): ?>
                        <label class="form-control-label" for="customer" style="padding-top: 20px">Rejected CheckSheet</label>
                        <textarea type="text" name="comment_for_approve" class="form-control " id="commentrgt" disabled><?php echo e($service->comment_for_approve); ?></textarea>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
        </div>

    <?php
        $dynamic=0;

    ?>


    <!-- Section hidden/show -->

    <?php
        $li = 0;
    ?>
    <?php $__currentLoopData = $compdet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hideSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $sectionname[$li] = $hideSection['section_name'];
                            $li++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php

                    $sec_aggre = in_array('Aggregation Information',$sectionname);
                    $sec_pre = in_array('Pre History',$sectionname);
                    $sec_com = in_array('Commercial & Logistics Report',$sectionname);
                    $sec_loose = in_array('Loose part report',$sectionname);
                    $sec_extwash = in_array('CC Inspection Check sheet after external washing',$sectionname);
                    $sec_prtclean = in_array('CC Inspection Check sheet after Parts Cleaning',$sectionname);
                    $sec_mising = in_array('Missing/Damaged Parts Report',$sectionname);
                    $sec_prtinsp = in_array('Parts Inspection Report',$sectionname);
                    $sec_loose = in_array('List of Salvage components',$sectionname);
                    $sec_engassem = in_array('Engine Assembly Checksheet',$sectionname);


    ?>




                    <!-- Engine Assembly Check sheet  -->
                    <?php if(!empty($sec_engassem)): ?>
                        <?php
                            $engassemhiddden = '';

                        ?>
                    <?php else: ?>
                        <?php
                            $engassemhiddden = 'hidden';

                        ?>
                    <?php endif; ?>

                         <div class="card" <?php echo e($engassemhiddden); ?>>
            <div class="card-header" id="engineassemblychecksheet">
                <h2 class="mb-0">
                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                            data-target="#collapseengineassemblychecksheet" aria-expanded="false" aria-controls="collapseengineassemblychecksheet">
                        <?php $__currentLoopData = $compdet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dynamicsectionname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($dynamicsectionname['section_id']==17): ?>
                                <?php echo e($dynamicsectionname['section_name']); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </button>
                </h2>
            </div>
            <div id="collapseengineassemblychecksheet" class="collapse" aria-labelledby="engineassemblychecksheet" data-parent="#checkSheet">
                <div class="card-body">
                    <form method="post" action="<?php echo e(url('admin/engine-assembly-save')); ?>" enctype="multipart/form-data">


                            <div class="table-responsive">
                                <table class="table align-items-center table-flush">

                                <?php
                                    $i=0;
                                ?>
                                <!-- dynamic repeater wrapper -->
                                    <div class="engine-assembly-checksheet">


                                        <thead class="thead-light">
                                            <tr>
                                                <th>Operation despcription</th>
                                                <th>Specification</th>
                                                <th>Actual Value</th>

                                            </tr>
                                        </thead>

                                        <?php

                                            $i=0;
                                        ?>
                                        <?php $__currentLoopData = $engineassembly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($qes->operation_desp)): ?>
                                               <?php if($showassembly!=Null): ?>
                                                    <?php
                                                        $actual=array_search($qes->operation_desp,$showassembly->operationdesp);

                                                    ?>
                                                    <tbody>
                                                    <tr>
                                                        <td><?php echo e($qes->operation_desp); ?></td>
                                                        <td >
                                                            <input type="hidden" name="operationdesp[<?php echo e($i); ?>]" value="<?php echo e($qes->operation_desp); ?>">
                                                            <div class="form-group mb-0">
                                                                <input type="hidden" name="specification[<?php echo e($i); ?>]" value="<?php echo e($qes->specification); ?>">
                                                                <?php echo e($qes->specification); ?>

                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group mb-0">
                                                                <input type="text" name="actval[<?php echo e($i); ?>]" value="<?php echo e($showassembly->actval[$actual]); ?>">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                    <?php
                                                        $i++;
                                                    ?>
                                               <?php else: ?>


                                                                    <tbody>
                                                                    <tr>
                                                                        <td><?php echo e($qes->operation_desp); ?></td>
                                                                        <td >
                                                                            <input type="hidden" name="operationdesp[<?php echo e($i); ?>]" value="<?php echo e($qes->operation_desp); ?>">
                                                                            <div class="form-group mb-0">
                                                                                <input type="hidden" name="specification[<?php echo e($i); ?>]" value="<?php echo e($qes->specification); ?>">
                                                                                <?php echo e($qes->specification); ?>

                                                                            </div>
                                                                        </td>
                                                                        <td>
                                                                            <div class="form-group mb-0">
                                                                                <input type="text" name="actval[<?php echo e($i); ?>]" value="">
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    </tbody>

                                                            <?php
                                                                $i++;
                                                            ?>
                                               <?php endif; ?>
                                            <?php endif; ?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </table>
                            </div>
                                        <?php
                                            $i++;
                                        ?>
                        <?php if(request()->session()->get('user')['section_id'] == '10'): ?>
                            <?php if(request()->session()->get('user')['role_id'] == '1'): ?>
                                <input type="hidden" name="dept_id" value="10">
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(request()->session()->get('user')['section_id'] == '11'): ?>
                            <?php if(request()->session()->get('user')['role_id'] == '1'): ?>
                                <input type="hidden" name="dept_id" value="11">
                            <?php endif; ?>
                        <?php endif; ?>

                        <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                        <!-- /row -->

                        <?php if((isset($allvalassembly[0]->id)&& $allvalassembly[0]->work_done==0)||!isset($allvalassembly[0]->id)): ?>
                            <button class="btn btn-primary" type="submit">Save</button>
                            <button class="btn btn-warning" type="reset">Reset form</button>
                        <?php else: ?>
                            <button class="btn btn-primary" type="submit" disabled>Save</button>
                            <button class="btn btn-warning" type="reset" disabled>Reset form</button>
                        <?php endif; ?>
                    </form>

                </div>
            </div>
        </div>


        <?php
  // print_r($showloosepat[0]->id);exit;
    ?>

        <?php if(isset($agrregate->id) && isset($prehist->id) && isset($allvalcommercialLog->id) && isset($allvalexterwash->id) && isset($allvalpartcln->id) && isset($allvalcylinderblock->id) && isset($allvalothercom->id) && isset($allvalconrod->id) && isset($allvalcranksft->id) && isset($allvalcamsft->id) && isset($allvalcylinderheadoil->id) && isset($showmissing[0]->id) && isset($showsalvage[0]->id) && isset($showloosepat[0]->id) && isset($showfailed[0]->id) && isset($allvalfandrive[0]->id) && isset($allvalwaterpump[0]->id) && isset($allvaloilpump[0]->id) && isset($allvalaircomp[0]->id) && isset($allvalconrodbush[0]->id) && isset($allvalassembly[0]->id) && ($agrregate->work_done ==0)): ?>
        <form method="post" action="<?php echo e(url('admin/check-sheet-total-form-save')); ?>" enctype="multipart/form-data">
            <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input class="btn btn-primary" type="submit" value="submit">

        </form>
    <?php else: ?>
        <input class="btn btn-primary" type="submit" value="submit" disabled>

    <?php endif; ?>

  


    </div>

    <?php if(auth()->check() && auth()->user()->hasRole('eng_head')): ?>
    <div class="" style="padding-right: 70px">
        <form method="post" action="<?php echo e(url('admin/head-approve-checksheet-save')); ?>" enctype="multipart/form-data">
            <div class="custom-control custom-control-inline custom-radio">
                <input name="status" class="custom-control-input approved" id="approved" type="radio" value="Approved">
                <label class="custom-control-label" for="approved">Approve</label>
            </div>
                <div class="text-right mb-1 col-md-4 commentapr"  style="display:none" >

                    <input type="text" name="comment_for_approve" class="form-control" id="commentapr" value="" >
                </div>

            <div class="custom-control custom-control-inline custom-radio">
                <input name="status" class="custom-control-input rejected" id="rejected" type="radio" value="Rejected">
                <label class="custom-control-label" for="rejected">Reject</label>
            </div>
                <div class="text-right mb-1 col-md-4 commentrgt"  style="display:none">

                    <input type="text" name="comment_for_approve" class="form-control " id="commentrgt1" value="">
                </div>

            <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input class="btn btn-primary" type="submit" value="submit">

        </form>


    </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_script'); ?>
    <script src="<?php echo e(URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>
    <script>
        $('.select2').select2();
    </script>








    <script type="text/javascript">
        /*Model serial no*/
        $('#approved').change(function() {
            //alert(1);
          $(".commentapr").show();
          $(".commentrgt").hide();

            //console.log(model);

        });
        $('#rejected').change(function() {
           // alert(1);
            $(".commentapr").hide();
            $(".commentrgt").show();
            $(".commentrgt").prop("disabled".false);


            //console.log(model);

        });

    </script>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/include/checksheetAssemblyCommon.blade.php ENDPATH**/ ?>