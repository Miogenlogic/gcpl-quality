<!-- Project List -->



<?php $__env->startSection('head'); ?>
<style>
    .custom-control-label::before,
    .custom-control-label::after {
        top: 0.2rem;
        width: 1.25rem;
        height: 1.25rem;
    }
</style>



    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Create New section</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin/super-admin-dashboard')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page"></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="<?php echo e(url('admin/checksheetsection-add-save')); ?>" enctype="multipart/form-data">



                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="id">Department</label>
                                <select name="dept_id" class="form-control">
                                    <?php
                                        $dept=App\Helpers\UserHelper::departmentforchecksheet();
                                    ?>

                                    <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($dep->id); ?>"><?php echo e($dep->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="id">Model No</label>
                                <select name="model_id" class="form-control">
                                    <?php
                                        $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                    ?>

                                    <?php $__currentLoopData = $mchmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($model->id); ?>"><?php echo e($model->model_no); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group " style="height: 335px;
    overflow-x: scroll">
                                <label for="section_id" class="form-control-label  originalsection">Section</label>

                                    <?php
                                        $sect=App\Helpers\UserHelper::sectionforchecksheet();
                                        $i=1;
                                    ?>

                                    <?php $__currentLoopData = $sect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="custom-control form-control-lg custom-checkbox">
                                            <input type="checkbox"  name="section_id[]" value="<?php echo e($sec->id); ?>" class="custom-control-input getsection" id="customCheck<?php echo e($i); ?>">
                                            <label class="custom-control-label" for="customCheck<?php echo e($i); ?>"><?php echo e($sec->name); ?></label>
                                        </div>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>


                        <div class="col-md-3 " >
                            <div class="form-group"  style="height: 335px;
        overflow-x: scroll">

                                   <!--<label for="" class="form-control-label  childsection">Child Section</label>-->
                                    <div id="childsectionContainer">
                                    
                                    </div>

                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group" style="height: 335px;
    overflow-x: scroll">


                                <!--<label for="" class="form-control-label  subchildsection">Sub Section</label>-->

                                    <div id="subchildsectionContainer">

                                        <?php
                                            $subchildsecnew=App\Helpers\UserHelper::subchildpopulate();
                                        $sub=0;
                                        ?>
                                        <?php $__currentLoopData = $subchildsecnew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php echo e($value[$sub]['sub_child_section']); ?>


                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $sub++;
                                        ?>

                                    </div>


                            </div>
                        </div>



                    </div>



                <!-- /row -->
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button class="btn btn-primary" type="submit">Submit</button>
                <button class="btn btn-warning" type="cancel">Cancel</button>
            </form>
        </div>

        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="<?php echo e(url('admin/checksheetcolumn-add-save')); ?>" enctype="multipart/form-data">



                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="id">Department</label>
                            <select name="dept_id" class="form-control">
                                <?php
                                    $dept=App\Helpers\UserHelper::departmentforchecksheet();
                                ?>

                                <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($dep->id); ?>"><?php echo e($dep->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="id">Model No</label>
                            <select name="model_id" class="form-control">
                                <?php
                                    $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                ?>

                                <?php $__currentLoopData = $mchmodel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($model->id); ?>"><?php echo e($model->model_no); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group " style="height: 335px;
    overflow-x: scroll">
                            <label for="section_id" class="form-control-label  originalsection">Section</label>

                            <?php
                                $sect=App\Helpers\UserHelper::sectionforchecksheet();
                                $i=1;
                            ?>

                            <?php $__currentLoopData = $sect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control form-control-lg custom-checkbox">
                                    <input type="checkbox"  name="section_id1[]" value="<?php echo e($sec->id); ?>" class="custom-control-input mainsection" id="customCheck1<?php echo e($i); ?>">
                                    <label class="custom-control-label" for="customCheck1<?php echo e($i); ?>"><?php echo e($sec->name); ?></label>
                                </div>
                                <?php
                                    $i++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>




                    <div class="col-md-3">
                        <div class="form-group" style="height: 335px;
    overflow-x: scroll">
                            <label for="role">Columns</label>
                            <div id="columnContainer">

                            </div>

                        </div>
                    </div>
                </div>



                <!-- /row -->
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button class="btn btn-primary" type="submit">Submit</button>
                <button class="btn btn-warning" type="cancel">Cancel</button>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_script'); ?>

    <!-- Optional JS -->
    <script src="<?php echo e(URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>


    <script type="text/javascript">
        /*component model no*/
        $('.getsection').change(function(event) {
            var checkshtchild = [];
            $.each($("input[name='section_id[]']:checked"), function(){
                checkshtchild.push($(this).val());
            });

            //alert("section: " + favorite.join(", "));

            //console.log(model);

            $.ajax({
                url: '<?php echo e(url("/admin/child-section-show")); ?>',
                type: 'POST',
                data: {checkshtchild:checkshtchild,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.childsection').show();

                    $('#childsectionContainer').html(response);

                    //$('.compserial').show();

                   // $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>

    <script type="text/javascript">
        /*component model no*/
       $('.childSection_1').click(function(event) {
        console.log(2);
        //$('#childSection').change(function(event) {
          //  var subsect = $(this).val();
            var subsect = [];
            $.each($("input[name='child_id[]']:checked"), function(){
                subsect.push($(this).val());
            });
            //alert("section: " + favorite.join(", "));

            //console.log(model);

            $.ajax({
                url: '<?php echo e(url("/admin/sub-child-section-show")); ?>',
                type: 'POST',
                data: {subsect:subsect,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);

                    $('.subchildsection').show();

                    $('#subchildsectionContainer').html(response);

                    //$('.compserial').show();

                    // $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>

    <script type="text/javascript">
        /*component model no*/
        $('.mainsection').change(function(event) {
            var columnchksht = [];
            $.each($("input[name='section_id1[]']:checked"), function(){
                columnchksht.push($(this).val());
            });

            //alert("section: " + favorite.join(", "));

            //console.log(model);

            $.ajax({
                url: '<?php echo e(url("/admin/column-section-show")); ?>',
                type: 'POST',
                data: {columnchksht:columnchksht,'_token':'<?php echo e(csrf_token()); ?>'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.childsection').show();

                    $('#columnContainer').html(response);

                    //$('.compserial').show();

                    // $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\gcpl-quality\resources\views/admin/checksheet/addchecksheetsection.blade.php ENDPATH**/ ?>