@extends('admin.include.layout')
<!-- Project List -->


@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Create new service request</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service requeust</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{url('admin/service-request-add-save')}}" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Service Request Number</label>
                            <input type="text" name="service_request_no" class="form-control" id="service" value="" readonly>
                            @if($errors->has('service_request_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('service_request_no')}}</div>
                            @endif
                        </div>
                    </div>
					
					
					
					<div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Description</label>
							<textarea name="description" class="form-control" id="service" value=""></textarea>
                     </div>
                    </div>
					
					
					
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Employee Responsibly</label>
                            <select name="empres" id="empres" class="form-control">
                                
                               <option selected="selected">
							  
                                  @foreach( $employee as  $emp)
									<option selected="" value="{{$emp->id}}">
                                        {{$emp->name}}
										</option>
                                   @endforeach

                                </option>
                          </select>

                        </div>
                    </div>
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Status</label>
                           <select name="cc_status" id="cc_status" class="form-control">
                                <option selected="selected">
                               
                                    @foreach( $status as  $stat)
									<option selected="" value="{{$stat->id}}">
                                        {{ $stat->status}}
										</option>
                                    @endforeach

                                </option>
                          </select>

                        </div>
                    </div>
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Impact/Urgency</label>
                            <input type="text" name="impact" class="form-control" id="service" value="" >

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="customer">Select customer</label>
                            <select name="customer" class="form-control">
                                <option selected="selected" disabled="disabled">--Select customer--</option>
                                @php
                                    $customer=App\Helpers\UserHelper::customer();
                                @endphp

                                @foreach($customer as $cus)

                                    <option value="{{$cus->name}}">{{$cus->name}}</option>

                                @endforeach
                            </select>
                            @if($errors->has('customer'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('customer')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="job">Job number</label>
                            <input type="text" name="job_no" class="form-control" id="" placeholder="">
                            @if($errors->has('job_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('job_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">AR number</label>
                            <input type="text" name="ar_no" class="form-control" id="" placeholder="AR number" value="">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Model number</label>
                            <select name="machine_modelno" id="machmodel" class="form-control">
                                <option selected="selected" disabled="disabled">--Select model number--</option>

                                @php
                                    $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                @endphp

                                @foreach($mchmodel as $cmodel)

                                    <option value="{{$cmodel->id}}">{{$cmodel->model_no}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('model_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('model_no')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label machserial" for="model">Machine Serial number</label>
                            <select name="machine_serialno" id="machserial" class="form-control">


                            </select>

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compmodel" for="model">Component Model number</label>
                            <select name="comp_model_no" id="compmodel" class="form-control">


                            </select>

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Component Serial Number</label>
                            <select name="component_serial_no" id="compserial" class="form-control">

                            </select>

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compname" for="Component">Component name</label>
                            <select name="component_name" id="compname" class="form-control">
                                <option selected="selected" disabled="disabled">--Select component--</option>
                                @php
                                    $comptype=App\Helpers\UserHelper::componenttype();
                                @endphp

                                @foreach($comptype as $ctype)

                                    <option value="{{$ctype->type}}">{{$ctype->type}}</option>

                                @endforeach
                            </select>
                            @if($errors->has('component_name'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('component_name')}}</div>
                            @endif
                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Branch Name</label>
                            <select name="branch_name" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Branch name--</option>

                                @php
                                    $branchnme=App\Helpers\UserHelper::branchname();
                                @endphp

                                @foreach($branchnme as $bname)

                                    <option value="{{$bname->sales_ofc}}">{{$bname->sales_ofc}}</option>

                                @endforeach
                            </select>
                            @if($errors->has('branch_name'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('branch_name')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Segment</label>
                            <select name="segment" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Segment--</option>

                                @php
                                    $segment=App\Helpers\UserHelper::segment();
                                @endphp

                                @foreach($segment as $seg)

                                    <option value="{{$seg->name}}">{{$seg->name}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('segment'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('segment')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Branch Location</label>
                            <input type="text" name="branch_location" class="form-control" id="" placeholder="Branch Location" value="">
                            @if($errors->has('branch_location'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('branch_location')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Work order no</label>
                            <input type="text" name="work_orderno" class="form-control" id="service" value="" >

                        </div>
                    </div>
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label for="servicedate" class="form-control-label">Service Request Date</label>

                            <input class="form-control" name="date" type="date" value="" id="servicedate">
                        </div>
                        {{-- @if($errors->has('date'))
                             <div class="invalid-feedback" style="display:block;">{/{$errors->first('date')}}</div>
                         @endif--}}
                    </div>
                  <div class="col-sm-6 col-md-11">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Recomendation</label>
							<textarea name="recom" class="form-control" id="service" value=""></textarea>
                         

                        </div>
                    </div>
                    

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload pre-history</label>
                            <div class="custom-file">
                                <input type="file" name="import_file" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                        </div>
                    </div>


                </div><!-- /row -->
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Save</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>
            <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="{{URL::asset('public/assets/download/sampleexcel.xlsx')}}">Sample excel File</a></div>
        </div>

    </div>
    <!-- Project List -->




@endsection
@section('after_script')

    <!-- Optional JS -->
    {{--<script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>--}}
    <script src="{{URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/machine-serial-list-show") }}',

                type: 'POST',

                data: {model:model,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-model-list-show") }}',

                type: 'POST',

                data: {commodel:commodel,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-serial-list-show") }}',

                type: 'POST',

                data: {coserial:coserial,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>



@endsection