@extends('admin.include.layout')

@section('after_styles')
    <link rel="stylesheet" href="{{URL::asset('public/assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">
@endsection

@section('head')
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Customer</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service request</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    <div class="row">
        <div class="col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <!-- Card header -->
                        <div class="card-header border-0">
                            <h3 class="mb-0">Upload Customer List Here</h3>
                        </div>
                        <form action="{{url('admin/upload-customer')}}" method="post">
                            <input type="file"><br><br>
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                            <button class="btn btn-primary" type="submit">Submit</button>
                            <button class="btn btn-warning" type="cancel">Cancel</button>
                        </form>


                        <div align="right">
                            <a href="{{url('admin/download-template-customer')}}"><button class="btn"><i class="fa fa-download"></i>Sample Template Download</button>
                            </a></div>
                    </div>




                    <div class="row">
                        <div class="col-xl-12">
                            <div class="row">
                                <div class="col">
                                    <div class="card">
                                        <!-- Card header -->
                                        <div class="card-header border-0">
                                            <h3 class="mb-0">All Users Details</h3>
                                        </div>

                                        <a href="{{url('admin/download-customer')}}"><button class="btn"><i class="fa fa-download"></i>Customer details Download</button>
                                        </a>

                                        <div class="text-right mb-1" style="padding-right: 70px">
                                            <a class="btn btn-info text-white" href="{{url('admin/customer-add')}}">Add Customer</a>
                                        </div>





                                        <div class="table-responsive">





                                            <div class="table-responsive">
                                                <table class="table align-items-center table-flush" id="tabe1">
                                                    <thead class="thead-light">
                                                    <tr>

                                                        <th scope="col" class="sort" data-sort="name">#</th>

                                                        <th scope="col" class="sort" data-sort="name">NAME</th>
                                                        <th scope="col" class="sort" data-sort="name">Customer Code</th>
                                                        <!-- <th scope="col" class="sort" data-sort="name">customer code</th>-->
                                                        <th scope="col" class="sort" data-sort="name">address</th>
                                                        <th scope="col" class="sort" data-sort="name">address2</th>
                                                        <th scope="col" class="sort" data-sort="name">address3</th>
                                                        <th scope="col" class="sort" data-sort="name">Phone no</th>
                                                        <th scope="col" class="sort" data-sort="name">Email</th>
                                                        <th scope="col" class="sort" data-sort="name">region</th>
                                                        <th scope="col" class="sort" data-sort="name">branch</th>
                                                        <th scope="col" class="sort" data-sort="name">created at</th>
                                                        <!--    <th scope="col" class="sort" data-sort="name">Action</th>-->

                                                        <!-- <th scope="col" class="sort" data-sort="name">Action</th>-->
                                                    </tr>
                                                    </thead>

                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                  </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

                                        @endsection


                                        @section('after_script')

                                            <script src="{{URL::asset('public/assets/vendor/datatables.net/js/jquery.dataTables.min.js')}}"></script>
                                            <script src="{{URL::asset('public/assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>

                                            <script type="text/javascript">
                                                $(document).ready(function(){
                                                    $('#tabe1').DataTable({
                                                        processing: true,
                                                        serverSide: true,
                                                        ajax:{
                                                            url: '{{ url("admin/fetchcustomer-get-table") }}',
                                                        },
                                                        columns: [
                                                            {data: 'id', name: 'id',orderable: false, searchable: false},
                                                            {data: 'name', name: 'name'},
                                                            {data: 'customer_code', name: 'customer_code'},
                                                            //{data: 'customer_code', name: 'customer_code'},
                                                            {data: 'address', name: 'address'},
                                                            {data: 'address2', name: 'address2'},
                                                            {data: 'address3', name: 'address3'},
                                                            {data: 'phone_no', name: 'phone_no'},
                                                            {data: 'email', name: 'email'},
                                                            {data: 'region', name: 'region'},
                                                            {data: 'branch', name: 'branch'},
                                                            {data: 'created_at', name:'created_at'},
                                                            //{data: 'action', name: 'action', orderable: false, searchable: false} ,


                                                        ],
                                                    });


                                                });
                                            </script>

@endsection

