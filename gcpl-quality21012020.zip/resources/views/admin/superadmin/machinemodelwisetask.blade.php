@extends('admin.include.layout')
<!-- Project List -->


@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Master Screen For Project</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Task Master</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>



@endsection
@section('body')
    @php
        //print_r( $mastermenu);
        //exit;

    @endphp




    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{url('admin/insertmastertask')}}" enctype="multipart/form-data">

                <div class="row">
                   <div class="col-md-6">
                        <div class="form-group">
                            <label for="question">Model No</label>
							
                            <select name="model_no" id="model_id" class="form-control">
							 <option selected="selected">select</option>
                                <option selected="selected">
                               
                                    @foreach($modelno as  $model)
									<option selected="" value="{{$model->id}}">
                                        {{ $model->model_no}}
										</option>
                                    @endforeach

                                </option>
                             
                            </select>
                        </div>
                    </div>
					
   <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Department name</label>
                            <select name="dept_id" id="dept_id" class="form-control">
                                <option selected="selected">
                               
                                    @foreach( $deptname as  $name)
									<option selected="" value="{{$name->id}}">
                                        {{ $name->name}}
										</option>
                                    @endforeach

                                </option>
                             
                            </select>
                           

                        </div>
                    </div>


                    </div>
					 

                <div class="row">

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="question">Task/Subtask</label>
                            <input type="text" class="form-control" id="" placeholder="name" name="name">
                            @if($errors->has('task_name'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('	task_name')}}</div>
                            @endif
                        </div>
                    </div>
					<div class="col-md-6">
                        <div class="form-group">
                            <label for="question">Parent Task</label>
                            <select class="form-control" name="parent">
							 <option>Select</option>
                             @foreach(  $selecttask as  $task)
									<option selected="" value="{{$task->id}}">
                                        {{ $task->name}}
										</option>
                                    @endforeach
                           
                       </select>
                        
                    </div>
                </div>
				 <div class="col-md-6">
                    <div class="form-group">
                        <label for="question">Sort Order</label>
                        <input type="number" class="form-control" id="" placeholder="select days" name="sort_order">
                        @if($errors->has('sort_order'))
                            <div class="invalid-feedback" style="display:block;">{{$errors->first('sort_order')}}</div>
                        @endif
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="form-group">
                        <label for="question">Turn Around Time(TAT)</label>
                        <input type="number" class="form-control" id="" placeholder="select days" name="tat">
                        @if($errors->has('tat'))
                            <div class="invalid-feedback" style="display:block;">{{$errors->first('tat')}}</div>
                        @endif
                    </div>
                </div>
                      
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="question">Predecessor</label>

                        <select class="form-control select2" multiple="multiple" name="predicessor[]" id="predicessor">

                            <option selected="selected">Select </option>
                            @foreach($items as $mod)
                                <option selected="selected" value="{{$mod->predicessor}}" >
                                    {{$mod->predicessor}}
                                </option>
                            @endforeach

                        </select>

                    </div>
                </div>
   
					  

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="question">Relation Type</label>
                        <select class="form-control" name="relation_type">
                            <option>Select relation</option>
                            <option>Finish to Start</option>
                            <option>Start to Start</option>
                            <option>Finish to Finish</option>
                        </select>
                        @if($errors->has('relation_type'))
                            <div class="invalid-feedback" style="display:block;">{{$errors->first('relation_type')}}</div>
                        @endif
                    </div>
                </div>
				 <div class="col-md-6">
                    <div class="form-group">
                        <label for="question">Description</label>
                        <input type="text" class="form-control" id="" placeholder="" name="description">
                        @if($errors->has('description'))
                            <div class="invalid-feedback" style="display:block;">{{$errors->first('description')}}</div>
                        @endif
                    </div>
                </div>
				</div>
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Submit</button>
                <button class="btn btn-warning" type="cancel">Cancel</button>
                </div>
            </form>
        </div>
    </div>

@endsection
@section('after_script')

    <!-- Optional JS -->
    <script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>

@endsection

