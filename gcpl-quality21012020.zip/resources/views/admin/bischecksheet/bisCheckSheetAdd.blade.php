@extends('admin.include.layout')
<!-- Project List -->


@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Create BisCheckSheet</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service requeust</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{url('admin/bis-add-save')}}" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">SL number</label>
                            <input type="text" name="sl_no" class="form-control" id="service" value="" >

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Job Number</label>
                            <input type="text" name="job_no" class="form-control" id="customer" value="{{old('job_no')?old('job_no'):$masterjobno->job_no}}" >
                            @if($errors->has('job_no'))
                                <div class="invalid-feedback" style="display:block;">{/{$errors->first('job_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="technician">TECHNICIAN</label>
                            <input type="text" name="technician" class="form-control" id="service" value="" >
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="model">Model</label>
                            <input type="text" name="model" class="form-control" id="service" value="" >
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="component_sl_no">COMPONENT SL NO.</label>
                            <input type="text" name="component_sl_no" class="form-control" id="" placeholder="component_sl_no" value="">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Customer</label>
                            <input type="text" name="customer" class="form-control" id="customer" value="{{old('customer')?old('customer'):$masterbis->customer}}" readonly>
                            @if($errors->has('customer'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('customer')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label machserial" for="test_smu">Test SMU</label>
                            <textarea rows="2" cols="20"class="" name="test_smu" value="test_smu">
                            </textarea>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compmodel" for="model">Engine enter date & time in the test bench</label>
                            <input type="text" name="engine_enter_date_time_in_the_test_bench" class="form-control" id="" placeholder="engine_enter_date_time_in_the_test_bench" value="">

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Date</label>
                            <input type="date" name="month" class="form-control" id="" placeholder="month" value="">

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compname" for="Component">Problem during testing</label>
                            <textarea rows="2" cols="20"class="" name="problem_during_testing" value="problem_during_testing">
                            </textarea>
                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="root_cause_analysis">Root cause Analysis</label>
                            <select name="root_cause_analysis" id="root_cause_analysis" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Option--</option>

                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->root_cause_analysis}}">{{$bischeckroot->root_cause_analysis}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('root_cause_analysis'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('root_cause_analysis')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="why">Why</label>
                            <textarea rows="2" cols="30" name= "why" class="" value="why">
                            </textarea>
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Solution</label>
                            <textarea rows="2" cols="25"class="" name="solution" value="solution">
                            </textarea>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Engine out date & time</label>
                            <input type="date" name="engine_out_date_time" class="form-control" id="" placeholder="engine_out_date_time" value="">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="impact">Impact</label>
                            <textarea rows="2" cols="25"class="" name="impact" value="impact">
                            </textarea>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Type of Problem</label>
                            <select name="type_of_problem" id="type_of_problem" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Option--</option>
                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->type_of_problem}}">{{$bischeckroot->type_of_problem}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('type_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('type_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Area of Problem</label>
                            <select name="area_of_problem" id="area_of_problem" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Option--</option>

                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->area_of_problem}}">{{$bischeckroot->area_of_problem}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('area_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('area_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Portion of Problem</label>
                            <select name="portion_of_problem" id="portion_of_problem" class="form-control">
                                <option selected="selected" disabled="disabled">--Select Option--</option>

                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->portion_of_problem}}">{{$bischeckroot->portion_of_problem}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('portion_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('portion_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Further action</label>
                            <textarea rows="2" cols="50"class="" name="further_action" value="further_action">
                            </textarea>
                        </div>
                    </div>
                    </div>



              <!-- /row -->
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Save</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>

        </div>

    </div>
    <!-- Project List -->




@endsection

