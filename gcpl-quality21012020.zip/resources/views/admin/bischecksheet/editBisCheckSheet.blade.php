@extends('admin.include.layout')
@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Edit BIS Checksheet</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Edit BIS Checksheet</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    @php
        //print_r($servicerequest);
        //die;
    @endphp

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{ url('/admin/save-bis')}}" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Sl_no</label>
                            <input type="text" name="sl_no" class="form-control" id="service" value="{{old('sl_no')?old('sl_no'):$servicerequest->sl_no}}" readonly>
                            @if($errors->has('sl_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('sl_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Job No</label>

                            <input type="text" name="customer" class="form-control" id="service" value="{{old('job_no')?old('job_no'):$servicerequest->job_no}}">
                            @if($errors->has('job_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('job_no')}}</div>
                            @endif



                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Technician</label>
                            <input type="text" name="technician" class="form-control" id="service" value="{{old('technician')?old('technician'):$servicerequest->technician}}" >
                            @if($errors->has('technician'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('technician')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">model</label>
                            <input type="text" name="model" class="form-control" id="service" value="{{old('model')?old('model'):$servicerequest->model}}" >
                            @if($errors->has('model'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('model')}}</div>
                            @endif
                        </div>
                    </div>


                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label class="form-control-label" for="service">component_sl_no</label>
                                    <input type="text" name="component_sl_no" class="form-control" id="service" value="{{old('component_sl_no')?old('component_sl_no'):$servicerequest->component_sl_no}}" >
                                    @if($errors->has('component_sl_no'))
                                        <div class="invalid-feedback" style="display:block;">{{$errors->first('component_sl_no')}}</div>
                                    @endif
                                </div>
                            </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">

                            <label class="form-control-label" for="service">customer</label>
                            <input type="text" name="customer" class="form-control" id="service" value="{{old('customer')?old('customer'):$servicerequest->customer}}" readonly>
                            @if($errors->has('customer'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('customer')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">test_smu</label>
                            <input type="text" name="test_smu" class="form-control" id="service" value="{{old('test_smu')?old('test_smu'):$servicerequest->test_smu}}" >
                            @if($errors->has('test_smu'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('test_smu')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">engine_enter_date_time_in_the_test_bench</label>
                            <input type="text" name="engine_enter_date_time_in_the_test_bench" class="form-control" id="service" value="{{old('engine_enter_date_time_in_the_test_bench')?old('engine_enter_date_time_in_the_test_bench'):$servicerequest->engine_enter_date_time_in_the_test_bench}}" >
                            @if($errors->has('test_smu'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('engine_enter_date_time_in_the_test_bench')}}</div>
                            @endif
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">month</label>
                            <input type="text" name="month" class="form-control" id="service" value="{{old('	month')?old('month'):$servicerequest->month}}" >
                            @if($errors->has('month'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('month')}}</div>
                            @endif
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">problem_during_testing</label>
                            <input type="text" name="problem_during_testing" class="form-control" id="service" value="{{old('problem_during_testing')?old('problem_during_testing'):$servicerequest->problem_during_testing}}" >
                            @if($errors->has('problem_during_testing'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('problem_during_testing')}}</div>
                            @endif

                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">root_cause_analysis</label>




                            <select name="root_cause_analysis" id="" class="form-control">
                                @foreach($rootanalysis as $mod)
                                    <option selected="selected" value="{{$mod->root_cause_analysis}}">
                                        {{$mod->root_cause_analysis}}
                                    </option>
                                @endforeach


                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->root_cause_analysis}}"  value="{{$bischeckroot->root_cause_analysis}}" >{{$bischeckroot->root_cause_analysis}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('root_cause_analysis'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('root_cause_analysis')}}</div>
                            @endif






                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">why</label>
                            <input type="text" name="why" class="form-control" id="service" value="{{old('why')?old('why'):$servicerequest->root_cause_analysis}}" >
                            @if($errors->has('why'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('why')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">solution</label>
                            <input type="text" name="solution" class="form-control" id="service" value="{{old('solution')?old('solution'):$servicerequest->solution}}" >
                            @if($errors->has('solution'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('solution')}}</div>
                            @endif

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">date</label>
                            <input type="text" name="engine_out_date_time" class="form-control" id="service" value="{{old('engine_out_date_time')?old('engine_out_date_time'):$servicerequest->	engine_out_date_time}}" >
                            @if($errors->has('engine_out_date_time'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('engine_out_date_time')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">impact</label>
                            <input type="text" name="impact" class="form-control" id="service" value="{{old('impact')?old('impact'):$servicerequest->impact}}" >
                            @if($errors->has('impact'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('impact')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">type_of_problem</label>
                            <select name="root_cause_analysis" id="" class="form-control">
                                @foreach($typeofproblem as $mod)
                                    <option selected="selected" value="{{$mod->type_of_problem}}">
                                        {{$mod->type_of_problem}}
                                    </option>
                                @endforeach


                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->type_of_problem}}"  value="{{$bischeckroot->root_cause_analysis}}" >{{$bischeckroot->type_of_problem}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('type_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('type_of_problem')}}</div>
                            @endif


                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">area of problem</label>
                            <select name="area_of_problem" id="" class="form-control">
                            @foreach($areaproblem as $mod)
                                <option selected="selected" value="{{$mod->area_of_problem}}">
                                    {{$mod->area_of_problem}}
                                </option>
                            @endforeach


                            @php
                                $bischeck=App\Helpers\UserHelper::bis();
                            @endphp

                            @foreach($bischeck as $bischeckroot)

                                <option value="{{$bischeckroot->area_of_problem}}"  value="{{$bischeckroot->area_of_problem}}" >{{$bischeckroot->area_of_problem}}</option>

                                @endforeach


                                </select>
                                @if($errors->has('type_of_problem'))
                                    <div class="invalid-feedback" style="display:block;">{{$errors->first('type_of_problem')}}</div>
                                @endif
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">portion_of_problem</label>
                            <select name="area_of_problem" id="" class="form-control">
                                @foreach($portionproblem as $mod)
                                    <option selected="selected" value="{{$mod->portion_of_problem}}">
                                        {{$mod->portion_of_problem}}
                                    </option>
                                @endforeach


                                @php
                                    $bischeck=App\Helpers\UserHelper::bis();
                                @endphp

                                @foreach($bischeck as $bischeckroot)

                                    <option value="{{$bischeckroot->portion_of_problem}}"  value="{{$bischeckroot->portion_of_problem}}" >{{$bischeckroot->portion_of_problem}}</option>

                                @endforeach


                            </select>
                            @if($errors->has('portion_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('portion_of_problem')}}</div>
                            @endif
                        </div>
                    </div>



                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">further_action</label>
                            <input type="text" name="further_action" class="form-control" id="service" value="{{old('further_action')?old('further_action'):$servicerequest->further_action}}" >
                            @if($errors->has('further_action'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('further_action')}}</div>
                            @endif
                        </div>
                    </div>
                    <!--<div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload PO</label>
                            <div class="custom-file">
                                <input type="file" name="po_upload" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                            <h6>upload pdf file</h6>
                        </div>
                    </div>-->


                </div><!-- /row -->
                <input type="hidden" name="id" value="{{$servicerequest->id}}">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Edit</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>
            <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="{{URL::asset('public/assets/download/sampleexcel.xlsx')}}">Sample excel File</a></div>
        </div>
    </div>



@endsection
@section('after_script')

    <!-- Optional JS -->
    {{--<script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>--}}
    <script src="{{URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/machine-serial-list-show") }}',

                type: 'POST',

                data: {model:model,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-model-list-show") }}',

                type: 'POST',

                data: {commodel:commodel,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-serial-list-show") }}',

                type: 'POST',

                data: {coserial:coserial,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });

    </script>



@endsection

