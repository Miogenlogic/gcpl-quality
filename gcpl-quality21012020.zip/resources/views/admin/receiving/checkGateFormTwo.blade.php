@extends('admin.include.layout')
<!-- Project List -->

@section('head')
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Receiving statistics</h6>
                    <!-- <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                        <li class="breadcrumb-item"><a href="../branch-office/index.html"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Default</li>
                      </ol>
                    </nav> -->
                </div>
            </div>

            <!-- Card stats -->
            <div class="row">

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">service requests received</h5>
                                    <span class="h2 font-weight-bold mb-0">20,456</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                        <i class="ni ni-briefcase-24"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Total checkgate filled</h5>
                                    <span class="h2 font-weight-bold mb-0">2,356</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                        <i class="ni ni-delivery-fast"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 1.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Awaiting to be filled</h5>
                                    <span class="h2 font-weight-bold mb-0">924</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                        <i class="ni ni-bullet-list-67"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-danger mr-2"><i class="fa fa-arrow-down"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection


@section('body')

    @php
       // $checkjob=App\Helpers\UserHelper::checkgatejobtypetwo();
        $question=App\Helpers\UserHelper::checkgatequestiontwo();
    @endphp

    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Inspection After Receiving at CRC</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">

            <!-- Pre-populated information -->
            <div class="row">
                <div class="col-md-6">
                    <div class="prepopulated-data">
                        <ul>
                            <li>Customer: <span>{{$checkgate->customer}}</span></li>
                            <li>Job number: <span>{{$checkgate->job_no}}</span></li>
                            <li>Branch name: <span>{{$checkgate->branch_name}}</span></li>
                            <li>Component Serial number: <span>{{$checkgate->component_serial_no}}</span></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="prepopulated-data">
                        <ul>
                            <li>AR number: <span>{{$checkgate->ar_no}}</span></li>
                            <li>Model number: <span>{{$checkgate->model_no}}</span></li>
                            <li>Components name: <span>{{$checkgate->component_name}}</span></li>
                            <li>Components receiving date: <span>{{$checkgate->date}}</span></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Pre-populated informations -->

            <hr>
            <h3 class="font-weight-500">Select file type</h3>
            <form method="post" action="{{url('admin/check-gate-form-two-add-save')}}" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-4">
                        <div class="very-own-radio">
                            <input type="radio" id="control_01" name="serviceType" value="1">
                            <label class="marc" for="control_01">
                                <h2>MARC</h2>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="very-own-radio">
                            <input type="radio" id="control_02" name="serviceType" value="2">
                            <label class="revenue" for="control_02">
                                <h2>Revenue</h2>
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="very-own-radio">
                            <input type="radio" id="control_03" name="serviceType" value="5">
                            <label class="warrenty" for="control_03">
                                <h2>Warranty</h2>
                            </label>
                        </div>
                    </div>
                </div>


                <!-- List group -->
                <ul class="list-group list-group-flush list mb-3 hard-to-choose">
                    @php
                        $i=0;
                    @endphp
                    @foreach($question as $qes)
                        <li class="list-group-item px-0">
                            <div class="row align-items-center">
                                <div class="col-7"><h4 class="mb-0">{{$qes->inspection_criteria}}</h4></div>
                                <div class="col-2">
                                    <input type="hidden" name="question[{{$i}}]" value="{{$qes->inspection_criteria}}">
                                    <div class="custom-control custom-control-inline custom-radio">
                                        <input name="answer[{{$i}}]" class="custom-control-input" id="yes{{$qes->id}}" type="radio" value="yes">
                                        <label class="custom-control-label" for="yes{{$qes->id}}">Yes</label>
                                    </div>
                                    <div class="custom-control custom-control-inline custom-radio">
                                        <input name="answer[{{$i}}]" class="custom-control-input" id="no{{$qes->id}}" type="radio" value="no">
                                        <label class="custom-control-label" for="no{{$qes->id}}">No</label>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <input type="text" name="remark[{{$i}}]" class="form-control" id="" placeholder="Remarks">
                                </div>
                            </div>
                        </li>
                        @php
                            $i++;
                        @endphp
                    @endforeach


                </ul>
                <input type="hidden" name="id" value="{{$checkgate->id}}">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Submit</button>
                <button class="btn btn-warning" type="reset">Reset form</button>

            </form>
        </div>
    </div>



@endsection

@section('after_script')

    <!-- Optional JS -->
    <script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>

    <script type="text/javascript">



    </script>



@endsection
