@extends('admin.include.layout')
<!-- Project List -->

@section('after_styles')
    <link rel="stylesheet" href="{{URL::asset('public/assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">
@endsection

@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Service request statistics</h6>
                    <!-- <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                        <li class="breadcrumb-item"><a href="../branch-office/index.html"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Default</li>
                      </ol>
                    </nav> -->
                </div>
            </div>

            <!-- Card stats -->
            <div class="row">

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Total service requests</h5>
                                    <span class="h2 font-weight-bold mb-0">350,897</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-default text-white rounded-circle shadow">
                                        <i class="ni ni-briefcase-24"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Total quotation received</h5>
                                    <span class="h2 font-weight-bold mb-0">2,356</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                        <i class="ni ni-chart-pie-35"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 1.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Ongoing service requests</h5>
                                    <span class="h2 font-weight-bold mb-0">924</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                        <i class="ni ni-settings-gear-65"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-danger mr-2"><i class="fa fa-arrow-down"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


@endsection
@section('body')
    @php
        //print_r($checkgateone->checkgate1_image);exit;
        $question=App\Helpers\UserHelper::checkgatequestion();
    @endphp

    @php
        $i=0;
    @endphp
    <form method="post" action="{{url('admin/check-gate-form-one-edit-save')}}" enctype="multipart/form-data">
        @foreach( $question as $comm)

            @php
                $check=array_search($comm->inspection_criteria,$checkgateonelist->question);
            @endphp

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-7"><h4 class="mb-0">{{$comm->inspection_criteria}}</h4></div>
                    <div class="col-2">
                        <input type="hidden" name="question[{{$i}}]" value="{{$comm->inspection_criteria}}">
                        <div class="custom-control custom-control-inline custom-radio">
                            <input name="answer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{$checkgateonelist->answer[$check]=='yes'?'checked':''}} >
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio">
                            <input name="answer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no" {{$checkgateonelist->answer[$check]=='no'?'checked':''}} >
                            <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                        </div>
                    </div>
                    <div class="col-3">
                        <input type="text" name="remark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{$checkgateonelist->remark[$check]}}">
                    </div>
                </div>
            </li>

            @php
                $i++;
            @endphp
        @endforeach
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="question">Image Upload</label>
                    <input type="file" class="form-control" id="" placeholder="" name="checkgate1_image[]" multiple>

                    @if($checkgateone['checkgate1_image']!='')
                        <img src="{{asset('public/assets/uploads/checkgate1Image').'/'.$checkgateone->checkgate1_image}}"  style="width:100px;height:100px;margin-top: 10px;">
                        <input type="checkbox" value="remove" name="img_rem"> Remove Image
                    @endif
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="question">Transporter Copy</label>
                    <input type="file" class="form-control" id="" placeholder="" name="transporter_Copy" multiple>

                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="question">Challan</label>
                    <input type="file" class="form-control" id="" placeholder="" name="challan" multiple>

                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="question">Gate Pass</label>
                    <input type="file" class="form-control" id="" placeholder="" name="gate_Pass" multiple>

                </div>
            </div>
        </div>

        <input type="hidden" name="id" value="{{$checkgateone->id}}">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <button class="btn btn-primary" type="submit">Submit</button>
        <button class="btn btn-warning" type="reset">Reset form</button>
    </form>
@endsection

