Dear Sir,<br>

A new service is created.<br>
New service no is {{$serviceno}}<br>

Here is  your Link For new Service -<a href="{{$url}}">Click it</a>

<br>
Thanks,