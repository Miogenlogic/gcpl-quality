Dear Sir,<br>

A new Quotation is created.<br>


Here is  your Link For new Quotation -<a href="{{$url}}">Click it</a>

<br>
Thanks,