@extends('admin.include.layout')
<!-- Project List -->

@section('head')
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">PDI CheckList</h6>
                    <!-- <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                        <li class="breadcrumb-item"><a href="../branch-office/index.html"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Default</li>
                      </ol>
                    </nav> -->
                </div>
            </div>

            <!-- Card stats -->
            <div class="row">

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">service requests received</h5>
                                    <span class="h2 font-weight-bold mb-0">20,456</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                        <i class="ni ni-briefcase-24"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Total checkgate filled</h5>
                                    <span class="h2 font-weight-bold mb-0">2,356</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                        <i class="ni ni-delivery-fast"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 1.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="card card-stats">
                        <!-- Card body -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Awaiting to be filled</h5>
                                    <span class="h2 font-weight-bold mb-0">924</span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                        <i class="ni ni-bullet-list-67"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-sm">
                                <span class="text-danger mr-2"><i class="fa fa-arrow-down"></i> 3.48%</span>
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection


@section('body')

    <li class="list-group-item px-0">
        <div class="row align-items-center">
            <div class="col-4">
                <h3>Engine</h3>
                <h3>VISUAL INSPECTION</h3>
            </div>

        </div>
    </li>
    @php
        $pdienginevisual=App\Helpers\UserHelper::pdichecksheet();

    @endphp
    @php
        $i=0;
    @endphp
    <form method="post" action="{{url('admin/pdi-edit-save')}}" enctype="multipart/form-data">

        @foreach( $pdienginevisual as $comm)

            @php
               $chk=array_search($comm->engine_visual_area	, $pdichecksheetlist->engvisarea);
           //echo '<pre>';//print_r($pdichecksheetlist);
            //exit();

            @endphp

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-2"><h4 class="mb-0" >{{$comm->engine_visual_area}}</h4></div>

                    <div class="col-2" >
                        <input type="hidden" name="engvisarea[{{$i}}]"  value="{{$comm->engine_visual_area}}">
                        <div class="col-5"><h4 class="mb-0">{{$comm->engine_visual_description}}</h4></div>

                            <input type="hidden" name="engvisarea[{{$i}}]"  value="{{$comm->engine_visual_description}}">




                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->engvisanswer[$chk]=='yes'?'checked':''}}>
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->engvisanswer[$chk]=='no'?'checked':''}}>
                            <label class="custom-control-label" for="no{{$comm->id}}" >No</label>
                        </div>

                    </div>
                    <div class="col-3" >
                        <input type="text" name="engvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->engvisremark[$chk]}}">
                    </div>
                </div>


            </li>

            @php
                $i++;
            @endphp
        @endforeach
        <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>FLUID LEVELS</h3>

                </div>
        @php
            $i=0;
        @endphp


        @foreach( $pdienginevisual as $comm)

            @php
             //  echo "<pre>";
               //print_r($comm->engine_fluid_area);
               //print_r($pdichecksheetlist->engdurarea);

               //exit();
                   $chk=array_search($comm->engine_fluid_area	, $pdichecksheetlist->engfluarea);

            @endphp
            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-7"><h4 class="mb-0" >{{$comm->engine_fluid_area}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfluarea[{{$i}}]"  value="{{$comm->engine_fluid_area}}">

                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->engfluanswer[$chk]=='yes'?'checked':''}}>
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->engfluanswer[$chk]=='no'?'checked':''}}>
                            <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                        </div>
                    </div>
                    <div class="col-3" >
                        <input type="text" name="engfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->engfluremark[$chk]}}">
                    </div>
                </div>

                <div class="col-7"><h4 class="mb-0" >{{$comm->engine_fluid_description}}</h4></div>
                <div class="col-2" >
                    <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->engine_fluid_description}}">
                </div>

            </li>
            @php
                $i++;
            @endphp
        @endforeach



        <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>DURING OPERATION</h3>
                </div>
        @php
            $i=0;
        @endphp
            @foreach( $pdienginevisual as $comm)
                @php
            //echo"<pre>";
          //  print_r($comm->engine_during_area);
          //  print_r($pdichecksheetlist->engdurarea);

            //exit();
                $chk=array_search($comm->engine_during_area	, $pdichecksheetlist->engdurarea);

            @endphp
            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-7"><h4 class="mb-0" >{{$comm->engine_during_area}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engdurarea[{{$i}}]"  value="{{$comm->engine_during_area}}">

                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->engduranswer[$chk]=='yes'?'checked':''}}>
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->engduranswer[$chk]=='no'?'checked':''}}>
                            <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                        </div>
                    </div>
                    <div class="col-3" >
                        <input type="text" name="engdurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->engdurremark[$chk]}}">
                    </div>
                </div>

                <div class="col-7"><h4 class="mb-0" >{{$comm->engine_during_description}}</h4></div>
                <div class="col-2" >
                    <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->engine_during_description}}">
                </div>
            </li>
            @php
                $i++;
            @endphp

            @endforeach

        <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>AFTER OPERATION</h3>

                </div>
        @php
            $i=0;
        @endphp
            @foreach( $pdienginevisual as $comm)
                @if(!empty($qes->engine_after_area))
                @php
                   // $engaftarea = (array) $pdichecksheetlist->engaftarea;
                     //     $chk=array_search($comm->engine_after_area, $engaftarea);
                     //  echo"<pre>";
                   // print_r($pdichecksheetlist);
                   // exit();
                   $chk=array_search($comm->engine_after_area, $pdichecksheetlist->engaftarea);
                    //echo"<pre>";
                    //print_r($pdichecksheetlist);
                    //exit();

            @endphp
            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-7"><h4 class="mb-0" >{{$comm->engine_after_area}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engaftarea[{{$i}}]"  value="{{$comm->engine_after_area}}">

                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->engaftanswer[$chk]=='yes'?'checked':''}}>
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="engaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->engaftanswer[$chk]=='no'?'checked':''}}>
                            <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                        </div>
                    </div>
                    <div class="col-3" >
                        <input type="text" name="engaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->engaftremark[$chk]}}">
                    </div>
                </div>

                <div class="col-7"><h4 class="mb-0" >{{$comm->engine_after_description}}</h4></div>
                <div class="col-2" >
                    <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->engine_after_description}}">
                </div>

            </li>
                @endif
            @php
                $i++;
            @endphp
        @endforeach


        <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>POWER TRAIN</h3>
                    <h3>VISUAL INSPECTION</h3>

                </div>
        @php
            $i=0;
        @endphp


        @foreach( $pdienginevisual as $comm)

            @php

                $chk=array_search($comm->powertrain_visual_area	, $pdichecksheetlist->powvisarea);

            @endphp
            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_visual_area}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="powvisarea[{{$i}}]"  value="{{$comm->powertrain_visual_area}}">

                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="powvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->powvisanswer[$chk]=='yes'?'checked':''}}>
                            <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                        </div>
                        <div class="custom-control custom-control-inline custom-radio" >
                            <input name="powvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->powvisanswer[$chk]=='no'?'checked':''}}>
                            <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                        </div>
                    </div>
                    <div class="col-3" >
                        <input type="text" name="powvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->powvisremark[$chk]}}">
                    </div>
                </div>

                <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_visual_description}}</h4></div>
                <div class="col-2" >
                    <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->powertrain_visual_description}}">
                </div>

            </li>
            @php
                $i++;
            @endphp
        @endforeach

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)
                @php
                  //  $powfluarea = (array) $pdichecksheetlist->powfluarea;
                    //  $chk=array_search($comm->powertrain_fluid_area, $powfluarea);
                 $chk=array_search($comm->powertrain_fluid_area	, $pdichecksheetlist->powfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="powfluarea[{{$i}}]"  value="{{$comm->powertrain_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->powvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->powvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="powfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->powfluremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_fluid_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="powdurdis[{{$i}}]"  value="{{$comm->powertrain_fluid_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>DURING OPERATION</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    $chk=array_search($comm->powertrain_during_area	, $pdichecksheetlist->powdurarea);
                      // $powdurarea = (array) $pdichecksheetlist->powdurarea;
                       //$chk=array_search($comm->powertrain_during_area, $powdurarea);

                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_during_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="powdurarea[{{$i}}]"  value="{{$comm->powertrain_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->powduranswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->powduranswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="powdurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{$pdichecksheetlist->powdurremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_during_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->powertrain_during_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                   // $powaftarea = (array) $pdichecksheetlist->powaftarea;
                    $chk=array_search($comm->powertrain_after_area, $pdichecksheetlist->powaftarea);



                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="powaftarea[{{$i}}]"  value="{{$comm->powertrain_after_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->powaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="powaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->powaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="powaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->powaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->powertrain_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->powertrain_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>STEERING </h3>
                        <h3>VISUAL INSPECTION</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                   // $stevisarea = (array) $pdichecksheetlist->stevisarea;
                     $chk=array_search($comm->steering_visual_area, $pdichecksheetlist->stevisarea);


                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->steering_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="stevisarea[{{$i}}]"  value="{{$comm->steering_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="stevisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes"{{ $pdichecksheetlist->stevisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="stevisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->stevisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="stevisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{  $pdichecksheetlist->stevisremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->steering_visual_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->steering_visual_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach



            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS </h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                   // $stefluarea = (array) $pdichecksheetlist->stefluarea;
                    $chk=array_search($comm->steering_fluid_area, $pdichecksheetlist->stefluarea);


                   // $chk=array_search($comm->steering_fluid_area ,$pdichecksheetlist->stefluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->steering_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="stefluarea[{{$i}}]"  value="{{$comm->steering_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="stefluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->stefluanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="stefluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{  $pdichecksheetlist->stefluanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="stefluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->stefluremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->steering_fluid_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->steering_fluid_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach




            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>DURING OPERATION </h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                                      // $stedurarea = (array) $pdichecksheetlist->stedurarea;
                   $chk=array_search($comm->steering_during_area,$pdichecksheetlist->stedurarea);




                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->steering_during_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="stedurarea[{{$i}}]"  value="{{$comm->steering_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="steduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{   $pdichecksheetlist->steduranswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="steduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{  $pdichecksheetlist->steduranswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="stedurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{$pdichecksheetlist->stedurremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->steering_during_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->steering_during_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION </h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                   // $steaftarea = (array) $pdichecksheetlist->steaftarea;
                    $chk=array_search($comm->steering_after_area, $pdichecksheetlist->steaftarea);


                   // $chk=array_search($comm->steering_after_area ,$pdichecksheetlist->steaftarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->steering_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="steaftarea[{{$i}}]"  value="{{$comm->steering_after_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="steaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->steaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="steaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{  $pdichecksheetlist->steaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="steaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->steaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->steering_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->steering_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>CHASIS & UNDERCARRIAGE
                            VISUAL INSPECTION</h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                    //$chasvisarea = (array) $pdichecksheetlist->chasvisarea;
                  //  $chk=array_search($comm->chasisundercrg_visual_area, $chasvisarea);

                    $chk=array_search($comm->chasisundercrg_visual_area ,$pdichecksheetlist->chasvisarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="chasvisarea[{{$i}}]"  value="{{$comm->chasisundercrg_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="chasvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes"  {{ $pdichecksheetlist->chasvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="chasvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->chasvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="chasvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->chasvisremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_visual_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->chasisundercrg_visual_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach



            <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>FLUID LEVELS</h3>

                </div>
                @php
                    $i=0;
                @endphp
                @foreach( $pdienginevisual as $comm)

                    @php

                        //$chasfluarea = (array) $pdichecksheetlist->chasfluarea;
                      //  $chk=array_search($comm->steering_fluid_area,  $chasfluarea);


                        $chk=array_search($comm->chasisundercrg_fluid_area ,$pdichecksheetlist->chasfluarea);
                    @endphp
                    <li class="list-group-item px-0">
                        <div class="row align-items-center">
                            <div class="col-7"><h4 class="mb-0" >{{$comm->steering_fluid_area}}</h4></div>
                            <div class="col-2" >
                                <input type="hidden" name="chasfluarea[{{$i}}]"  value="{{$comm->chasisundercrg_fluid_area}}">

                                <div class="custom-control custom-control-inline custom-radio" >
                                    <input name="chasfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->chasfluanswer[$chk]=='yes'?'checked':''}}>
                                    <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                                </div>
                                <div class="custom-control custom-control-inline custom-radio" >
                                    <input name="chasfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{$pdichecksheetlist->chasfluanswer[$chk]=='no'?'checked':''}}>
                                    <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                                </div>
                            </div>
                            <div class="col-3" >
                                <input type="text" name="chasfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->chasfluremark[$chk]}}">
                            </div>
                        </div>

                        <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_fluid_description}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->chasisundercrg_fluid_description}}">
                        </div>

                    </li>
                    @php
                        $i++;
                    @endphp
                @endforeach


           <li class="list-group-item px-0">
            <div class="row align-items-center">
                <div class="col-4">
                    <h3>DURING OPERATION</h3>

                </div>
                @php
                    $i=0;
                @endphp
                @foreach( $pdienginevisual as $comm)

                    @php

                        //$chasdurarea = (array) $pdichecksheetlist->chasdurarea;
                       // $chk=array_search($comm->chasisundercrg_during_area,  $chasdurarea);


                       $chk=array_search($comm->chasisundercrg_during_area ,$pdichecksheetlist->chasdurarea);
                    @endphp
                    <li class="list-group-item px-0">
                        <div class="row align-items-center">
                            <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_during_area}}</h4></div>
                            <div class="col-2" >
                                <input type="hidden" name="chasdurarea[{{$i}}]"  value="{{$comm->chasisundercrg_during_area}}">

                                <div class="custom-control custom-control-inline custom-radio" >
                                    <input name="chasduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->chasduranswer[$chk]=='yes'?'checked':''}}>
                                    <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                                </div>
                                <div class="custom-control custom-control-inline custom-radio" >
                                    <input name="chasduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->chasduranswer[$chk]=='no'?'checked':''}}>
                                    <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                                </div>
                            </div>
                            <div class="col-3" >
                                <input type="text" name="chasdurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->chasdurremark[$chk]}}">
        </div>
    </div>

    <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_during_description}}</h4></div>
    <div class="col-2" >
                                <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->chasisundercrg_during_description}}">
                            </div>

                    </li>
                    @php
                        $i++;
                    @endphp
                @endforeach
            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                    // $chasdurarea = (array) $pdichecksheetlist->chasdurarea;
                    // $chk=array_search($comm->chasisundercrg_after_area,  $chasdurarea);

                      $chk=array_search($comm->chasisundercrg_after_area ,$pdichecksheetlist->chasdurarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="chasaftarea[{{$i}}]"  value="{{$comm->chasisundercrg_after_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="chasaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->chasaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="chasaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no" {{ $pdichecksheetlist->chasaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="chasaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->chasaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->chasisundercrg_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->chasisundercrg_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>HYDRAULIC</h3>
                        <h3>VISUAL INSPECTION</h3>

                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$hydvisarea = (array) $pdichecksheetlist->hydvisarea;
                    //$chk=array_search($comm->hydraulic_visual_area,  $hydvisarea);

                   $chk=array_search($comm->hydraulic_visual_area ,$pdichecksheetlist->hydvisarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="hydvisarea[{{$i}}]"  value="{{$comm->hydraulic_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->hydvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{  $pdichecksheetlist->hydvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="hydvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->hydvisremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_visual_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->hydraulic_visual_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS</h3>


                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php

                  //  $hydfluarea = (array) $pdichecksheetlist->hydfluarea;
                    //    $chk=array_search($comm->hydraulic_fluid_area,  $hydfluarea);

                        $chk=array_search($comm->hydraulic_fluid_area ,$pdichecksheetlist->hydfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="hydfluarea[{{$i}}]"  value="{{$comm->hydraulic_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->hydfluanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->hydfluanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="hydfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{  $pdichecksheetlist->hydfluremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_fluid_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->hydraulic_fluid_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>DURING OPERATION</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)
                @php
                   // $hyddurarea = (array) $pdichecksheetlist->hyddurarea;
                    $chk=array_search($comm->hydraulic_during_area,  $pdichecksheetlist->hyddurarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_during_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="hyddurarea[{{$i}}]"  value="{{$comm->hydraulic_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->hydduranswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->hydduranswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="hyddurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{  $pdichecksheetlist->hyddurremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_during_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->hydraulic_during_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>


                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$hydaftarea = (array) $pdichecksheetlist->hydaftarea;
                   // $chk=array_search($comm->hydraulic_after_area,  $hydaftarea);

                   $chk=array_search($comm->hydraulic_after_area ,$pdichecksheetlist->hydaftarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="hydaftarea[{{$i}}]"  value="{{$comm->hydraulic_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->hydaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="hydaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"   {{ $pdichecksheetlist->hydaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="hydaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->hydaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->hydraulic_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->hydraulic_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach



            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>CAB OR CANOPY</h3>
                        <h3>VISUAL INSPECTION</h3>


                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)
                @php
                  //  $cabvisarea = (array) $pdichecksheetlist->cabvisarea;
                    $chk=array_search($comm->cab_visual_area,  $pdichecksheetlist->cabvisarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->cab_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="cabvisarea[{{$i}}]"  value="{{$comm->cab_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->cabvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->cabvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="cabvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->cabvisremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->cab_visual_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->cab_visual_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach




            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS</h3>
                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)
                @php
                   // $cabfluarea = (array) $pdichecksheetlist->cabfluarea;
                    //$chk=array_search($comm->cab_fluid_area,  $cabfluarea);

                   $chk=array_search($comm->cab_fluid_area ,$pdichecksheetlist->cabfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->cab_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="cabfluarea[{{$i}}]"  value="{{$comm->cab_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->cabfluanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->cabfluanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="cabfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->cabfluremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->cab_fluid_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->cab_fluid_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach




            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>DURING OPERATION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$cabdurarea = (array) $pdichecksheetlist->cabdurarea;
                   // $chk=array_search($comm->cab_during_area,  $cabdurarea);
                   $chk=array_search($comm->cab_during_area ,$pdichecksheetlist->cabdurarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->cab_during_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="cabdurarea[{{$i}}]"  value="{{$comm->cab_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->cabduranswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->cabduranswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="cabdurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->cabdurremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->cab_during_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->cab_during_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach




            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                 //   $cabaftarea = (array) $pdichecksheetlist->cabaftarea;
                   // $chk=array_search($comm->cab_after_area,  $cabaftarea);

                    $chk=array_search($comm->cab_after_area ,$pdichecksheetlist->cabfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->cab_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="cabaftarea[{{$i}}]"  value="{{$comm->cab_after_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->cabaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="cabaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->cabaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="cabaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->cabaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->cab_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->cab_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>MISC. & ATTACHMENTS</h3>
                        <h3>VISUAL INSPECTION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                  //  $misvisarea = (array) $pdichecksheetlist->misvisarea;
                    //$chk=array_search($comm->miscattach_visual_area,  $misvisarea);
                   $chk=array_search($comm->miscattach_visual_area ,$pdichecksheetlist->misvisarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="misvisarea[{{$i}}]"  value="{{$comm->miscattach_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes"{{ $pdichecksheetlist->misvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->misvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="misvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->misvisremark[$chk]}}">
        </div>
    </div>

    <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_visual_description}}</h4></div>
    <div class="col-2" >
        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->miscattach_visual_description}}">
    </div>

</li>
@php
$i++;
@endphp
@endforeach

            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$misfluarea = (array) $pdichecksheetlist->misfluarea;
                    //$chk=array_search($comm->miscattach_fluid_area,  $misfluarea);
                   $chk=array_search($comm->miscattach_fluid_area ,$pdichecksheetlist->misfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="misfluarea[{{$i}}]"  value="{{$comm->miscattach_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{  $pdichecksheetlist->misfluanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no" {{ $pdichecksheetlist->misfluanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="misfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->misfluremark[$chk]}}">
        </div>
    </div>

    <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_fluid_description}}</h4></div>
    <div class="col-2" >
                            <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->miscattach_fluid_description}}">
                        </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach



            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                   // $misaftarea = (array) $pdichecksheetlist->misaftarea;
                    //$chk=array_search($comm->miscattach_after_area,  $misaftarea);
                   $chk=array_search($comm->miscattach_after_area ,$pdichecksheetlist->misaftarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="misaftarea[{{$i}}]"  value="{{$comm->miscattach_fluid_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->misaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="misaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->misaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="misaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->misaftremark[$chk]}}">
        </div>
    </div>

    <div class="col-7"><h4 class="mb-0" >{{$comm->miscattach_after_description}}</h4></div>
    <div class="col-2" >
                            <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->miscattach_after_description}}">
                        </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>IMPLEMENTS</h3>
                        <h3>VISUAL INSPECTION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$impvisarea = (array) $pdichecksheetlist->impvisarea;
                   // $chk=array_search($comm->implement_visual_area,  $impvisarea);
                    $chk=array_search($comm->implement_visual_area ,$pdichecksheetlist->impvisarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->implement_visual_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="impvisarea[{{$i}}]"  value="{{$comm->implement_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impvisanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->impvisanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impvisanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->impvisanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="impvisremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{  $pdichecksheetlist->impvisremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->implement_visual_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->implement_visual_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach



            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>FLUID LEVELS</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                   // $impfluarea = (array) $pdichecksheetlist->impfluarea;
                    //$chk=array_search($comm->implement_fluid_area,  $impfluarea);
                   $chk=array_search($comm->implement_fluid_area ,$pdichecksheetlist->impfluarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->implement_fluid_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="impfluarea[{{$i}}]"  value="{{$comm->implement_visual_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impfluanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->impfluanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impfluanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->impfluanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="impfluremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->impfluremark[$chk]}}">
        </div>
    </div>

    <div class="col-7"><h4 class="mb-0" >{{$comm->implement_fluid_description}}</h4></div>
    <div class="col-2" >
                            <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->implement_fluid_description}}">
                        </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>DURING OPERATION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$impdurarea = (array) $pdichecksheetlist->impdurarea;
                   // $chk=array_search($comm->implement_during_area,  $impdurarea);
                    $chk=array_search($comm->implement_during_area ,$pdichecksheetlist->impdurarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->implement_during_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="impdurarea[{{$i}}]"  value="{{$comm->implement_during_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impduranswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->impduranswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impduranswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->impduranswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="impdurremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->impdurremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->implement_during_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->implement_during_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <li class="list-group-item px-0">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h3>AFTER OPERATION</h3>



                    </div>
            @php
                $i=0;
            @endphp
            @foreach( $pdienginevisual as $comm)

                @php
                    //$impaftarea = (array) $pdichecksheetlist->impaftarea;
                    //$chk=array_search($comm->implement_after_area,  $impaftarea);
                   $chk=array_search($comm->implement_after_area ,$pdichecksheetlist->impaftarea);
                @endphp
                <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-7"><h4 class="mb-0" >{{$comm->implement_after_area}}</h4></div>
                        <div class="col-2" >
                            <input type="hidden" name="impaftarea[{{$i}}]"  value="{{$comm->implement_after_area}}">

                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impaftanswer[{{$i}}]" class="custom-control-input" id="yes{{$comm->id}}" type="radio" value="yes" {{ $pdichecksheetlist->impaftanswer[$chk]=='yes'?'checked':''}}>
                                <label class="custom-control-label" for="yes{{$comm->id}}">Yes</label>
                            </div>
                            <div class="custom-control custom-control-inline custom-radio" >
                                <input name="impaftanswer[{{$i}}]" class="custom-control-input" id="no{{$comm->id}}" type="radio" value="no"  {{ $pdichecksheetlist->impaftanswer[$chk]=='no'?'checked':''}}>
                                <label class="custom-control-label" for="no{{$comm->id}}">No</label>
                            </div>
                        </div>
                        <div class="col-3" >
                            <input type="text" name="impaftremark[{{$i}}]" class="form-control" id="" placeholder="Remarks" value="{{ $pdichecksheetlist->impaftremark[$chk]}}">
                        </div>
                    </div>

                    <div class="col-7"><h4 class="mb-0" >{{$comm->implement_after_description}}</h4></div>
                    <div class="col-2" >
                        <input type="hidden" name="engfludes[{{$i}}]"  value="{{$comm->implement_after_description}}">
                    </div>

                </li>
                @php
                    $i++;
                @endphp
            @endforeach


            <input type="hidden" name="id" value="{{$pdichecksheet->id}}">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <button class="btn btn-primary" type="submit">Submit</button>
        <button class="btn btn-warning" type="reset">Reset form</button>
    </form>
@endsection




