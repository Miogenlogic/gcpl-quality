<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CustomerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {
        return [


            'name'=> 'required',

            'customer_code'=> 'required',
            'address'=> 'required',
            'address2'=> 'required',
            'address3'=> 'required',
            'phone_no'=> 'required',
            'email'=> 'required',


        ];
    }


    public function messages()
    {
        return [

            'name'=> 'Field is required.',

            'customer_code'=> 'Field is required.',
            'address'=> 'Field is required.',
                'address2'=> 'Field is required.',
          'address3'=>  'Field is required.',
         'phone_no'=> 'Field is required.',
         'email'=> 'Field is required.',
        ];
    }
}
