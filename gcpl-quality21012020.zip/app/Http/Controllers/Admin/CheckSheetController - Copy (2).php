<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CheckGateQuestionEditRequest;
use App\Http\Requests\CheckGateQuestionRequest;

use App\Http\Requests\DisassmblyAggregateRequest;
use App\Models\MasterAggregate;
use App\Models\MasterCcinspectionExternalWashDetails;
use App\Models\MasterCcinspectionPartCleanDetails;
use App\Models\MasterCheckGate;
use App\Models\MasterCheckGateInspectionQuestion;
use App\Models\MasterCommercialValues;
use App\Models\MasterComponentDetails;
use App\Models\MasterListofSalvageDis;
use App\Models\MasterLoosepartDis;
use App\Models\MasterMCModel;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterMissingdamagePartDis;
use App\Models\MasterPartCamshaftValue;
use App\Models\MasterPartConnectingRodValues;
use App\Models\MasterPartCrankshaftValue;
use App\Models\MasterPartCylinderHeadValues;
use App\Models\MasterPartinspectionCylinderHeadDetails;
use App\Models\MasterPartOthercomponentValues;
use App\Models\MasterPartsInspectionCylinderHeadValues;
use App\Models\MasterPreHistoryDis;
use App\Models\Service;
use Illuminate\Http\Request;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;



use Carbon\Carbon;
use DB;
use Hash;
use File;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
class CheckSheetController extends Controller
{
//engine

    public function engineDissList()
    {


        return view('admin.checksheet.disassembly.engineDissList');
    }

    public function engineDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {
                if(isset($table->checkgate2) && strlen($table->checkgate2) > 1){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                            
                                                
                                          
                                                <a class="dropdown-item" href="'.url('admin/check-gate-form-two-listing')."/"."$table->id".'">Checkgate Two View</a>    
                                               
                                                
                                            </div>
                                        </div>';
                }else {
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add')."/"."$table->id". '">Checkgate Two Entry</a>
                                          
                                                
                                               
                                                
                                            </div>
                                        </div>';
                }
                return $btns;
                /*$btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                           <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add')."/"."$table->id". '">Checkgate Two Entry</a>
                                             <a class="dropdown-item" href="'.url('admin/check-gate-form-two-listing')."/"."$table->id".'">Checkgate Two View</a>    
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;*/
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

//trans
    public function transDissList()
    {


        return view('admin.checksheet.disassembly.transDissList');
    }

    public function transDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

//hyd
    public function hydDissList()
    {


        return view('admin.checksheet.disassembly.hydDissList');
    }

    public function hydDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }
//mor

    public function morDissList()
    {


        return view('admin.checksheet.disassembly.morDissList');
    }

    public function morDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }
//undercarraige
    public function undercargDissList()
    {


        return view('admin.checksheet.disassembly.undercarrigeDissList');
    }

    public function undercargDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    //super admin
    public function checkSheetEntryCommon($id)
    {
        $dept_id=1;

        $service = Service::find($id);
        // dd($service);exit;

        if(!empty($service)){

            //aggregation show

            $agrregate=MasterAggregate::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)->get()->first();
            //dd($agrregate);exit;
            $mcModel=MasterMCModel::find($service->machine_modelno);
            //$mcSerial=MasterMCSerialNumber::find($service['machine_serialno']);
            $mcSerial = Service::select('service_request.id','machine_serialno', 'gw_master_machine_serial_no.serial_no')
                ->leftjoin('gw_master_machine_serial_no','gw_master_machine_serial_no.id', '=', 'service_request.machine_serialno')
                ->where('service_request.id', '=' ,$id)->get();
            $componentSerial=MasterComponentDetails::find($service->component_serial_no);
            //dd($mcModel);
            //dd($mcSerial);
            // dd($componentSerial);
            //dd($service);


            // exit;
            /*if(isset($agrregate->id)) {



                /*
                $agrregate = Service::select('service_request.*', 'gw_master_mc_model.model_no','gw_master_mc_serial_number.serial_no','gw_master_comp_details.comp_serial_no')
                    ->join('gw_master_mc_model', 'gw_master_mc_model.id', '=', 'service_request.machine_modelno')
                    ->join('gw_master_mc_serial_number', 'gw_master_mc_serial_number.id', '=', 'service_request.machine_serialno')
                    ->join('gw_master_comp_details', 'gw_master_comp_details.id', '=', 'service_request.component_serial_no')
                    ->where('service_request.id', '=', $id)
                    ->get()->first();*/
            /*  }
              else{
                  $mcModel=Null;
                  $mcSerial=Null;
                  $componentSerial=Null;
              }*/

            //prehistory show
            $prehist=MasterPreHistoryDis::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)->get()->first();
            if(isset($prehist->id)) {
                $machSerial=MasterMCSerialNumber::find($service->machine_serialno);
                $comSerial=MasterComponentDetails::find($service->component_serial_no);

            }
            else{
                $machSerial=Null;
                $comSerial=Null;
            }

            //Commercial and logistics
            $commercialLogistic=MasterCommercialValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($commercialLogistic->id)){
                $commercialLogistic=json_decode($commercialLogistic->values);
            }else{
                $commercialLogistic=Null;
            }
//dd($commercialLogistic);exit;
            //ccinspection after external wash
            $externalWash=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($externalWash->id)){
                $externalWash=json_decode($externalWash->values);
            }else{
                $externalWash=Null;
            }

            //cc inspection after parts clean
            $partsClean=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($partsClean->id)){
                $partsClean=json_decode($partsClean->values);
            }else{
                $partsClean=Null;
            }

            //partsinspection cylinder head
            $cylinder=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($cylinder->id)){
                $cylinder=json_decode($cylinder->details);
            }else{
                $cylinder=Null;
            }

            //partinspection other component

            $showothercomp=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showothercomp->id)){
                $showothercomp=json_decode($showothercomp->values);
            }else{
                $showothercomp=Null;
            }

            //partsinspection connecting rod
            $showconrod=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showconrod->id)){
                $showconrod=json_decode($showconrod->values);
            }else{
                $showconrod=Null;
            }

            //partinspection cylinder block
            $showcylinderblock=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcylinderblock->id)){
                $showcylinderblock=json_decode($showcylinderblock->values);
            }else{
                $showcylinderblock=Null;
            }
            //$var = $showcylinderblock->frontcenter;
            if(isset($showcylinderblock->frontcenter)){
                $myArray = json_decode(json_encode($showcylinderblock->frontcenter), true);
            }
            else{
                $myArray=Null;
            }
            if(isset($showcylinderblock->frontresult)) {
                $frntreslt = json_decode(json_encode($showcylinderblock->frontresult), true);
            }else{
                $frntreslt=Null;
            }
            if(isset($showcylinderblock->mainfrontremarks)) {
                $frtmainrst = json_decode(json_encode($showcylinderblock->mainfrontremarks), true);
            }else{
                $frtmainrst=Null;
            }
            if(isset($showcylinderblock->centerresult)) {
                $rearcenteryes = json_decode(json_encode($showcylinderblock->centerresult), true);
            }else{
                $rearcenteryes=Null;
            }
            if(isset($showcylinderblock->rearresults)) {
                $rearresyes = json_decode(json_encode($showcylinderblock->rearresults), true);
            }else{
                $rearresyes=Null;
            }
            if(isset($showcylinderblock->rearresults)) {
                $rearremaryes = json_decode(json_encode($showcylinderblock->mainrearremarks), true);
            }else{
                $rearremaryes=Null;
            }

            //parts inspection crankshaft inspection
            $showcrankshaft=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcrankshaft->id)){
                $showcrankshaft=json_decode($showcrankshaft->values);
            }else{
                $showcrankshaft=Null;
            }

            //parts inspection camshaft inspection

            $showcamshaft=MasterPartCamshaftValue::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcamshaft->id)){
                $showcamshaft=json_decode($showcamshaft->values);
            }else{
                $showcamshaft=Null;
            }


            //missingdamagepart
            $showmissing_1=MasterMissingdamagePartDis::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get();
            //dd($showmissing_1);exit;
            if(isset($showmissing_1)){
                $showmissing=$showmissing_1;
                //dd($showmissing);exit;

            }else{
                $showmissing=Null;
                // echo "Rim";exit;
            }

            //list of salvage

            $showsalvage_1=MasterListofSalvageDis::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get();
            //dd($showmissing_1);exit;
            if(isset($showsalvage_1)){
                $showsalvage=$showsalvage_1;
                //dd($showmissing);exit;

            }else{
                $showsalvage=Null;
            }

            //loose parts
            $showloosepat_1=MasterLoosepartDis::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get();
            // dd($showloosepat_1);exit;
            if(isset($showloosepat_1)){
                $showloosepat=$showloosepat_1;
                //dd($showmissing);exit;

            }else{
                $showloosepat=Null;
            }



            return view('admin.include.checksheetCommon')
                ->with('service',$service)
                ->with('agrregate', $agrregate)
                ->with('mcModel', $mcModel)
                ->with('mcSerial', $mcSerial)
                ->with('componentSerial', $componentSerial)
                ->with('commercialLogistic',$commercialLogistic)
                ->with('prehist',$prehist)
                ->with('machSerial',$machSerial)
                ->with('comSerial',$comSerial)
                ->with('externalWash',$externalWash)
                ->with('partsClean',$partsClean)
                ->with('cylinder',$cylinder)
                ->with('showothercomp',$showothercomp)
                ->with('myArray',$myArray)
                ->with('showconrod',$showconrod)
                ->with('frntreslt',$frntreslt)
                ->with('frtmainrst',$frtmainrst)
                ->with('rearcenteryes',$rearcenteryes)
                ->with('rearresyes',$rearresyes)
                ->with('rearremaryes',$rearremaryes)
                ->with('showcrankshaft',$showcrankshaft)
                ->with('showcamshaft',$showcamshaft)
                ->with('showcylinderblock',$showcylinderblock)
                ->with('showmissing',$showmissing)
                ->with('showsalvage',$showsalvage)
                ->with('showloosepat',$showloosepat);


        }
        else{
            $service=Null;
            $agrregate=Null;
            $mcModel=Null;
            $mcSerial=Null;
            $componentSerial=Null;
            $commercialLogistic=Null;
            $prehist=Null;
            $machSerial=Null;
            $comSerial=Null;
            $externalWash=Null;
            $partsClean=Null;
            $cylinder=Null;
            $showothercomp=Null;
            $myArray=Null;
            $showconrod=Null;
            $frntreslt=Null;
            $rearcenteryes=Null;
            $rearresyes=Null;
            $rearremaryes=Null;
            $showcrankshaft=Null;
            $showcamshaft=Null;
            $showcylinderblock=Null;
            $frtmainrst=Null;

            return view('admin.include.checksheetCommon')
                ->with('service',$service)
                ->with('agrregate', $agrregate)
                ->with('mcModel', $mcModel)
                ->with('mcSerial', $mcSerial)
                ->with('componentSerial', $componentSerial)
                ->with('commercialLogistic',$commercialLogistic)
                ->with('prehist',$prehist)
                ->with('machSerial',$machSerial)
                ->with('comSerial',$comSerial)
                ->with('externalWash',$externalWash)
                ->with('partsClean',$partsClean)
                ->with('cylinder',$cylinder)
                ->with('showothercomp',$showothercomp)
                ->with('myArray',$myArray)
                ->with('showconrod',$showconrod)
                ->with('frntreslt',$frntreslt)
                ->with('frtmainrst',$frtmainrst)
                ->with('rearcenteryes',$rearcenteryes)
                ->with('rearresyes',$rearresyes)
                ->with('rearremaryes',$rearremaryes)
                ->with('showcrankshaft',$showcrankshaft)
                ->with('showcamshaft',$showcamshaft)
                ->with('showcylinderblock',$showcylinderblock);



        }
        //dd($frtmainrst);
        //echo '<pre>';print_r($myArray[3]);exit;
        //dd($showcylinderblock);exit;




    }


    public function checkGateAggregateSave(DisassmblyAggregateRequest $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        //echo $request['service_id'];exit;
        $service = Service::find($request['service_id']);
        // dd($service);
        $aggregate=MasterAggregate::where('service_request_id','=',$request['service_id'])
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset($aggregate->service_request_id)){
            //echo "rimpi";exit;
            $aggregate =new MasterAggregate();
        }

        $aggregate->service_request_id = $request['service_id'];
        $aggregate->dept_id = $request['dept_id'];
        $aggregate->aggr_type = $request['aggr_type'];
        // $aggregate->machine_modelno = $service->machine_modelno;
        // $aggregate->machine_serialno = $service->machine_serialno;
        $aggregate->arrangement_no = $request['arrangement_no'];
        // $aggregate->customer = $service->customer;
        $aggregate->customer_contact = $request['customer_contact'];
        // $aggregate->servicing_branch = $service->branch_name;
        $aggregate->branch_contact = $request['branch_contact'];
        $aggregate->crc_supervisor = $request['crc_supervisor'];
        $aggregate->crc_job_no = $request['crc_job_no'];
        $aggregate->branch_job_no = $request['branch_job_no'];
        $aggregate->date_arrival = $request['date_arrival'];
        $aggregate->date_dispatch = $request['date_dispatch'];
        $aggregate->machine_modelno = $request['machine_modelno'];
        $aggregate->machine_serialno = $request['machine_serialno'];
        $aggregate->customer = $request['customer'];
        $aggregate->servicing_branch = $request['servicing_branch'];

        $aggregate->save();


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    public function checkGatePreHisDisSave(Request $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $prehist=MasterPreHistoryDis::where('service_request_id','=',$request['service_id'])
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset($prehist->id)){
            $prehist =new MasterPreHistoryDis();
        }

        $prehist->service_request_id = $request['service_id'];
        $prehist->dept_id = $request['dept_id'];
        $prehist->repair_mode = $request['repair_mode'];
        $prehist->engine_serial_no = $request['engine_serial_no'];
        $prehist->engine_arrange_no =$request['engine_arrange_no'];
        $prehist->machine_type = $request['machine_type'];
        $prehist->machine_serial_no= $request['machine_serial_no'];
        $prehist->smu=$request['smu'];
        $prehist->no_of_overhauls_done=$request['no_of_overhauls_done'];
        $prehist->last_overhaul_smu=$request['last_overhaul_smu'];
        $prehist->failure_details=$request['failure_details'];
        $prehist->major_cylinder_head=$request['major_cylinder_head'];
        $prehist->major_injector=$request['major_injector'];
        $prehist->major_oil_pump=$request['major_oil_pump'];
        $prehist->major_fuel_injection_pump=$request['major_fuel_injection_pump'];
        $prehist->save();


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGateCommerciallogisticDisSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $cmmercial=MasterCommercialValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cmmercial)){
            $cmmercial =new MasterCommercialValues();
        }
        // if(isset($cmmercial->id))
        $commercial=$request->all();

        //$obj = new MasterCommercialValues();



        if(isset($service->id)) {
            $cmmercial->service_request_id = $service->id;
            $cmmercial->dept_id = $request['dept_id'];
            $cmmercial->values = json_encode($commercial);
            $cmmercial->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGateCcexternalwashDisSave(Request $request)
    {
        //$myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $externalwas=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($externalwas)){
            $externalwas =new MasterCcinspectionExternalWashDetails();
        }

        $exterwash=$request->all();

        // $obj = new MasterCcinspectionExternalWashDetails();

        if(isset($service->id)) {
            $externalwas->service_request_id = $service->id;
            $externalwas->dept_id = $request['dept_id'];
            $externalwas->values = json_encode($exterwash);
            $externalwas->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGateCcpartcleanDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $cleaning=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cleaning)){
            $cleaning =new MasterCcinspectionPartCleanDetails();
        }
        $partclean=$request->all();

        //$obj = new MasterCcinspectionPartCleanDetails();

        if(isset($service->id)) {
            $cleaning->service_request_id = $service->id;
            $cleaning->dept_id = $request['dept_id'];
            $cleaning->values = json_encode($partclean);
            $cleaning->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }


    public function checkGateLoosepartsDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        // $file=$request->file('photograph');
        $file=$request['part_description'];
        if(isset($service->id)){
            MasterLoosepartDis::where('service_request_id',$request['service_id'])->delete();
            foreach($file as $key=>$val){
                // echo'<pre>';print_r($val);echo'<pre>';
                //$obj->photograph=$request['photograph'];

                $txt= $val;
                /*  $imgfile = $val;


                  $save_imgfile = time(). $imgfile->getClientOriginalName();
                  $destinationPath = 'public/assets/uploads/engdisassembly/looseparts';
                  $imgfile->move($destinationPath, $save_imgfile);
                  //move_uploaded_file($val,$destinationPath.'/'.$save_imgfile);


                   $image = $save_imgfile;
*/
                //$obj->photograph = $image;
                /*if($file = $request->file('photograph')) {

                    $fileName = time().$file->getClientOriginalName() ;
                    $destinationPath = 'public/assets/uploads/engdisassembly/looseparts' ;
                    $file->move($destinationPath, $fileName);


                }die;*/

                $loosepart=new MasterLoosepartDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->part_description=$txt;
                $loosepart->qty=$request['qty'][$key];
                $loosepart->part_condition=$request['part_condition'][$key];
                $loosepart->photograph = Null ;
                $loosepart->save();

            }



        }

        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGateMissingdamagepartDisSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);
        /*$misingdam=MasterMissingdamagePartDis::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($misingdam)){
            $misingdam =new MasterMissingdamagePartDis();
        }*/

        $missing=$request['missing_damage'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            MasterMissingdamagePartDis::where('service_request_id',$request['service_id'])->delete();
            foreach ($missing as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $loosepart = new MasterMissingdamagePartDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->description = $request['description'][$key];
                $loosepart->qty = $request['qty'][$key];
                $loosepart->missing_damage = $txt;
                $loosepart->photo = $request['photo'][$key];
                $loosepart->damage_details = $request['damage_details'][$key];
                $loosepart->action_taken = $request['action_taken'][$key];


                $loosepart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGateListofsalvageDisSave(Request $request)
    {
        //$myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $salvage=$request['vendor_name'];



        if(isset($service->id)) {
            MasterListofSalvageDis::where('service_request_id',$request['service_id'])->delete();
            foreach ($salvage as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $loosepart = new MasterListofSalvageDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->component_name =$request['component_name'][$key];
                $loosepart->description = $request['description'][$key];
                $loosepart->qty = $request['qty'][$key];
                $loosepart->out_date = $request['out_date'][$key];
                $loosepart->in_date = $request['in_date'][$key];
                $loosepart->vendor_name = $txt;
                $loosepart->inspected_by = $request['inspected_by'][$key];


                $loosepart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGatePartinspectionCylinderheadDisSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new MasterPartsInspectionCylinderHeadValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->details = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGatePartinspectionOthercomponentDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partothercomp=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partothercomp)){
            $partothercomp =new MasterPartOthercomponentValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partothercomp->service_request_id = $service->id;
            $partothercomp->dept_id = $request['dept_id'];
            $partothercomp->values = json_encode($othercomp);
            $partothercomp->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    public function checkGatePartinspectionConnectingrodDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $connectingrod=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($connectingrod)){
            $connectingrod =new MasterPartConnectingRodValues();
        }
        $partconrod=$request->all();

        //$obj = new MasterCcinspectionPartCleanDetails();

        if(isset($service->id)) {
            $connectingrod->service_request_id = $service->id;
            $connectingrod->dept_id = $request['dept_id'];
            $connectingrod->values = json_encode($partconrod);
            $connectingrod->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }


    public function checkGatePartinspectionCylinderblockDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcylinderblock=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcylinderblock)){
            $partcylinderblock =new MasterPartCylinderHeadValues();
        }


        $cyblockdetails = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcylinderblock->service_request_id = $service->id;
            $partcylinderblock->dept_id = $request['dept_id'];
            $partcylinderblock->values = json_encode($cyblockdetails);
            $partcylinderblock->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    public function checkGatePartinspectionCrankshaftDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcrankshaft=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcrankshaft)){
            $partcrankshaft =new MasterPartCrankshaftValue();
        }


        $pcrankshaft = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcrankshaft->service_request_id = $service->id;
            $partcrankshaft->dept_id = $request['dept_id'];
            $partcrankshaft->values = json_encode($pcrankshaft);
            $partcrankshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }


    public function checkGatePartinspectionCamshaftDisSave(Request $request)
    {
        // $myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcamshaft=MasterPartCamshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcamshaft)){
            $partcamshaft =new MasterPartCamshaftValue();
        }


        $parcamshaftput = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcamshaft->service_request_id = $service->id;
            $partcamshaft->dept_id = $request['dept_id'];
            $partcamshaft->values = json_encode($parcamshaftput);
            $partcamshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

}
