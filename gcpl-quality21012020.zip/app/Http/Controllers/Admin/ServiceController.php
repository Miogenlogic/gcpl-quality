<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UserHelper;
use App\Http\Controllers\Controller;

use App\Http\Requests\BranchServiceRequest;
use App\Models\MasterAllComponentName;
use App\Models\MasterBranch;
use App\Models\MasterEngineModel;
use App\Models\MasterMachine;
use App\Models\MasterPreHistoryDis;
use App\Models\MasterSegment;
use App\Models\Service;
use App\Models\MasterMCModel;
use App\Models\MasterComponentDetails;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterCustomer;
use App\Models\MasterMachineModelNo;
use App\Models\Masterrole;
use App\Models\Menuaccess;
use App\Models\MasterStatus;
use App\Models\Menu;
use App\Models\MasterEmployee;
use Illuminate\Http\Request;
use App\Models\MasterDepartment;

use App\Models\MasterTask;
use App\Models\ProjectPlanMaster;
use App\Models\ProjectTask;
use App\Models\ProjectUser;
use App\Models\TaskUser;

use phpDocumentor\Reflection\Types\Collection;
use Rap2hpoutre\FastExcel\FastExcel;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;
use Box\Spout\Writer\Style\StyleBuilder;


use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use File;
use \PDF;
use Response;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
class ServiceController extends Controller
{
    public function test(){
        /*
        Role::create(['name' => 'super_admin']);
        Role::create(['name' => 'crc_head']);
        Role::create(['name' => 'spc']);
        Role::create(['name' => 'branch_engineer']);
        Role::create(['name' => 'section_supervisor']);
        Role::create(['name' => 'section_engineer']);
        Role::create(['name' => 'qa_qc']);
        Role::create(['name' => 'planning_supervisor']);
        Role::create(['name' => 'store_manager']);
        Role::create(['name' => 'despatch_manager']);

        Permission::create(['name' => 'edit articles']);

        A permission can be assigned to a role using 1 of these methods:

        $role->givePermissionTo($permission);
        $permission->assignRole($role);

        A permission can be removed from a role using 1 of these methods:

        $role->revokePermissionTo($permission);
        $permission->removeRole($role);

        // get a list of all permissions directly assigned to the user
        $permissionNames = $user->getPermissionNames(); // collection of name strings
        $permissions = $user->permissions; // collection of permission objects

        // get all permissions for the user, either directly, or from roles, or from both
        $permissions = $user->getDirectPermissions();
        $permissions = $user->getPermissionsViaRoles();
        $permissions = $user->getAllPermissions();

        // get the names of the user's roles
        $roles = $user->getRoleNames();

        $users = User::role('writer')->get(); // Returns only users with the role 'writer'

        $users = User::permission('edit articles')->get(); // Returns only users with the permission 'edit articles' (inherited or directly)

        $all_users_with_all_their_roles = User::with('roles')->get();
        $all_users_with_all_direct_permissions = User::with('permissions')->get();
        $all_roles_in_database = Role::all()->pluck('name');


        You can check if a user has Any of an array of permissions:

        $user->hasAnyPermission(['edit articles', 'publish articles', 'unpublish articles']);

        user has All of an array of permissions:

        $user->hasAllPermissions(['edit articles', 'publish articles', 'unpublish articles']);

        $user->can('edit articles');

        //Assign Role to User
        $user=User::find(1);
        $user->assignRole('super_admin');

        // Adding permissions to a user
        $user->givePermissionTo('edit articles');


        $user=User::find(1);
        $user->assignRole('super_admin');
        echo "Assign Role";


        $user=User::find(1);
        $user->removeRole('super_admin');
        echo "Delete Role";

        $user=User::find(11);
        $user->assignRole('receiving');
        echo "Assign Role";*/
        //Role::create(['name' => 'receiving']);

    }

    public function test3(){

        //echo "test 2";
        return view('admin.serviceengineer.transmissioncheckSheetEntry');

    }



//brunch engineeer

    public function branchDashboardListGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/listing/'.$table->id ) . '">Edit</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function serviceRequestList()
    {

        return view('admin.branchengineer.allserviceRequest');
    }

    public function serviceRequestGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/listing/'.$table->id ) . '">Edit</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function serviceRequestAdd()
    {
        $status = MasterStatus::select('gw_master_status.*')->get();
        $employee = MasterEmployee::select('gw_master_employee.*')->get();
        return view('admin.branchengineer.newserviceRequest')
            ->with('employee',$employee)
            ->with('status',$status);
    }

    public function serviceRequestAddSave(BranchServiceRequest $request)
    {
        $service = mt_rand(100000,999999);

        //$ser="SR";


        $obj = new Service();
        // $obj->service_request_no = $ser.$request['date'];
        $obj->service_request_no = $service;
        $obj->description = $request['description'];
        $obj->empres = $request['empres'];
        $obj->cc_status = $request['cc_status'];
        $obj->impact = $request['impact'];$obj->recom=$request['recom'];
        $obj->customer=$request['customer'];
        $obj->job_no=$request['job_no'];
        $obj->component_serial_no=$request['component_serial_no'];
        $obj->component_name=$request['component_name'];
        $obj->comp_model_no=$request['comp_model_no'];
        $obj->machine_modelno=$request['machine_modelno'];
        $obj->machine_serialno=$request['machine_serialno'];
        $obj->ar_no=$request['ar_no'];
        $obj->branch_name=$request['branch_name'];
        $obj->segment=$request['segment'];
        $obj->branch_location=$request['branch_location'];
        $obj->date=$request['date'];
        $obj->work_orderno=$request['work_orderno'];
        $obj->save();

        $id = $obj->id;





        (new FastExcel)->import($request->file('import_file'), function ($line) {
            $getServiceId = Service::selectRaw('max(id) as serviceID')->get();
            $serviceID=$getServiceId[0]['serviceID'];
            //dd($serviceID);exit;
            if ($line['Engine serial no']) {
                $mcModel = MasterPreHistoryDis::get();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterPreHistoryDis();
                    //$mcModel->dept_id = 1;
                    $mcModel->service_request_id = $serviceID;
                    $mcModel->engine_serial_no = $line['Engine serial no'];
                    $mcModel->engine_arrange_no = $line['Engine arrange no'];
                    $mcModel->machine_type = $line['Machine type'];
                    $mcModel->machine_serial_no = $line['Machine serial no'];
                    $mcModel->smu = $line['Total component life(SMU)'];
                    $mcModel->no_of_overhauls_done = $line['No of Overhauls Done'];
                    $mcModel->last_overhaul_smu = $line['Last Overhaul SMU'];
                    $mcModel->failure_details = $line['Failure Details & nature of failure'];
                    $mcModel->major_cylinder_head = $line['Cylinder head'];
                    $mcModel->major_injector = $line['Injector'];
                    $mcModel->major_oil_pump = $line['Oil pump'];
                    $mcModel->major_fuel_injection_pump = $line['Fuel injection pump'];

                    $mcModel->save();

                }

            }

        });



        $obj = new Service();
        if ($request->file('import_file')) {
            $imgfile = $request->file('import_file');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/serviceprehistory';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->pre_history = $image;


        $url=url('/');
        //dd($url);exit;

        /*mail to dept only one email*/

        $to_email = 'rimpi2019das@hotmail.com';
        $subject = 'Service Create Mail';
        $message = view('admin.mail.serviceNotificationMail', ['serviceno' => $obj->service_request_no,'url'=>$url])->render();

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From:' . \Config::get('env.service_mail')."\r\n";
        mail($to_email, $subject, $message, $headers);

        /*mail in every dept employee*/
        /*//$jobrole = \App\Helpers\UserHelper::jobrole();

      $jobrole=UserHelper::jobrole();

       dd($jobrole);exit;
       foreach ($jobrole as $jbrl) {
           $to_email = $jbrl->name;

       }
       $subject = 'Service Update Mail';
       $message = view('admin.mail.serviceNotificationMail', ['serviceno' => $obj->service_request_no,'url'=>$url])->render();

       $headers  = 'MIME-Version: 1.0' . "\r\n";
       $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
       $headers .= 'From:' . \Config::get('env.service_mail')."\r\n";
       mail($to_email, $subject, $message, $headers);
	   
	   return redirect('admin/service-request-list');
*/
        /* end employee mail */

        /* return redirect('admin/service-request-list')
             ->with('Great! file has been successfully uploaded.');*/
    }

    public function importPrehistSave(Request $request)
    {

        $service = Service::find($request['service_id']);
        // $path='C:/Apache24/htdocs/gcpl-quality/prehistoryupload';

//dd($service);exit;

        (new FastExcel)->import($request->file('import_file'), function ($line) {

            if ($line['Engine serial no']) {
                $mcModel = MasterPreHistoryDis::get();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterPreHistoryDis();
                    //$mcModel->dept_id = 1;
                    //$mcModel->service_request_id =18;
                    $mcModel->engine_serial_no = $line['Engine serial no'];
                    $mcModel->engine_arrange_no = $line['Engine arrange no'];
                    $mcModel->machine_type = $line['Machine type'];
                    $mcModel->machine_serial_no = $line['Machine serial no'];
                    $mcModel->smu = $line['Total component life(SMU)'];
                    $mcModel->no_of_overhauls_done = $line['No of Overhauls Done'];
                    $mcModel->last_overhaul_smu = $line['Last Overhaul SMU'];
                    $mcModel->failure_details = $line['Failure Details & nature of failure'];
                    $mcModel->major_cylinder_head = $line['Cylinder head'];
                    $mcModel->major_injector = $line['Injector'];
                    $mcModel->major_oil_pump = $line['Oil pump'];
                    $mcModel->major_fuel_injection_pump = $line['Fuel injection pump'];

                    $mcModel->save();

                }

            }

        });
        $obj = new Service();
        if ($request->file('import_file')) {
            $imgfile = $request->file('import_file');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/serviceprehistory';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->pre_history = $image;
        // Excel::import(new ImportContacts, request()->file('import_file'));

        return redirect('admin/service-request-list');
    }



    //ServicerequestEdit
    public function servicerequestlisting($id)
    {
        /* $servicerequest = Service::select('service_request_no')->get();
          //$customer = Service::select('customer')->get();
          $jobno = Service::select('job_no')->get();
          $machinemodel = Service::select('service_request.id', 'machine_modelno', 'gw_master_mc_model.model_no')->leftjoin('gw_master_mc_model',
              'gw_master_mc_model.id', '=', 'service_request.machine_modelno')->where('service_request.id', '=', '1')->get();

          $table = Service::select('service_request.id', 'comp_model_no', 'gw_master_component_model_no.model_no')->leftjoin('gw_master_component_model_no',

              'gw_master_component_model_no.id', '=', 'service_request.comp_model_no')->where('service_request.id', '=', '1')->get();
          $table = Service::select('service_request.id,comp_model_no left join gw_master_component_model_no ON
               service_request.comp_model_no= gw_master_component_model_no.id');

          return view('admin.branchengineer.servicerequestlisting')
              ->with('', $servicerequest)
              ->with('service', $customer)
              ->with('jobno', $jobno)
              ->with('modelno', $machinemodel)
              ->with('table', $table);*/



        $servicerequest = Service::find($id);


        $machinemodel = Service::select('service_request.id', 'machine_modelno', 'gw_master_mc_model.model_no')->leftjoin('gw_master_mc_model',
            'gw_master_mc_model.id', '=', 'service_request.machine_modelno')->where('service_request.id', '=', $id)->get();

        $status = MasterStatus::select('gw_master_status.*')->get();


        $employee = MasterEmployee::select('gw_master_employee.name')->get();

        $compmodelno = Service::select('service_request.id', 'comp_model_no', 'gw_master_component_model_no.model_no')->leftjoin('gw_master_component_model_no',

            'gw_master_component_model_no.id', '=', 'service_request.comp_model_no')->where('service_request.id', '=', $id)->get();
        $machserial = Service::select('service_request.id','machine_serialno', 'gw_master_machine_serial_no.serial_no')
            ->leftjoin('gw_master_machine_serial_no','gw_master_machine_serial_no.id', '=', 'service_request.machine_serialno')
            ->where('service_request.id', '=' ,$id)->get();


        $compserialno = Service::select('service_request.id','component_serial_no', 'gw_master_component_serial_no.serial_no')
            ->leftjoin('gw_master_component_serial_no', 'gw_master_component_serial_no.id', '=', 'service_request.component_serial_no')->where('service_request.id',
                '=' , $id)->get();
        return view('admin.branchengineer.servicerequestlisting')
            ->with('servicerequest', $servicerequest)
            ->with('employee',$employee)
            ->with('machinemodel', $machinemodel)
            ->with('compmodelno', $compmodelno)
            ->with('machserial',$machserial)
            ->with('status',$status)

            ->with('compserialno', $compserialno);
    }

    //service request edit save
    public function updateservicerequest(Request $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        $obj = Service::find($request['id']);

        $obj->customer=$request['customer'];
        $obj->empres=$request['empres'];
        $obj->cc_status=$request['cc_status'];
        $obj->description=$request['description'];
        $obj->impact=$request['impact'];
        $obj->recom=$request['recom'];
        $obj->job_no=$request['job_no'];
        $obj->component_serial_no=$request['component_serial_no'];
        $obj->component_name=$request['component_name'];
        $obj->comp_model_no=$request['comp_model_no'];
        $obj->machine_modelno=$request['machine_modelno'];
        $obj->machine_serialno=$request['machine_serialno'];
        $obj->ar_no=$request['ar_no'];
        $obj->branch_name=$request['branch_name'];
        $obj->segment=$request['segment'];
        $obj->branch_location=$request['branch_location'];
        $obj->work_orderno=$request['work_orderno'];
        $id = $obj->id;




        /* if ($request->file('po_upload')) {
             $imgfile = $request->file('po_upload');
             $tmp = explode('.', $imgfile->getClientOriginalName());
             $ext = end($tmp);
             $save_imgfile = time() . '.' . $ext;
             $destinationPath = 'public/assets/uploads/servicePOUpload';
             $imgfile->move($destinationPath, $save_imgfile);
             $image = $save_imgfile;
         } else {
             $image = '';
         }
         $obj->po_upload = $image;*/


        $obj->save();


        /*  (new FastExcel)->import($request->file('import_file'), function ($line) {
              $getServiceId = Service::selectRaw('max(id) as serviceID')->get();
              $serviceID=$getServiceId[0]['serviceID'];
              //dd($serviceID);exit;
              if ($line['Engine serial no']) {
                  $mcModel = MasterPreHistoryDis::get();
                  if (!isset($mcModel->id)) {
                      $mcModel = new MasterPreHistoryDis();
                      //$mcModel->dept_id = 1;
                      $mcModel->service_request_id = $serviceID;
                      $mcModel->engine_serial_no = $line['Engine serial no'];
                      $mcModel->engine_arrange_no = $line['Engine arrange no'];
                      $mcModel->machine_type = $line['Machine type'];
                      $mcModel->machine_serial_no = $line['Machine serial no'];
                      $mcModel->smu = $line['Total component life(SMU)'];
                      $mcModel->no_of_overhauls_done = $line['No of Overhauls Done'];
                      $mcModel->last_overhaul_smu = $line['Last Overhaul SMU'];
                      $mcModel->failure_details = $line['Failure Details & nature of failure'];
                      $mcModel->major_cylinder_head = $line['Cylinder head'];
                      $mcModel->major_injector = $line['Injector'];
                      $mcModel->major_oil_pump = $line['Oil pump'];
                      $mcModel->major_fuel_injection_pump = $line['Fuel injection pump'];

                      $mcModel->save();

                  }

              }

          });*/

        // $url=url('admin/listing')."/".$id;
        $url=url('/');
        //dd($url);exit;
        /*mail to dept*/

        $to_email = 'rimpi2019das@hotmail.com';
        $subject = 'Service Update Mail';
        $message = view('admin.mail.serviceNotificationMail', ['serviceno' => $obj->service_request_no,'url'=>$url])->render();

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From:' . \Config::get('env.service_mail')."\r\n";
        mail($to_email, $subject, $message, $headers);



        return redirect('admin/service-request-list');


    }



    /* public function serviceRequestEdit($id)
     {
         $title='Edit Service';

         $service=Service::find($id);

         return view('admin.branchengineer.editserviceRequest')
             ->with('service',$service);
     }


     public function serviceRequestEditSave(Request $request)
     {
         //  $myrequest=$request->all();
         //dd($request);

         $obj = Service::find($request['id']);

         $obj->customer=$request['customer'];
         $obj->job_no=$request['job_no'];
         $obj->component_serial_no=$request['component_serial_no'];
         $obj->component_name=$request['component_name'];
         $obj->model_no=$request['model_no'];
         $obj->machine_modelno=$request['machine_modelno'];

         $obj->ar_no=$request['ar_no'];
         $obj->branch_name=$request['branch_name'];
         $obj->segment=$request['segment'];
         $obj->branch_location=$request['branch_location'];
         $obj->date=$request['date'];

         if($obj->pre_history != '') {
             if ($file = $request->hasFile('pre_history')) {

                 $file = $request->file('pre_history');

                 $fileName = $file->getClientOriginalName();
                 $destinationPath = 'public/assets/uploads/serviceprehistory';
                 $file->move($destinationPath, $fileName);
                 $obj->pre_history = $fileName;
             }else{
                 $fileName = $obj->pre_history;
             }

         }
         $obj->save();


         return redirect('admin/service-request-list');

     }*/



    public function quotationList()
    {

        return view('admin.branchengineer.quotation');
    }

    public function quotationListGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)

            ->addColumn('action', function ($table) {
                if(isset($table->quotation) && strlen($table->quotation) > 1) {
                    //dd($table);exit;
                    $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              
                                <a class="dropdown-item" href="' . url('admin/quotation-download-show') . "/" . $table->id . '">Download quotation</a>
                              </div>
                            </div>';

                    //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                    return $btns;
                }
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function branchList()
    {

        return view('admin.branchengineer.listBranch');
    }

    public function branchGetTable(Request $request)
    {

        $table = MasterBranch::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('#' . $table->id) . '">Edit</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function segmentList()
    {

        return view('admin.branchengineer.listSegment');
    }

    public function segmentGetTable(Request $request)
    {

        $table = MasterSegment::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('#' . $table->id) . '">Edit</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }




//receiving

    public function receivingDashboardListGetTable(Request $request)
    {

        $table = Service::select('*') ->orderBy('id', 'DESC')
            ->offset(0)
            ->limit(3)->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                if(isset($table->checkgate1) && strlen($table->checkgate1) > 1){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                
                                          
                                                <a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>
                                               
                                                
                                            </div>
                                        </div>';
                }else {
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-one-add') . "/" . "$table->id" . '">Check Gate 1 </a>
                                          
                                                
                                               
                                                
                                            </div>
                                        </div>';
                }
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }



    public function serviceRequestLatestList()
    {


        return view('admin.receiving.allServiceRequests');
    }

    public function serviceRequestLatestListGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/



            ->addColumn('action', function ($table) {

                if(isset($table->checkgate1) && strlen($table->checkgate1) > 1){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                
                                          
                                                <a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>
                                               
                                                
                                            </div>
                                        </div>';
                }else {
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-one-add') . "/" . "$table->id" . '">Check Gate 1 </a>
                                          
                                                
                                               
                                                
                                            </div>
                                        </div>';
                }
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }



    public function checkGateFormOne()
    {

        return view('admin.receiving.checkGateFormOne');
    }

    public function checkGateFormOneAdd($id)
    {
        $chkgate=Service::find($id);

        return view('admin.receiving.checkGateFormOne')
            ->with('chkgate',$chkgate);
    }

    public function checkGateFormOneAddSave(Request $request)
    {
        $checkgate1=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate1=$checkgate1;

        if ($request->file('checkgate1_image')) {
            $imgfile = $request->file('checkgate1_image');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/checkgate1Image';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->checkgate1_image = $image;

        if ($request->file('transporter_copy')) {
            $imgfile = $request->file('transporter_copy');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->transporter_copy = $image;

        if ($request->file('challan')) {
            $imgfile = $request->file('challan');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->challan = $image;

        if ($request->file('gate_pass')) {
            $imgfile = $request->file('gate_pass');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->gate_pass = $image;

        $obj->save();


        $url=url('/');
        $to_email = 'rimpi2019das@hotmail.com';
        $subject = 'Checkgate1 Create Mail';

        $message = view('admin.mail.checkgateOneNotificationMail', ['url'=>$url])->render();
        //$head = 'From:' . \Config::get('env.service_mail')."\r\n";

        UserHelper::mailnoti($to_email,$subject,$message);
        //mailnoti($to_email,$subject,$message);


        //send Notification
        return redirect('admin/service-request-latest-list');
    }

    //Check Gate Form One Listing
    public function checkgatefromOnelisting($id)
    {
        $checkgateone=Service::find($id);
        $checkgateonelist=Service::where('id','=',$checkgateone->id)
            ->get()->first();
        if(isset($checkgateonelist->id)){
            $checkgateonelist=json_decode($checkgateonelist->checkgate1);
        }else{
            $checkgateonelist=Null;
        }
        return view('admin.receiving.checkGateFormOneListing')
            ->with('checkgateone',$checkgateone)
            ->with('checkgateonelist',$checkgateonelist);
    }

    public function checkGateFormOneEditSave(Request $request)
    {
        $checkgateoneedit=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate1=$checkgateoneedit;


        if(isset($checkgateoneedit['checkgate1_image']) && (count($checkgateoneedit['checkgate1_image'])<=5)){
            $i = 0;
            foreach ($checkgateoneedit['checkgate1_image'] as $key=>$checkgate1_image ){
                if ($request->file('checkgate1_image')) {
                    $imgfile = $request->file('checkgate1_image')[$key];
                    $tmp = explode('.', $imgfile->getClientOriginalName());
                    $ext = end($tmp);
                    $save_imgfile = rand(1000000000,9999999999).'.'. $ext;
                    $destinationPath = 'public/assets/uploads/checkgate1Image';
                    $imgfile->move($destinationPath, $save_imgfile);
                    $image[$i] = $save_imgfile;
                    File::delete($destinationPath . '/' . $obj->checkgate1_image);
                } else {
                    if(isset($request['img_rem'])){
                        $destinationPath = 'public/assets/uploads/checkgate1Image';
                        File::delete($destinationPath . '/' . $obj->checkgate1_image);
                        $image='';
                    }else{
                        $image = $obj->checkgate1_image;
                    }

                }

                $i++;
            }
//                echo '<pre>';print_r($image);exit;
//                echo '<pre>';print_r(implode(',',$image));exit;

            $obj->checkgate1_image = implode(',',$image);
        }

        if ($request->file('transporter_copy')) {
            $imgfile = $request->file('transporter_copy');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->transporter_copy = $image;

        if ($request->file('challan')) {
            $imgfile = $request->file('challan');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->challan = $image;

        if ($request->file('gate_pass')) {
            $imgfile = $request->file('gate_pass');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/receivingUploads';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->gate_pass = $image;

        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');
    }



    /*  public function checkGateFormOneList()
     {

         return view('admin.receiving.checkGateFormList');
     }

     public function checkGateFormOneListGetTable(Request $request)
     {


         $table = Service::select('*')->get();


         $datatables =  Datatables::of($table)
             /*->addColumn('usertype', function ($table) {
                 if(){

                 }
                 return $btns;
             })
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
    /*->addColumn('action', function ($table) {
        $btns = '';
        //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
        return $btns;
    })

    ->rawColumns([]);


return $datatables->make(true);
}*/

    /*public function checkGateFormTwo()
     {

         return view('admin.receiving.checkGateFormTwo');

     }*/
    //checkgate-form-two
    public function checkGateFormTwoAdd($id)
    {
        $checkgate=Service::find($id);
        //$checkgatetwolist=Service::where('id','=',$checkgate->id)

        //  ->get()->first();
        //if(isset($checkgatetwolist->id)){
        //  $checkgatetwolist=json_decode($checkgatetwolist->values);
        //}else{
        //  $checkgatetwolist=Null;
        //}
        return view('admin.receiving.checkGateFormTwo')
            //    ->with('checkgatetwolist','$checkgatetwolist')
            ->with('checkgate',$checkgate) ;

    }

    public function checkGateFormTwoAddSave(Request $request)
    {
        $checkgate2=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate2=$checkgate2;
        $obj->save();
        //send Notification
        return redirect('admin/engine-diss-list');


    }

    //Check Gate Form Two Listing
    public function checkgatefromtwolisting($id)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        $checkgate=Service::find($id);
        $checkgatetwolist=Service::where('id','=',$checkgate->id)

            ->get()->first();
        if(isset($checkgatetwolist->id)){
            $checkgatetwolist=json_decode($checkgatetwolist->checkgate2);
        }else{
            $checkgatetwolist=Null;
        }
        //dd($checkgatetwolist);exit;

        return view('admin.receiving.checkGateFormTwoListing')
            ->with('checkgate',$checkgate)
            ->with('checkgatetwolist',$checkgatetwolist);
    }
    public function checkGateFormTwoEditSave(Request $request)
    {
        $checkgatetwoedit=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate2=$checkgatetwoedit;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');
    }

    //checkgate-form-threee
    public function checkGateFormThreeAdd($id)
    {
        $checkgate=Service::find($id);
//dd($checkgate);exit;
        return view('admin.receiving.checkGateFormThree')

            ->with('checkgate',$checkgate) ;

    }

    public function checkGateFormThreeAddSave(Request $request)
    {
        $checkgate3=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate3=$checkgate3;
        $obj->save();
        //send Notification
        return redirect('admin/engine-diss-list');


    }

//Check Gate Form three Listing
    public function checkgatefromThreelisting($id)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        $checkgate=Service::find($id);
        $checkgatethreelist=Service::where('id','=',$checkgate->id)

            ->get()->first();
        if(isset($checkgatethreelist->id)){
            $checkgatethreelist=json_decode($checkgatethreelist->checkgate3);
        }else{
            $checkgatethreelist=Null;
        }
        //dd($checkgatetwolist);exit;

        return view('admin.receiving.checkGateFormThreeListing')
            ->with('checkgate',$checkgate)
            ->with('checkgatethreelist',$checkgatethreelist);
    }
    public function checkGateFormThreeEditSave(Request $request)
    {
        $checkgatetwoedit=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate3=$checkgatetwoedit;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');
    }






//super admin
    public function projectsOpenList()
    {

        return view('admin.superadmin.openProjects');
    }

    public function projectsCompletedList()
    {

        return view('admin.superadmin.completedProjects');
    }
   /* public function projectDetails()
    {

        return view('admin.superadmin.projectDetails');
    }*/

    //engine model no
    public function engineModelNoList()
    {

        return view('admin.serviceform.listEngineModelNo');
    }

    public function engineModelNoListGetTable(Request $request)
    {

        $table = MasterEngineModel::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('#' . $table->id) . '">Download quotation</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })*/

            ->rawColumns([]);


        return $datatables->make(true);
    }


    //Component Name
    public function componentNameAdd()
    {

        return view('admin.serviceform.addComponentName');
    }

    public function componentNameAddSave(Request $request)
    {

        $obj = new MasterAllComponentName();

        $obj->name=$request['name'];
        /*$obj->job_no=$request['job_no'];
        $obj->component_name=$request['component_name'];
        $obj->model_no=$request['model_no'];
        $obj->ar_no=$request['ar_no'];
        $obj->ar_no=$request['ar_no'];*/


        $obj->save();


        return redirect('admin/super-admin-dashboard');
    }

    public function componentNameEdit($id)
    {
        $title='Edit User';

        $ques=MasterAllComponentName::find($id);

        return view('admin.serviceform.editComponentName')
            ->with('ques',$ques);
    }





    //formelements

    public function formElementsForm()
    {

        return view('admin.dashboard.formElements');
    }


    //service engineer
    public function checkSheetEntry()
    {

        return view('admin.serviceengineer.checkSheetEntry');
    }

    public function checkSheetEntryCommon($id)
    {

        $checkcommon = Service::find($id);
        return view('admin.include.checkSheetCommon')
            ->with('checkcommon',$checkcommon);
    }

    public function serviceList()
    {

        return view('admin.serviceengineer.allserviceList');
    }

    public function serviceGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Check Sheet Entry</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function machineSerialListShow(Request $request){

        $machserial= UserHelper::machineserialno($request['model']);


        //$model=$_POST['model'];


        $str = '<option selected="selected" disabled="disabled">Select Machine Serial number</option>';
        if (!isset($machserial->mc_model_id)) {
            foreach ($machserial as $key => $value) {
                $str .= '<option value=' . $value['id'] . '>' . $value['serial_no'] . '</option>';
            }
        }
        echo $str;

        //$model=$_POST['model'];
        //echo $model;

    }


    public function componentModelListShow(Request $request)
    {

        // $machserial = UserHelper::machineserialno();
        $compdet = UserHelper::componentdetails($request['commodel']);

        $commod = '<option selected="selected" disabled="disabled">Select Component Model number</option>';
        if (!isset($compdet->mc_model_id)) {
            foreach ($compdet as $key => $value) {
                $commod .= '<option value=' . $value['id'] . '>' . $value['comp_model_no'] . '</option>';
            }
        }
        echo $commod;

    }

    public function componentSerialListShow(Request $request)
    {

        // $machserial = UserHelper::machineserialno();
        $compse = UserHelper::componentserial($request['coserial']);
//dd($compse);exit;
        $comser = '<option selected="selected" disabled="disabled">Select Component Serial number</option>';
        if (!isset($compse->mc_model_id)) {
            foreach ($compse as $key => $value) {
                $comser .= '<option value=' . $value['id'] . '>' . $value['comp_serial_no'] . '</option>';
            }
        }
        echo $comser;
    }

//quotation upload
    public function supportQuotationList(){

        return view('admin.support.quotationUpload');
    }

    public function supportQuotationgetTable(Request $request)
    {



        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /* ->addColumn('quotation', function ($table) {
                  $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                  return $img;
              })*/
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/support-quotation-add/' ) ."/". $table->id. '">Upload Quotation</a>
                                 <a class="dropdown-item" href="' . url('admin/quotation-download-show/' ) ."/". $table->id. '">Download Quotation</a>
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);
        return $datatables->make(true);
    }
    public function supportQuotationAdd($id)
    {

        $service=Service::find($id);
        return view('admin.support.addQuotation')
            ->with('service',$service);
    }

    public function supportQuotationAddSave(Request $request)
    {

        $obj = Service::find($request['id']);

        //$request->file('quotation')

        $data=[];

        // $data=$request->file('quotation');

        /*$pdf_path='public/assets/uploads/quotationupload/1234567.pdf';
        $pdf = \PDF::loadView('admin.support.pdfQuotation', $data)->save($pdf_path);

        $obj->quotation=$request['quotation'];
        $obj->save();*/

        if ($request->file('quotation')) {
            $imgfile = $request->file('quotation');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/quotationupload';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->quotation = $image;

        $obj->save();

        $url=url('/');

        $to_email = 'rimpi2019das@hotmail.com';
        $subject = 'Quotation Update Mail';
        $message = view('admin.mail.quotationUploadMail', ['url'=>$url])->render();

        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From:' . \Config::get('env.service_mail')."\r\n";
        mail($to_email, $subject, $message, $headers);


        return redirect('admin/support-dashboard');
    }

    //upload Po in spc
    public function uploadPoAdd($id)
    {

        $service=Service::find($id);
        return view('admin.spc.addPO')
            ->with('service',$service);
    }
    public function uploadPoAddSave(Request $request)
    {

        $obj = Service::find($request['id']);

        if ($request->file('po_upload')) {
            $imgfile = $request->file('po_upload');
            $tmp = explode('.', $imgfile->getClientOriginalName());
            $ext = end($tmp);
            $save_imgfile = time() . '.' . $ext;
            $destinationPath = 'public/assets/uploads/servicePOUpload';
            $imgfile->move($destinationPath, $save_imgfile);
            $image = $save_imgfile;
        } else {
            $image = '';
        }
        $obj->po_upload = $image;
        $obj->po_date = $request['po_date'];
        $obj->save();
        $obj = Service::find($request['id'])->toArray();

        // $machine_model = UserHelper::machineserialno($request['model']);
        $dept_name = UserHelper::getDeptName($obj['dept_id'])[0];
        $getDeptEmp = UserHelper::getDeptEmp($obj['dept_id']);
        $getDeptTasks = UserHelper::getDeptTask($obj['dept_id']);
        $project_id = '#PRO'.substr(str_shuffle("12345"), -1).mt_rand(1000,99999);
        $emp_res = '';
        $task_res = '';
        $task_tat_cal = 0;
        if(!empty($getDeptEmp)){
            foreach ($getDeptEmp as $key => $emp) {
                if($key == 0)
                {
                    $emp_res =$emp['emp_code'];
                } else {
                    $emp_res =$emp_res.','.$emp['emp_code'];
                }
            }
        }
        if(!empty($getDeptTasks)){
            foreach ($getDeptTasks as $key => $task) {
                $task_tat_cal += $task['tat'];
                if($key == 0)
                {
                    $task_res =$task['id'];
                } else {
                    $task_res =$task_res.','.$task['id'];
                }
            }
        }

        $number = $task_tat_cal.' days';
        $estm_end_date=date_create($obj['po_date']);
        date_add($estm_end_date,date_interval_create_from_date_string($number));

        $obj_project_plan = new ProjectPlanMaster();
        $obj_project_plan->service_id=$obj['id'];
        $obj_project_plan->service_request_no=$obj['service_request_no'];
        $obj_project_plan->project_id=$project_id;
        $obj_project_plan->name=$dept_name['name'];
        $obj_project_plan->dept_id=$obj['dept_id'];
        $obj_project_plan->dept_name=$dept_name['name'];
        $obj_project_plan->customer_id=$obj['customer'];
        $obj_project_plan->estm_start_date=$obj['po_date'];
        $obj_project_plan->estm_end_date=date_format($estm_end_date,"Y-m-d");
        $obj_project_plan->estm_days=$task_tat_cal;
        $obj_project_plan->save();

        $obj_project_task = new ProjectTask();
        $obj_project_task->prj_id = $obj_project_plan->id;
        $obj_project_task->project_id = $project_id;
        $obj_project_task->dept_id = $obj['dept_id'];
        $obj_project_task->tasks = $task_res;
        $obj_project_task->save();

        $obj_project_user = new ProjectUser();
        $obj_project_user->prj_id = $obj_project_plan->id;
        $obj_project_user->project_id = $project_id;
        $obj_project_user->dept_id = $obj['dept_id'];
        $obj_project_user->users = $emp_res;
        $obj_project_user->save();


        //dd($obj->work_orderno);exit;

        return redirect('admin/spc-dashboard');
    }

    //spc dashboard
    public function spcDashboardListGetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /* ->addColumn('quotation', function ($table) {
                  $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                  return $img;
              })*/

            ->addColumn('action', function ($table) {
                if(isset($table->po_upload) && strlen($table->po_upload) > 1) {
                    $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/upload-po-add/') . "/" . $table->id . '">Upload PO</a>
                                <a class="dropdown-item" href="' . url('admin/po-download-show/') . "/" . $table->id . '">Download PO</a>
                              </div>
                            </div>';
                    //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                    return $btns;
                }else{
                    $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/upload-po-add/') . "/" . $table->id . '">Upload PO</a>
                                
                              </div>
                            </div>';
                    //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                    return $btns;
                }
            })

            ->rawColumns(['action']);
        return $datatables->make(true);
    }


    //engine head dashboard

    public function engHeadDashboardGetTable(Request $request)
    {

        $table = Service::select('*')

            ->orderBy('status', 'DESC')
            ->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /* ->addColumn('quotation', function ($table) {
                  $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                  return $img;
              })*/

            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                
                              </div>
                            </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);
        return $datatables->make(true);
    }


    public function mastermachinedetails( request $id)
    {
        $servicerequest = Service::find($id);
        $machinemodel = Service::select('service_request.id', 'machine_modelno', 'gw_master_mc_model.model_no')->leftjoin('gw_master_mc_model',
            'gw_master_mc_model.id', '=', 'service_request.machine_modelno')->where('service_request.id', '=', $id)->get();

        $machserial = Service::select('service_request.id','machine_serialno', 'gw_master_machine_serial_no.serial_no')
            ->leftjoin('gw_master_machine_serial_no','gw_master_machine_serial_no.id', '=', 'service_request.machine_serialno')
            ->where('service_request.id', '=' ,$id)->get();
        return view('admin.receiving.mastermachinedetails')
            ->with('servicerequest', $servicerequest)
            ->with('machinemodel', $machinemodel)
            ->with('machserial',$machserial);
    }
    public function rollmenulist()
    {
        //$masterrole = Masterrole::find($id);
        //$mastermenu = Menu::select('menu');
        return view('admin.superadmin.rollmenulist');
        //->with('mastermenu', $mastermenu);
        //->with('masterrole', $masterrole);
    }



    public function rollmenulistsave(Request $request)

    {
        $rollmenulist=$request->all();
        //echo'<pre>';print_r($rollmenulist);exit;
        //dd($rollmenulist);exit;
        //$rollmenu=$request->all('menu');
        $obj = new Menuaccess();
        //$obj->role = json_encode($rollmenulist);
        $obj->role = $rollmenulist['role'];
        $obj->menu = json_encode($rollmenulist['checked']);
        $obj->save();
        return redirect('admin/rollmenu');
    }
    public function rollmenulisting($id)
    {
        $role=Menuaccess::find($id);
        $rollmenulist=Menuaccess::where('menu')->get()->first();
        if(isset($rollmenulist->id)) {
            $rollmenulist = json_decode($rollmenulist->menu);
        }else{
            $rollmenulist=Null;
        }

        $rolemenu = Menuaccess::select('menu_access.id', 'role', 'roles.name')->leftjoin('roles',
            'roles.id', '=', 'menu_access.role')->where('menu_access.role', '=', $id)->get();


        return view('admin.superadmin.rollmenulisting')

            ->with('rolemenu',$rolemenu)
            ->with('rollmenulist',$rollmenulist);
    }





    //quotation download

    public function quotationDownloadShow($id)
    {

        $service=Service::find($id);
        return view('admin.branchengineer.downloadQuotationShow')
            ->with('service',$service);
    }
    public function quotationDownload(Request $request)
    {

        $quotationdownload= Service::find($request['id']);

        //dd($quotationdownload);exit;


        $file='public/assets/uploads/quotationupload/';

        // $name= $file.$quotationdownload;

        $pathToFile=$file."/".$quotationdownload->quotation;
        // $file=$path.'1576847665.pdf';
        //$name = basename($file);
        return Response::download($pathToFile);

        //return redirect('admin/branch-dashboard');

    }


    public function poDownloadShow($id)
    {

        $service=Service::find($id);
        return view('admin.spc.downloadPO')
            ->with('service',$service);
    }
    public function poDownload(Request $request)
    {

        $podownload= Service::find($request['id']);

        //dd($quotationdownload);exit;


        $file='public/assets/uploads/servicePOUpload/';

        // $name= $file.$quotationdownload;

        $pathToFile=$file."/".$podownload->po_upload;
        // $file=$path.'1576847665.pdf';
        //$name = basename($file);
        return Response::download($pathToFile);

        //return redirect('admin/branch-dashboard');

    }

    public function checkGateFormFourAdd($id)
    {
        $checkgate = Service::find($id);


        return view('admin.receiving.checkGateFormFour')
            ->with('checkgate', $checkgate);
    }

    public function checkGateFormFourAddSave(Request $request)

    {
        $checkgate4 = $request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate4 = $checkgate4;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');

    }
    public function checkgatefromfourlisting($id)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        $checkgate = Service::find($id);
        $checkgateFourlist = Service::where('id', '=', $checkgate->id)
            ->get()->first();
        if (isset($checkgateFourlist->id)) {
            $checkgateFourlist = json_decode($checkgateFourlist->checkgate4);





        } else {
            $checkgateFourlist = Null;
        }
        //dd($checkgatetwolist);exit;

        return view('admin.receiving.checkGateFormFourListing')
            ->with('checkgate',  $checkgate)
            ->with('checkgateFourlist',  $checkgateFourlist);
    }
    public function checkGateFormFourEditSave(Request $request)
    {
        $checkgatefouredit=$request->all();
        $obj = Service::find($request['id']);
        $obj->checkgate4=$checkgatefouredit;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');
    }

    //common mail for all information

//PDI checksheet
    public function pdiAdd($id)
    {
        $pdiadd = Service::find($id);


        return view('admin.pdichecksheet.pdiCheckSheet')
            ->with('pdiadd', $pdiadd);
    }


    public function pdiAddSave(Request $request)

    {
        $pdiAddSave = $request->all();
        $obj = Service::find($request['id']);
        $obj->pdi_checksheet = $pdiAddSave;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');

    }
    public function pdilisting($id)
    {
        {

            $pdichecksheet = Service::find($id);
            $pdichecksheetlist = Service::where('id', '=', $pdichecksheet->id)
                ->get()->first();
            if (isset($pdichecksheetlist->id)) {
                $pdichecksheetlist = json_decode($pdichecksheetlist->pdi_checksheet);

            } else {
                $pdichecksheetlist = Null;
            }
            //dd($checkgatetwolist);exit;

            return view('admin.pdichecksheet.pdiCheckSheetListing')
                ->with('pdichecksheet',  $pdichecksheet)
                ->with('pdichecksheetlist',  $pdichecksheetlist);
        }
    }
    public function pdiEditSave(Request $request)
    {
        $pdicheckgateedit=$request->all();
        $obj = Service::find($request['id']);
        $obj->pdi_checksheet= $pdicheckgateedit;
        $obj->save();
        //send Notification
        return redirect('admin/service-request-latest-list');
    }

    //project plan
    // Assign Users to Project
    public function AssignUserProject(Request $request){
        $project_user = ProjectUser::find($request['prj_user_id']);
        $project_user->prj_id = $request['prj_id'];
        $project_user->project_id = $request['project_id'];
        $project_user->dept_id = $request['dept_id'];
        $project_user->users = implode(',', $request['asign_user']);
        $project_user->save();
        return redirect('admin/project-details/'.$project_user->prj_id);
    }

    // Assign Users to Task
    public function AssignUserTask(Request $request){


        $date1=date_create($request['actual_strt_dt']);
        $date2=date_create($request['end_dt']);
        $diff=date_diff($date1,$date2);
        $tat =  $diff->format("%a");

        $masterTask = new MasterTask();
        $masterTask->dept_id  =  $request['dept_id'];
        $masterTask->model_no  =  $request['model_no'];
        $masterTask->name  =  $request['main_task'];
        if(isset($request['parent_task_id'])){
            $masterTask->parent  =  $request['parent_task_id'];
        }
        $masterTask->tat  =  $tat;
        $masterTask->save();

        $taskUsers = new TaskUser();
        $taskUsers->prj_id  =  $request['prj_id'];
        $taskUsers->project_id  =  $request['project_id'];
        $taskUsers->task  =  $masterTask->id;
        $taskUsers->actual_strt_dt  =  $request['actual_strt_dt'];
        $taskUsers->end_dt  =  $request['end_dt'];
        // $taskUsers->comment   =  $request['comment'];
        $taskUsers->users  =  implode(',', $request['task_users']);
        $taskUsers->save();

        $getDeptTasks = UserHelper::getDeptTask($request['dept_id']);
        $task_res = '';
        $task_tat_cal = 0;
        if(!empty($getDeptTasks)){
            foreach ($getDeptTasks as $key => $task) {
                $task_tat_cal += $task['tat'];
                if($key == 0)
                {
                    $task_res =$task['id'];
                } else {
                    $task_res =$task_res.','.$task['id'];
                }
            }
        }

        $project_task=ProjectTask::find($request['prj_task_id']);
        $project_task->tasks = $task_res;
        $project_task->save();



        return redirect('admin/project-details/'.$request['prj_id']);
    }
    public function AssignUserProjectTask(Request $request){
        $taskUsers = TaskUser::where('task','=',$request['parent_task_id'])
            ->where('prj_id','=',$request['prj_id'])
            ->get()->toArray();
        $users = implode(',',$request['asign_user_task']);
        if(!empty($taskUsers)){

            DB::statement("UPDATE gw_task_users SET users = '".$users."' where task = '". $request['parent_task_id']."' AND prj_id = '".$request['prj_id']."'");
        }
        else{
            $taskUsers = new TaskUser();
            $taskUsers->prj_id  =  $request['prj_id'];
            $taskUsers->project_id  =  $request['project_id'];
            $taskUsers->task  =  $request['task_id'];
            $taskUsers->users  = $users;
            // $taskUsers->actual_strt_dt  =  $request['actual_strt_dt'];
            // $taskUsers->end_dt  =  $request['end_dt'];
            // $taskUsers->comment   =  $request['comment'];
            $taskUsers->save();
        }

        return redirect('admin/project-details/'.$request['prj_id']);
    }

    // Edit Task
    public function editTask(Request $request){
        $taskUsers = TaskUser::where('task','=',$request['task_id'])
            ->where('prj_id','=',$request['prj_id'])
            ->get()->toArray();
        // $taskUsers->actual_strt_dt  =  $request['actual_strt_dt'];
        // $taskUsers->end_dt  =  $request['end_dt'];
        // $taskUsers->comment   =  $request['comment'];
        // $taskUsers->save();
        // echo "<pre>";print_r($request['actual_strt_dt']);exit;
        if(!empty($taskUsers)){
            DB::statement("UPDATE gw_task_users SET actual_strt_dt = '".$request['actual_strt_dt']."',end_dt = '".$request['end_dt']."' , comment = '".$request['comment']."' where task = '". $request['task_id']."' AND prj_id = '".$request['prj_id']."'");
        }
        else{
            $taskUsers = new TaskUser();
            $taskUsers->prj_id  =  $request['prj_id'];
            $taskUsers->project_id  =  $request['project_id'];
            $taskUsers->task  =  $request['task_id'];
            $taskUsers->actual_strt_dt  =  $request['actual_strt_dt'];
            $taskUsers->end_dt  =  $request['end_dt'];
            $taskUsers->comment   =  $request['comment'];
            $taskUsers->save();
        }
        return redirect('admin/project-details/'.$request['prj_id']);

    }

    // Project Note
    public function projectNote(Request $request){
        $project_user = ProjectPlanMaster::find($request['prj_id']);
        $project_user->comment = $request['project_note'];
        $project_user->save();
        return redirect('admin/project-details/'.$request['prj_id']);
    }
    public function projectDetails($id)
    {
        // ProjectPlanMaster;
        // ProjectTask;
        // ProjectUser;
        // TaskUser;
        // MasterDepartment;
        // MasterEmployee;
        // MasterTask
        $title='Project Details';
        $emp_details=[];
        $tasks=[];
        $project_plan=ProjectPlanMaster::find($id)->toArray();
        $project_task=ProjectTask::where('prj_id','=',$id)
            ->get()->toArray()[0];
        $project_user=ProjectUser::where('prj_id','=',$id)
            ->get()->toArray()[0];
        $task_user=TaskUser::where('prj_id','=',$id)
            ->get()->toArray();
        $service_details = Service::where('id','=',$project_plan['service_id'])
            ->get()->toArray()[0];

        $getDeptTasks = UserHelper::getDeptTask($project_plan['dept_id']);
        $task_res = '';
        $task_tat_cal = 0;
        if(!empty($getDeptTasks)){
            foreach ($getDeptTasks as $key => $task) {
                $task_tat_cal += $task['tat'];
                if($key == 0)
                {
                    $task_res =$task['id'];
                } else {
                    $task_res =$task_res.','.$task['id'];
                }
            }
        }

        $number = $task_tat_cal.' days';
        $estm_end_date=date_create($project_plan['estm_start_date']);
        date_add($estm_end_date,date_interval_create_from_date_string($number));


        $project_plan=ProjectPlanMaster::find($id);
        $project_plan->estm_end_date = date_format($estm_end_date,"Y-m-d");
        $project_plan->estm_days = $task_tat_cal;
        $project_plan->save();

        $dept_employees = UserHelper::getDeptEmp($project_plan['dept_id']);
        $emp_codes = explode(',', $project_user['users']);
        $dept_tasks = explode(',', $project_task['tasks']);
        if(count($emp_codes) > 0){
            $e = 0;
            foreach ($emp_codes as $key => $emp_code) {
                $emp_details[$e] = MasterEmployee::where('emp_code','=',$emp_code)
                    ->get()->toArray()[0];
                $e++;
            }
        }

        if(count($dept_tasks) > 0){
            $t = 0;
            foreach ($dept_tasks as $key => $task) {
                $tasks[$t] = MasterTask::where('id','=',$task)
                    ->get()->toArray()[0];
                $t++;
            }
        }
        // $parentTask=UserHelper::checkParentTask();
        // $getDeptTasks = UserHelper::getDeptTask($obj['dept_id']);
        // echo "<pre>";print_r($project_plan);
        // echo "<pre>";print_r($project_task);
        // echo "<pre>";print_r($project_user);
        // echo "<pre>";print_r($emp_details);
        // echo "<pre>";print_r($dept_employees);
        // echo "<pre>";print_r($tasks);
        // echo "<pre>";print_r($service_details);
        // echo "<pre>";print_r($task_user);
        // exit;

        return view('admin.superadmin.projectDetails')
            ->with('project_plan',$project_plan)
            ->with('project_task',$project_task)
            ->with('project_user',$project_user)
            ->with('emp_details',$emp_details)
            ->with('dept_employees',$dept_employees)
            ->with('tasks',$tasks)
            ->with('task_user',$task_user)
            ->with('service_details',$service_details);
    }

    public function getTableProjectMaster(Request $request)
    {
        $table =ProjectPlanMaster::select('*')->get();
        // echo "<pre>";print_r($table);exit();
        $datatables =  Datatables::of($table)

            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/project-details')."/"."$table->id".'">EDIT</a>
                                
                            </div>
                        </div>';

                return $btns;
            })
            ->addColumn('status', function ($table) {
                $btns = ' <span class="badge badge-success">'.$table->status.'</span>';

                return $btns;
            })
            ->addColumn('date_duration', function ($table) {
                $btns = date('m/d/Y',strtotime($table->estm_start_date)).' - '.date('m/d/Y',strtotime($table->estm_end_date));

                return $btns;
            })
            ->addColumn('estm_start_date', function ($table) {
                $btns = date('m/d/Y',strtotime($table->estm_start_date));

                return $btns;
            })
            ->rawColumns(['action','status','date_duration','estm_start_date']);
        return $datatables->make(true);
    }


}
