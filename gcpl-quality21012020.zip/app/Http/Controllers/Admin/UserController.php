<?php

namespace App\Http\Controllers\admin;

use App\Models\ChecksheetChildSection;
use App\Models\ChecksheetColumn;
use App\Models\ChecksheetSubChildSection;
use App\Models\MasterBranch;
use App\Models\MasterCheckSheetSection;
use App\Models\MasterComponentArrangementNo;
use App\Models\MasterComponentDetails;
use App\Models\MasterComponentModelNo;
use App\Models\MasterComponentSerialNo;
use App\Models\MasterComponentType;
use App\Models\MasterCustomer;
use App\Models\MasterDesignation;
use App\Models\MasterEmployee;
use App\Models\MasterJobType;
use App\Models\MasterMachine;
use App\Models\MasterMachineDetails;
use App\Models\MasterMachineModelNo;
use App\Models\MasterMachineSerialNo;
use App\Models\MasterMCModel;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterPartOthercomponentBasicEngine;
use App\Models\MasterPartOthercomponentCoolingSystem;
use App\Models\MasterPartOthercomponentFuelSystem;
use App\Models\MasterPartOthercomponentLubricationSystem;
use App\Models\MasterSection;
use App\Models\MasterSegment;
use App\Models\Roles;
use Rap2hpoutre\FastExcel\FastExcel;
use App\Http\Controllers\Controller;
use App\Http\Requests\UserEditRequest;
use App\Http\Requests\UserRequest;
use App\Models\MasterEngineModel;
use Illuminate\Http\Request;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;


use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;

use Excel;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
class UserController extends Controller
{
    public function test(){
        /*
        Role::create(['name' => 'super_admin']);
        Role::create(['name' => 'crc_head']);
        Role::create(['name' => 'spc']);
        Role::create(['name' => 'branch_engineer']);
        Role::create(['name' => 'section_supervisor']);
        Role::create(['name' => 'section_engineer']);
        Role::create(['name' => 'qa_qc']);
        Role::create(['name' => 'planning_supervisor']);
        Role::create(['name' => 'store_manager']);
        Role::create(['name' => 'despatch_manager']);

        Permission::create(['name' => 'edit articles']);

        A permission can be assigned to a role using 1 of these methods:

        $role->givePermissionTo($permission);
        $permission->assignRole($role);

        A permission can be removed from a role using 1 of these methods:

        $role->revokePermissionTo($permission);
        $permission->removeRole($role);

        // get a list of all permissions directly assigned to the user
        $permissionNames = $user->getPermissionNames(); // collection of name strings
        $permissions = $user->permissions; // collection of permission objects

        // get all permissions for the user, either directly, or from roles, or from both
        $permissions = $user->getDirectPermissions();
        $permissions = $user->getPermissionsViaRoles();
        $permissions = $user->getAllPermissions();

        // get the names of the user's roles
        $roles = $user->getRoleNames();

        $users = User::role('writer')->get(); // Returns only users with the role 'writer'

        $users = User::permission('edit articles')->get(); // Returns only users with the permission 'edit articles' (inherited or directly)

        $all_users_with_all_their_roles = User::with('roles')->get();
        $all_users_with_all_direct_permissions = User::with('permissions')->get();
        $all_roles_in_database = Role::all()->pluck('name');


        You can check if a user has Any of an array of permissions:

        $user->hasAnyPermission(['edit articles', 'publish articles', 'unpublish articles']);

        user has All of an array of permissions:

        $user->hasAllPermissions(['edit articles', 'publish articles', 'unpublish articles']);

        $user->can('edit articles');

        //Assign Role to User
        $user=User::find(1);
        $user->assignRole('super_admin');

        // Adding permissions to a user
        $user->givePermissionTo('edit articles');


        $user=User::find(1);
        $user->assignRole('super_admin');
        echo "Assign Role";


        $user=User::find(1);
        $user->removeRole('super_admin');
        echo "Delete Role";
        Role::create(['name' => 'dept_hyd_disassembly']);
        */

        $user=User::find(31);
        $user->assignRole('dept_undercarriage');
        echo "Assign Role";


    }

    /*Read excel file with fastexcel and insert data into database autometically*/

    public function test2(Request $request){


       (new FastExcel)->import('C:/Apache24/htdocs/gcpl-qualitynew htmls/Book1.xlsx', function ($line) {
//echo "<pre>"; print_r($line);exit;
           if($line['Section'] ) {
               $mcModel = MasterCheckSheetSection::where('name', '=', $line['Section'])->get()->first();
               if (!isset($mcModel->id)) {
                   $mcModel = new MasterCheckSheetSection();
                   //$mcModel->section_id = $line['Section'];

                   $mcModel->name = $line['Section'];
                   $mcModel->save();

               }
           }


       /* if($line['child section'] ) {
             $section = ChecksheetChildSection::where('child_section', '=', $line['child section'])
                 //->where('section_id','=',$mcModel->id)
                ->get()->first();
             if (!isset($section->id)) {
                 $section = new ChecksheetChildSection();
                 $section->section_id = $mcModel->id;
                 $section->child_section = $line['child section'];
                 $section->save();

             }
         }
           if($line['subsection'] ) {
               $sub = ChecksheetSubChildSection::where('sub_child_section', '=', $line['subsection'])
                   //->where('section_id','=',$mcModel->id)
                   ->get()->first();
               if (!isset($sub->id)) {
                   $sub = new ChecksheetSubChildSection();
                   $sub->section_id = $mcModel->id;
                   $sub->child_id = $section->id;
                   $sub->sub_child_section = $line['subsection'];
                   $sub->save();

               }
           }*/
           if($line['columns'] ) {
               $colu = ChecksheetColumn::where('columns', '=', $line['columns'])
                   //->where('section_id','=',$mcModel->id)
                   ->get();
               if (!isset($colu->id)) {
                   $colu = new ChecksheetColumn();
                   $colu->section_id = $mcModel->id;
                   $colu->columns = $line['columns'];
                   $colu->save();

               }
           }
       /*  if ($line['Designation ']) {
                   $desig = MasterDesignation::where('designation', '=', $line['Designation '])->get()->first();
                   if (!isset($desig->id)) {
                       $desig = new MasterDesignation();
                       $desig->designation = $line['Designation '];
                       $desig->save();

                   }*/
                /*if($e['MACHINE SL NO']){
                       $mcSerialNumber=MasterMCSerialNumber::where('serial_no','=',$line['MACHINE SL NO'])
                           ->where('mc_model_id','=',$mcModel->id)
                           ->get()->first();
                       if(!isset($mcSerialNumber->id)) {
                           $mcSerialNumber = new MasterMCSerialNumber();
                           $mcSerialNumber->mc_model_id = $mcModel->id;
                           $mcSerialNumber->serial_no = $line['MACHINE SL NO'];
                           $mcSerialNumber->save();
                       }
                   }*/

                  /* if ($line['Name']) {
                       $compSerialNumber = MasterEmployee::where('name', '=', $line['Name'])
                           ->where('jobrole_id', '=', $mcModel->id)
                           //->where('designation_id', '=', $desig->id)
                           ->get()->first();
                       if (!isset($compSerialNumber->id)) {
                           $compSerialNumber = new MasterEmployee();
                           $compSerialNumber->section_id = $section->id;
                           $compSerialNumber->jobrole_id = $mcModel->id;
                           $compSerialNumber->name = $line['Name'];
                           $compSerialNumber->emp_code = $line['Emp Code'];
                           $compSerialNumber->designation_id =$desig->id;


                           $compSerialNumber->save();
                       }
                   }*/


                  //$obj->comp_serial_no = $line['COMPONENT_MC  SERIAL NO'];
                  //$obj->comp_type = $line['COMPONENT'];

             // }
         // }
        });



  }

    public function test3(Request $request)
    {
        $session = $request->session()->all();
        $users = (new FastExcel)->import($request->file('user_excel'), function ($line) {
            if($line['MACHINE MODEL'] !="" && $line['MACHINE MODEL']!=null){
                $emp=MasterMachine::where('machine_model_no','=',$line['MACHINE MODEL'])->get();
                if(!isset($emp[0]->machine_model_no)){
                    $obj=new User();
                    $obj->machine_model_no = $line['MACHINE MODEL'];
                    $obj->machine_serial_no = $line['MACHINE SL NO'];

                   // $obj->email = $line['Email'];
                    //$obj->password = Hash::make('123456');
                    //$obj->employee_code = $line['Employee_Code'];
                    $obj->save();

                    //echo $mail;exit;

                    /*****Email to Employee**********/
                }
            }

        });

        $excelfile = $request->file('user_excel');
        $tmp = explode('.', $excelfile->getClientOriginalName());
        $ext = end($tmp);
        $save_exlfile = time() . '.' . $ext;
        $destinationPath = 'public/assets/upload/sys_user';
        $excelfile->move($destinationPath, $save_exlfile);
        $users_upload = $save_exlfile;

        $activity=UserHelper::getRecentActivities($session['user']['user_id'],'uploaded User details',$session['user']['user_id'],'User',$session['user']['user_id'],$session['user']['name']);

        if($users){
            Session::flash('msg', 'User created successfully');
            Session::flash('alert-class', 'alert-success');
            return redirect('admin/userlist');
        }else{
            Session::flash('msg', 'Excel failed to upload!');
            Session::flash('alert-class', 'alert-danger');
            return redirect('admin/user-create');
        }

    }






  //super admin
    public function userAdd()
    {
        $title='Add User';


        return view('admin.user.addUser');
    }

    public function userAddStore(UserRequest $request)
    {
        //  $myrequest=$request->all();
        //dd($myrequest);

        $obj =new User();
        $obj->username = $request['username'];
        $obj->email = $request['email'];
        $obj->password=Hash::make($request['password']);

        $obj->status = $request['status'];
        $obj->save();

        //Assign Role
        foreach ($request['role'] as $role){
            $obj->assignRole($role);
        }


        return redirect('admin/super-admin-dashboard');

    }

    public function userList()
    {
        return view('admin.user.listUser');
    }

    public function getTableUser(Request $request)
    {

        $table =User::select('*')->get();


        $datatables =  Datatables::of($table)
            ->addColumn('roles', function ($table) {
                $str="";
                $roles=$table->getRoleNames();
                foreach($roles as $arrRole){
                    $rol_uc = str_replace("_"," ",$arrRole);
                    $rol_uc = ucwords($rol_uc);
                   $str .= $rol_uc.", ";
                }
                $roles=substr($str, 0, -2);

                return $roles;
            })

            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                <a class="dropdown-item" href="' . url('admin/user-edit')."/"."$table->id".'">EDIT</a>
                                                
                                            </div>
                                        </div>';

                return $btns;
                //$btns = ' <a href="' . url('admin/user-edit/' . $table->id) . '" class="btn btn-outline-success" >EDIT</a>';
                //  $btns .=' <a href="' . url('admin/cms-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                //return $btns;
            })

            ->rawColumns(['action','roles']);


        return $datatables->make(true);
    }

    public function userEdit($id)
    {
        $title='Edit User';
        $arrroles=[];
        $user=User::find($id);
        $roles=$user->getRoleNames();
        foreach($roles as $arrRole){
            array_push($arrroles, $arrRole);
        }
        $user->role=$arrroles;
        return view('admin.user.editUser')
            ->with('user',$user);
    }

    public function userEditStore(UserEditRequest $request)
    {
        //  $myrequest=$request->all();
        //dd($request);

        $obj=User::find($request['id']);
        $obj->username = $request['username'];

        $obj->email = $request['email'];
        if($request['password']!=NULL){
            $obj->password=Hash::make($request['password']);
        };

        $obj->status = $request['status'];
        $obj->save();

        //Delete Role
        $obj->roles()->detach();

        foreach ($request['role'] as $role){
            $obj->assignRole($role);
        }
        //$obj->removeRole($request['role']);

        //$obj->assignRole($request['role']);


        return redirect('admin/super-admin-dashboard');

    }

}
