<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CheckGateQuestionEditRequest;
use App\Http\Requests\CheckGateQuestionRequest;

use App\Models\MasterCheckGate;
use App\Models\MasterCheckGateInspectionQuestion;
use Illuminate\Http\Request;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;



use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
class CheckGateController extends Controller
{

  //super admin
    public function checkGateQuestionAdd()
    {
        $title='Add Questions';

        return view('admin.checkGateQuestion.addCheckGateQuestion');
    }

    public function checkGateQuestionAddStore(CheckGateQuestionRequest $request)
    {
        //  $myrequest=$request->all();
        //dd($myrequest);

        $obj =new MasterCheckGateInspectionQuestion();
        $obj->check_gate_id = $request['check_gate_id'];
        $obj->inspection_criteria = $request['inspection_criteria'];

        $obj->save();


        return redirect('admin/check-gate-question-list');

    }

    public function checkGateQuestionList()
    {
        return view('admin.checkGateQuestion.listCheckGateQuestion');
    }

    public function checkGateQuestionGetTable(Request $request)
    {

        //$table =MasterCheckGateInspectionQuestion::select('*')->get();
        $table = MasterCheckGateInspectionQuestion::select('gw_master_check_gate_inspection_question.*','gw_master_check_gate.name')
            ->leftjoin('gw_master_check_gate','gw_master_check_gate.id','=','gw_master_check_gate_inspection_question.check_gate_id')
            ->get();

        $datatables =  Datatables::of($table)
            /*->addColumn('roles', function ($table) {
                $str="";


                return $roles;
            })*/

            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                <a class="dropdown-item" href="' . url('admin/check-gate-question-edit')."/"."$table->id".'">EDIT</a>
                                                <a class="dropdown-item" href="' . url('admin/check-gate-question-delete')."/"."$table->id".'">DELETE</a>
                                            </div>
                                        </div>';

                return $btns;
                //$btns = ' <a href="' . url('admin/check-gate-question-edit/' . $table->id) . '" class="btn btn-outline-success" >EDIT</a>';
                  //$btns .=' <a href="' . url('admin/check-gate-question-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                //return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function checkGateQuestionEdit($id)
    {
        $title='Edit User';

        $ques=MasterCheckGateInspectionQuestion::find($id);

        return view('admin.checkGateQuestion.editCheckGateQuestion')
            ->with('ques',$ques);
    }

    public function checkGateQuestionEditStore(CheckGateQuestionEditRequest $request)
    {
        //  $myrequest=$request->all();
        //dd($request);

        $obj=MasterCheckGateInspectionQuestion::find($request['id']);

        $obj->check_gate_id = $request['check_gate_id'];
        $obj->inspection_criteria = $request['inspection_criteria'];

        $obj->save();

        return redirect('admin/check-gate-question-list');

    }
    public function checkGateQuestionDelete($user_id)
    {
        $qstn = MasterCheckGateInspectionQuestion::find($user_id);

        $qstn->delete();
        //dd($location);
        return redirect('admin/check-gate-question-list');
    }


}
