<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UserHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\DepartmentRequest;
use App\Http\Requests\MasterTaskRequest;
use App\Models\ChecksheetColumnStore;
use App\Models\ChecksheetSectionWiseColumn;
use App\Models\MasterDesignation;
use App\Models\MasterEmployee;
use App\Models\MasterMCModel;
use App\Models\MasterSection;
use App\Models\MasterTask;
use App\Models\ModelWiseCheecksheet;
use Illuminate\Http\Request;


use App\Models\MasterComponentModelNo;
use App\Models\MasterComponentDetails;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterBranch;
use App\Models\Service;
use App\Models\MasterDepartment;use App\Models\MasterMachineModelNo;
use App\Models\MasterCustomer;
use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;




use App\Http\Requests\BranchRequest;
use Spatie\Permission\Models\Role;

class MasterController extends Controller
{

    public function checksheetsectionAdd()
    {
        return view('admin.checksheet.addchecksheetsection');


    }

    public function checksheetsectionAddSave(Request $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new ModelWiseCheecksheet();
        $obj->dept_id = $request['dept_id'];
        $obj->model_id = $request['model_id'];
        $obj->section_id=implode(',',$request['section_id']);
        $obj->child_id = $request['childSection'];

        $obj->subsection_id = $request['subsect'];
        $obj->save();

        return redirect('admin/service-request-list');

    }
    public function checksheetcolumnAddSave(Request $request)
    {

        $obj1 = new ChecksheetColumnStore();
        $obj1->section_id=$request['section_id1'];
        $obj1->column_id = implode(',',$request['columnSection']);
        //$obj->section_id = $request['section_id'];
        $obj1->save();
        return redirect('admin/service-request-list');

    }
//json value show in checksheet section column selection
    public function childSectionShow(Request $request)
    {

        $childSelection = '';
        // $checkshtchildArr=explode(',',$request['checkshtchild']);
        $i = 0;
        foreach($request['checkshtchild'] as $checkshtchild){


            $compdet = UserHelper::childsectionchecksheet($checkshtchild);


            if (!isset($compdet->section_id)) {

                foreach ($compdet as $key => $value) {

                    $childSelection .= '<div class="custom-control form-control-lg custom-checkbox childSection">
                                            <input type="checkbox"  name="childSection[]" value="'.$value['id'].'" class="custom-control-input childSection_1" id="childSection'.$i.'">
                                            <label class="custom-control-label" for="childSection'.$i.'">'.$value['child_section'].'</label></div>';
                    $i++;
                }

            }
        }

        echo $childSelection;

    }

    public function subChildSectionShow(Request $request)
    {

        $subchildSelection = '';

        $i = 0;
        foreach($request['subsect'] as $subsect){

//print_r($subsect);
            $compdet = UserHelper::subChildsectionchecksheet($subsect);
    //echo'<pre>';print_r($compdet);exit;

            if (!isset($compdet->child_id)) {


                foreach ($compdet as $key => $value) {

                    $subchildSelection .= '<div class="custom-control form-control-lg custom-checkbox">
                                            <input type="checkbox"  name="subchildSection[]" value="'.$value['id'].'" class="custom-control-input childSection2" id="subchildSection'.$i.'">
                                            <label class="custom-control-label" for="subchildSection'.$i.'">'.$value['sub_child_section'].'</label></div>';
                    $i++;
                }

            }
        }

        echo $subchildSelection;




        // $machserial = UserHelper::machineserialno();
        /*   $compdet = UserHelper::subChildsectionchecksheet($request['subsect']);
           // dd($compdet);exit;
           $commod = '<option selected="selected" disabled="disabled">Select Sub Child Section</option>';
           if (!isset($compdet->child_id)) {
               foreach ($compdet as $key => $value) {
                   $commod .= '<option value=' . $value['id'] . '>' . $value['sub_child_section'] . '</option>';
               }
           }
           echo $commod;*/

    }

    public function columnSectionShow(Request $request)
    {

        $columnSelection = '';
        //print_r($request['columnchksht']);
        $checkshtchildArr = $request['columnchksht'];

        $i = 0;
        // foreach($request['columnchksht'] as $columnchksht){
        foreach($checkshtchildArr as $columnchksht){
            //

            // foreach(explode(',', $request->columnchksht) as $columnchksht){

            $compdet = UserHelper::columnforchecksheet($columnchksht);


            if (!isset($compdet->section_id)) {
                //echo "<pre>";print_r($compdet[0]['column_id']);echo "<br>";exit;
                foreach ($compdet as $key => $value) {

                    $columnSelection .= '<div class="custom-control form-control-lg custom-checkbox">
                                            <input type="checkbox"  name="columnSection[]" value="'.$value['column_id'].'" class="custom-control-input mainsection" id="columnSection'.$i.'">
                                            
                                            <label class="custom-control-label" for="columnSection'.$i.'">'.$value['column_name'].'</label></div>';

                    $i++;


                }

            }
        }




        echo $columnSelection ;

    }






    public function show()
    {
        return view('admin.dashboard.branch');


    }
    public function insertdata(BranchRequest $request)
    {
        // $data = $request->input();
        // dd($data);

        $obj = new MasterComponentModelNo();
        $obj->model_no = $request['model_no'];
        $obj->save();
        return redirect('admin/service-request-list');



    }



//fetch model_no
    public function fetch()
    {

        return view('admin.dashboard.fetchbranch');


    }

    public function fetchmodelGetTable(Request $request)
    {
        $table = MasterComponentModelNo::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    // public function fetchdata($id)
    //{
    // $title='Edit Service';

    //  $masterComponentModelNo=MasterComponentModelNo::find($id);

    //return view('admin.branchengineer.editmodelRequest')
    //  ->with('masterComponentModelNo',$masterComponentModelNo);
    //}
    public function fetchdata($id) {

        $errors = MasterComponentModelNo::find($id);


        return view('admin.branchengineer.editmodelRequest')
            ->with('errors',$errors);
    }


    public function update(Request $request)
    {

        $obj = MasterComponentModelNo::find($request['id']);

        $obj->model_no=$request['model_no'];
        $obj->save();
        return redirect('admin/fetch');


    }

    public function modelDelete($user_id)
    {
        $blog = MasterComponentModelNo::find($user_id);


        $blog->delete();

        return redirect('admin/fetch');
    }

    public function mastercustomer()
    {
        //$customerid = MasterCustomer::find('id');
        //$customername = MasterCustomer::select('name');
        return view ('admin.master.masterCustomer')	;
        //->with('customerid', $customerid)
        //->with('customername', $customername);




    }

    public function fetchcustomerGetTable(Request $request)
    {
        $table = MasterCustomer::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editcustomer/' . $table->id) . '">Edit</a>
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function editcustomer($id) {



        $errors = MasterCustomer::find($id);



        return view('admin.master.editcustomer')
            ->with('errors',$errors);



    }

    public function updatecustomer(Request $request)
    {
        $obj = MasterCustomer::find($request['id']);


        $obj->name=$request['name'];
        $obj->customer_code=$request['customer_code'];
        $obj->address=$request['address'];
        $obj->contact_details=$request['contact_details'];


        $obj->region=$request['region'];
        $obj->branch=$request['branch'];
        $obj->save();
        return redirect('admin/master-customer');

    }

    public function masterbranch()
    {
        return view('admin.master.masterbranch');
    }

    public function fetchbranchGetTable(Request $request)
    {
        $table = MasterBranch::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editbranch/' . $table->id) . '">Edit</a>
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editbranch($id) {

        $errors =  MasterBranch::find($id);




        return view('admin.master.editbranch')
            ->with('errors',$errors);
    }

    public function updatebranch(Request $request)
    {
        $obj = MasterBranch::find($request['id']);

        $obj->sales_ofc=$request['sales_ofc'];
        $obj->sales_ofc_code=$request['sales_ofc_code'];
        $obj->save();
        return redirect('admin/master-branch');
    }

    public function mastercomp()
    {
        $title='';
        return view('admin.master.mastercomponentserial')
            ->with('title',$title);
    }

    public function fetchcompserial(Request $request)
    {
        $table = MasterComponentDetails::Select ('gw_master_comp_details.id','gw_master_component_model_no.model_no','gw_master_comp_details.comp_model_no','gw_master_comp_details.comp_serial_no','gw_master_comp_details.comp_type')-> leftjoin('gw_master_component_model_no' , 'gw_master_component_model_no.id','=','gw_master_comp_details.mc_model_id')->get();



        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editcomponent/' . $table->id) . '">Edit</a>
                                   </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function editcomponent($id)
    {
        $mcComponent =  MasterComponentDetails::find($id);
        return view('admin.master.editcomponent')
            ->with('mcComponent',$mcComponent);

    }



    public function updatecomponent(Request $request)
    {
        $obj = MasterComponentDetails::find($request['id']);

        $obj->comp_model_no=$request['comp_model_no'];
        $obj->comp_serial_no=$request['comp_serial_no'];
        $obj->comp_type=$request['comp_type'];
        $obj->save();
        return redirect('admin/comp-details');
    }

    public function mastermodelserial()
    {
        $title='';
        return view('admin.master.mastermcmodel')
            ->with('title',$title);
    }

    public function fetchmodelserial(Request $request)

    {
        /*$table=MasterMCModel::Select('gw_master_mc_model.model_no','gw_master_mc_serial_number.serial_no','gw_master_comp_details.comp_type','gw_master_comp_details.comp_model_no','gw_master_comp_details.comp_serial_no')->join('gw_master_mc_serial_number','gw_master_mc_serial_number.mc_model_id','=','gw_master_mc_model.id')->join('gw_master_comp_details','gw_master_comp_details.mc_model_id','=','gw_master_mc_model.id')->get();*/

        $table=MasterMCModel::Select('gw_master_mc_model.model_no','gw_master_mc_serial_number.serial_no','gw_master_comp_details.comp_type','gw_master_comp_details.comp_model_no','gw_master_comp_details.comp_serial_no')
            ->LeftJoin('gw_master_mc_serial_number','gw_master_mc_serial_number.mc_model_id','=','gw_master_mc_model.id')
            ->LeftJoin('gw_master_comp_details','gw_master_comp_details.mc_model_id','=','gw_master_mc_model.id')->get();
        //  echo '<pre>';print_r($table);exit;
        //dd($table);
        // exit();
        /* $table = MasterMCSerialNumber::Select ('gw_master_mc_serial_number.id','gw_master_mc_serial_number.serial_no','gw_master_mc_model.model_no')
         ->leftJoin('gw_master_mc_model' , 'gw_master_mc_model.id','=','gw_master_mc_serial_number.mc_model_id')
             ->get();

         $fetchcomp = MasterComponentDetails::Select('gw_master_comp_details.id','gw_master_comp_details.comp_model_no','gw_master_comp_details.comp_serial_no','gw_master_comp_details.comp_type')
             ->leftjoin('gw_master_mc_model','gw_master_mc_model.id','=','gw_master_comp_details.mc_model_id')->get();
 */
        $datatables = Datatables::of($table)

            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editmachine/' . $table->id) . '">Edit</a>
                                   </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }



    public function editmachine($id)
    {

        /*$table = MasterMCSerialNumber::Select ('gw_master_mc_serial_number.id','gw_master_mc_serial_number.serial_no','gw_master_mc_serial_number.created_at','gw_master_mc_model.model_no')
        ->leftJoin('gw_master_mc_model' , 'gw_master_mc_model.id','=','gw_master_mc_serial_number.mc_model_id')
        ->get();*/

        //$errors =  MasterMCSerialNumber::find($id);
        $mcMachine =  MasterMCSerialNumber::find($id);
        return view('admin.master.editmachine')
            ->with('mcMachine',$mcMachine);




        //  return view('admin.master.editmachine')
        //->with('table',$table);
        //    ->with('errors',$errors);

    }
    public function updatemachine(Request $request)
    {
        $obj = MasterMCSerialNumber::find($request['id']);


        $obj->serial_no=$request['serial_no'];

        $obj->save();
        return redirect('admin/master-machine');
    }
    public function mastertask()
    {
        $items = MasterTask::all();
        //$machinemodel = MasterTask::select('machine_modelwise_task.dept_id', 'gw_master_department.name')->leftjoin('gw_master_department',
        //    'gw_master_department.id', '=', 'machine_modelwise_task.id')->get();
        $deptname = MasterDepartment::select('gw_master_department.id','gw_master_department.name')->get();
        $modelno=MasterMachineModelNo::select('gw_master_machine_model_no.id','gw_master_machine_model_no.model_no')->get();
        $selecttask=MasterTask::select('machine_modelwise_task.*')->get();
        return view ('admin.superadmin.machinemodelwisetask', compact('items'))
            ->with('selecttask',$selecttask)
            ->with('deptname',$deptname)
            ->with('modelno',$modelno);



    }

    public function insertmastertask(MasterTaskRequest $request)


    {

        $obj = new MasterTask();
        $obj->dept_id=$request['dept_id'];
        $obj->model_no=$request['model_no'];
        $obj->name	=$request['name'];
        //$obj->name	=$request['name'];
        $obj->description=$request['description'];
        //$obj->sub_task=$request['sub_task'];
        $obj->tat=$request['tat'];
        $obj->parent=$request['parent'];
        $obj->predicessor=implode(',',$request['predicessor']);

        $obj->relation_type=$request['relation_type'];
        $obj->sort_order=$request['sort_order'];
        $obj->save();
        return redirect('admin/fetchmodelwisetask');


    }




    public function fetchmachinetask()
    {
        $table = Service::Select('service_request.id', 'service_request.checkgate1')->WHERE('checkgate1','!=',NULL)->get();
        //  echo '<pre>';
        //print_r($table);
        //exit;


        return view('admin.superadmin.machinemodelwisetasklisting');

    }
    public function fetchmachinemodeltask(Request $request)
    {









        $table = MasterTask::select('*')->get();




        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editmachinetask/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/deletemachinetask/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }
    public function editmachinetask($id) {

        $errors =  MasterTask::find($id);


        return view('admin.superadmin.editMachineModelTask')
            ->with('errors',$errors);
    }
    public function updatemachinetask(Request $request)
    {
        $obj = MasterTask::find($request['id']);

        $obj->name=$request['name'];
        $obj->tat=$request['tat'];
        $obj->predicessor=$request['predicessor'];
        $obj->relation_type=$request['relation_type'];
        $obj->save();
        return redirect('admin/fetchmodelwisetask');

    }
    public function deletemachinetask($user_id)
    {
        $machinetask = MasterTask::find($user_id);


        $machinetask->delete();

        return redirect('admin/fetchmodelwisetask');
    }









    //master employee name and code
    public function employeetNameList()
    {
        return view('admin.master.listEmployeeName');

    }
    public function employeeNameGetTable(Request $request)
    {
        $table = MasterEmployee::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    //employee section designation role
    public function employeetSectionDesigRoleList()
    {
        return view('admin.master.listEmployeeSectionDesigRole');


    }

    public function sectionAddSave(Request $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new MasterSection();
        $obj->section = $request['section'];
        $obj->save();
        return redirect('admin/employee-section-desig-role-list');

    }

    public function designationAddSave(Request $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new MasterDesignation();
        $obj->designation = $request['designation'];
        $obj->save();
        return redirect('admin/employee-section-desig-role-list');

    }
    public function jobroleAddSave(Request $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new Role();
        $obj->name = $request['name'];
        $obj->guard_name = 'web';
        $obj->save();
        return redirect('admin/employee-section-desig-role-list');

    }

    public function sectionGetTable(Request $request)
    {
        $table = MasterSection::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function designationGetTable(Request $request)
    {
        $table = MasterDesignation::select('*')->get();


        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function jobroleGetTable(Request $request)
    {
        $table = Role::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }



    //employee details

    public function employeeDetailsAdd()
    {
        return view('admin.master.addEmployeeDetails');


    }

    public function employeeDetailsAddSave(Request $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new MasterEmployee();
        $obj->name = $request['name'];
        $obj->emp_code = $request['emp_code'];
        $obj->section_id = $request['section_id'];
        $obj->designation_id = $request['designation_id'];
        $obj->jobrole_id = $request['jobrole_id'];
        $obj->save();
        return redirect('admin/employee-detsils-list');

    }




    public function employeeDetailsList()
    {
        return view('admin.master.listEmployeeDetails');


    }
    public function employeeDetailsGetTable(Request $request)
    {
        //$table = MasterEmployee::select('*')->get();
        $table = MasterEmployee::select('gw_master_employee.*','gw_master_section.section','gw_master_designation.designation','roles.name as jobrole')
            ->join('gw_master_section','gw_master_section.id','=','gw_master_employee.section_id')
            ->join('gw_master_designation','gw_master_designation.id','=','gw_master_employee.designation_id')
            ->join('roles','roles.id','=','gw_master_employee.jobrole_id')
            //->groupby('gw_master_employee.section_id')
            ->get();


        // $table = MasterDesignation::select('*')->get();
        //$section=App\Helpers\UserHelper::section();



        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/fetchdata/' . $table->id) . '">Edit</a>
                                 <a class="dropdown-item" href="' . url('admin/model-delete/') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    //service depertment
    public function servicedepartment()



    {
        $masterdesignation=MasterDesignation::get();
        return view('admin.branchengineer.servicedepartment')
            ->with('masterdesignation','$masterdesignation');



    }
    public function insertservicedepartment(DepartmentRequest $request)
    {
        // $data = $request->input();
        // dd($data);
        $obj = new MasterEmployee();
        $obj->name = $request['name'];
        $obj->designation_id = $request['designation_id'];
        $obj->phone_no = $request['phone_no'];
        $obj->email = $request['email'];
        $obj->save();
        return redirect('admin/fetchservicedepartment');


    }



    public function fetchservicedepartment()
    {


        return view('admin.branchengineer.servicedepartmentlisting');


    }

    public function fetchdepartment(Request $request)
    {
        $table = MasterEmployee::select('*')->get();




        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {



                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/servicedepartment/' ) . '">ADD</a>
                                 <a class="dropdown-item" href="' . url('#') . "/". "$table->id" . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">EDIT</a>                              </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editservicedepartment($id)
    {
        $deptemployee =  MasterEmployee::find($id);
        return view('admin.branchengineer.editservicedepartment')
            ->with('deptemployee',$deptemployee);



    }




}
