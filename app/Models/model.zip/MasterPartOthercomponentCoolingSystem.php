<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterPartOthercomponentCoolingSystem extends Model

{

    protected $table='gw_parts_othercomponent_cooling_system';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        // 'name', 'email', 'password',
    ];


    /*
        protected $primaryKey = "";
        public $incrementing = false;
        public $timestamps = false;
    */
}













