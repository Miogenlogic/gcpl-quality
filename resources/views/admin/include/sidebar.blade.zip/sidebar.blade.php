<nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header d-flex align-items-center">
            <a class="navbar-brand" href="{{url('admin/admin-dashboard')}}">
                <img src="{{URL::asset('public/assets/img/brand/blue.png')}}" class="navbar-brand-img" alt="Logo">
            </a>
            <div class="ml-auto">
                <!-- Sidenav toggler -->
                <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
                    <div class="sidenav-toggler-inner">
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                    </div>
                </div>
            </div>
        </div>
        <ul class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link {{(Request::is('*/admin/*dashboard*')) ?'active':''}}" href="

                            @hasrole('super_admin') {{url('admin/super-admin-dashboard')}} @endrole
                            @hasrole('branch_engineer')  {{url('admin/branch-dashboard')}} @endrole
                            @hasrole('crc_head')  {{url('admin/crc-head-dashboard')}} @endrole
                            @hasrole('spc')  {{url('admin/spc-dashboard')}} @endrole
                            @hasrole('section_supervisor')  {{url('admin/section-supervisor-dashboard')}} @endrole
                            @hasrole('section_engineer')  {{url('admin/section-engineer-dashboard')}} @endrole
                            @hasrole('qa_qc') {{url('admin/qaqc-dashboard')}} @endrole
                            @hasrole('planning_supervisor')  {{url('admin/planning-supervisor-dashboard')}} @endrole
                            @hasrole('store_manager') {{url('admin/store-manager-dashboard')}} @endrole
                            @hasrole('despatch_manager')  {{url('admin/despatch-manager-dashboard')}} @endrole
                            @hasrole('receiving')  {{url('admin/receiving-dashboard')}} @endrole
                            @hasrole('service_engineer')  {{url('admin/service-engineer-dashboard')}} @endrole
                             @hasrole('dept_eng')  {{url('admin/engine-dashboard')}} @endrole
                              @hasrole('dept_eng_disassembly')  {{url('admin/engine-dashboard')}} @endrole
                               @hasrole('dept_eng_assembly')  {{url('admin/engine-dashboard')}} @endrole
                                @hasrole('dept_trans')  {{url('admin/trans-dashboard')}} @endrole
                                 @hasrole('dept_trans_assembly')  {{url('admin/trans-dashboard')}} @endrole
                                 @hasrole('dept_trans_disassembly')  {{url('admin/trans-dashboard')}} @endrole
                                 @hasrole('dept_hyd')  {{url('admin/hyd-dashboard')}} @endrole
                                 @hasrole('dept_hyd_assembly')  {{url('admin/hyd-dashboard')}} @endrole
                                 @hasrole('dept_hyd_disassembly')  {{url('admin/hyd-dashboard')}} @endrole
                                 @hasrole('dept_mor')  {{url('admin/mor-dashboard')}} @endrole
                                 @hasrole('dept_mor_asembly')  {{url('admin/mor-dashboard')}} @endrole
                                 @hasrole('dept_mor_disasembly')  {{url('admin/mor-dashboard')}} @endrole
                                 @hasrole('dept_undercarriage')  {{url('admin/undercarg-dashboard')}} @endrole
                                 @hasrole('dept_undercarriage_assembly')  {{url('admin/undercarg-dashboard')}} @endrole
                                 @hasrole('dept_undercarriage_disassembly')  {{url('admin/undercarg-dashboard')}} @endrole
                              @hasrole('support')  {{url('admin/support-dashboard')}} @endrole
                               @hasrole('eng_head')  {{url('admin/eng-head-dashboard')}} @endrole
                            ">
                            <i class="ni ni-shop text-primary"></i>
                            <span class="nav-link-text">Dashboards</span>
                        </a>

                    </li>
                </ul>
                <ul class="navbar-nav">

                    <li class="nav-item">
                        <a class="nav-link {{(Request::is('admin/service-request')) ?'active':''}}" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="{{(Request::is('admin/service-request*')) ?'true':'false'}}"
                           aria-controls="navbar-examples">
                            <i class="ni ni-briefcase-24 text-orange"></i>
                            <span class="nav-link-text">Menu</span>
                        </a>

                        <!-- Menu structure -->
                        <div class="collapse {{(Request::is('admin/service-request*')) ?'show':''}}" id="navbar-examples">
                            <!--- THIS IS FOR BRANCH -->
                            @if (request()->session()->get('user')['section_id'] == '1')



                                <ul class="nav nav-sm flex-column">








                                @if(request()->session()->get('user')['role_id'] == '1')
                                    <!-- <li class="nav-item">
                                            <a href="{{url('admin/service-request-add')}}" class="nav-link {{((Request::is('admin/service-request-add')) || (Request::is('admin/service-request-add')) )?'active':''}}">Create Service Request</a>
                                        </li>-->
                                    @endif

                                    <li class="nav-item">
                                        <a href="{{url('admin/service-request-list')}}" class="nav-link {{((Request::is('admin/service-request-list')) || (Request::is('admin/service-request-list')) )?'active':''}}">Service Request</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{url('admin/quotation-list')}}" class="nav-link {{url('admin/quotation-list')}}" class="nav-link {{((Request::is('admin/quotation-list'))  )?'active':''}}">Download Quatation & view Quatation</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{url('admin/spc-dashboard')}}" class="nav-link {{url('admin/spc-dashboard')}}" class="nav-link {{((Request::is('admin/spc-dashboard'))  )?'active':''}}">Upload PO</a>
                                    </li>
                                </ul>
                            @endif
                        <!--- END OF BRANCH MENU -->

                            <!--- THIS IS FOR SUPPORT -->
                            @if (request()->session()->get('user')['section_id'] == '2')<!--all-->
                            <ul class="nav nav-sm flex-column">
                            @if(request()->session()->get('user')['role_id'] == '1')<!--engineer-->
                                <li class="nav-item">
                                    <a href="{{url('admin/service-request-list')}}" class="nav-link {{((Request::is('admin/service-request-list')) || (Request::is('admin/service-request-list')) )?'active':''}}">Service Request</a>
                                </li>
                            @endif
                            <!-- <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Open Workorder in SAP</a>
                                    </li>-->
                                <li class="nav-item">
                                    <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">SPC Upload Quotation</a>
                                </li>
                            </ul>
                            @endif
                        <!--- END OF SUPPORT MENU -->

                            <!--- THIS IS FOR RECEIVING -->
                            @if (request()->session()->get('user')['section_id'] == '3')
                                <ul class="nav nav-sm flex-column">
                                    @if(request()->session()->get('user')['role_id'] == '1')
                                        <li class="nav-item">
                                            <a href="{{url('admin/servicedashboard-checkgateone')}}" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/check-gate-form-one-add/id')) )?'active':''}}">Create Check Gate 1</a>
                                        </li>
                                    @endif
                                    <li class="nav-item">
                                        <a href="{{url('admin/check-gate-form-one-listing/{id}')}}" class="nav-link {{((Request::is('check-gate-form-one-listing/{id}')) || (Request::is('check-gate-form-one-listing/{id}')) )?'active':''}}">View Check Gate One</a>
                                    </li>
                                </ul>
                            @endif
                        <!--- END OF RECEIVING MENU -->

                            <!--- THIS IS FOR ENG. DISASMLY -->
                            @if (request()->session()->get('user')['section_id'] == '4')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateone')) || (Request::is('admin/check-sheet-entry-common/{id}')) )?'active':''}}">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="{{url('admin/servicedashboard-checkgatetwo')}}" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servicedashboard-checkgatetwo')) )?'active':''}}">Enter Check Gate 2 </a>
                                    </li>
                                    <!--<li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Download Checklist in Excel</a>
                                    </li>-->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">Create / Update Quotation in SAP</a>
                                    </li>
                                @endif

                                @if(request()->session()->get('user')['role_id'] == '2')<!-- Head -->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Disassembly Checklist</a>
                                    </li>
                                @endif
                                <!-- NOT Confirmed YET-->
                                </ul>
                            @endif
                        <!--- END OF ENG. DISASMLY MENU -->

                            <!--- THIS IS FOR TRAN. DISASMLY -->
                            @if (request()->session()->get('user')['section_id'] == '5')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateone')) || (Request::is('admin/servicedashboard-checkgateone')) )?'active':''}}">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgatetwo" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servicedashboard-checkgatetwo')) )?'active':''}}">Enter Check Gate 2 </a>
                                    </li>


                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">Create / Update Quotation in SAP</a>



                                    </li>
                                @endif

                                @if(request()->session()->get('user')['role_id'] == '2')<!-- Head -->
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgatetwo" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servicedashboard-checkgatetwo')) )?'active':''}}">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateone')) || (Request::is('admin/servirequest')) )?'active':''}}">View Disassembly Checklist</a>
                                    </li>
                                @endif
                                <!-- NOT Confirmed YET-->
                                </ul>
                            @endif
                        <!--- END OF TRAN. DISASMLY MENU -->

                            <!--- THIS IS FOR HYD. COMP. DISASMLY -->
                            @if (request()->session()->get('user')['section_id'] == '12')











                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateone')) || (Request::is('admin/servicedashboard-checkgateone')) )?'active':''}}">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgatetwo" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servicedashboard-checkgatetwo')) )?'active':''}}">Enter Check Gate 2 </a>
                                    </li>



                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Download Checklist in Excel</a>



                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">Create / Update Quotation in SAP</a>



                                    </li>
                                @endif

                                @if(request()->session()->get('user')['role_id'] == '2')<!-- Head -->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Check Gate Two</a>



                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Disassembly Checklist</a>
                                    </li>
                                @endif
                                <!-- NOT Confirmed YET-->
                                </ul>
                            @endif
                        <!--- END OF HYD. COMP. DISASMLY MENU -->

                            <!--- THIS IS FOR MOR -->
                            @if (request()->session()->get('user')['section_id'] == '6')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">

                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateon')) || (Request::is('admin/servicedashboard-checkgateon')) )?'active':''}}">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgatetwo" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Download Checklist in Excel</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">Create / Update Quotation in SAP</a>
                                    </li>
                                @endif

                                @if(request()->session()->get('user')['role_id'] == '2')<!-- Head -->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Disassembly Checklist</a>
                                    </li>
                                @endif
                                <!-- NOT Confirmed YET-->
                                </ul>
                            @endif
                        <!--- END OF MOR MENU -->

                            <!--- THIS IS FOR UNDERCARRIGE -->
                            @if (request()->session()->get('user')['section_id'] == '7')

                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->

                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgateone" class="nav-link {{((Request::is('admin/servicedashboard-checkgateone')) || (Request::is('admin/servicedashboard-checkgateone')) )?'active':''}}">Enter / Update  Disassembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="servicedashboard-checkgatetwo" class="nav-link {{((Request::is('admin/servicedashboard-checkgatetwo')) || (Request::is('admin/servicedashboard-checkgatetwo')) )?'active':''}}">Enter Check Gate 2 </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Download Checklist in Excel</a>



                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/support-quotation-list')) || (Request::is('admin/support-quotation-list')) )?'active':''}}">Create / Update Quotation in SAP</a>



                                    </li>
                                @endif

                                @if(request()->session()->get('user')['role_id'] == '2')<!-- Head -->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Check Gate Two</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Disassembly Checklist</a>
                                    </li>
                                @endif
                                <!-- NOT Confirmed YET-->
                                </ul>
                            @endif
                        <!--- END OF UNDERCARRIGE MENU -->

                            <!--- THIS IS FOR SPC -->
                            @if (request()->session()->get('user')['section_id'] == '20')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '3')<!--Engineer-->
                                <!--<li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Update Service Request</a>
                                    </li>-->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Project Plan</a>
                                    </li>
                                    @endif
                                </ul>
                            @endif
                        <!--- END OF SPC MENU -->

                            <!--- THIS IS FOR STORE -->
                            @if (request()->session()->get('user')['section_id'] == '9')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Receive Material</a>
                                    </li>
                                <!-- <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View & Update Task List</a>
                                    </li-->>
                                @endif
                                @if(request()->session()->get('user')['role_id'] == '2')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="fetchmodelwisetask" class="nav-link {{((Request::is('admin/fetchmodelwisetask')) || (Request::is('admin/fetchmodelwisetask')) )?'active':''}}">Task Listing</a>
                                    </li>
                                    @endif
                                </ul>
                            @endif
                        <!--- END OF STORE MENU -->

                            <!--- THIS IS FOR ENG ASSEMBLY & TESTING SECTION -->
                            @if (request()->session()->get('user')['section_id'] == '10')
                                <ul class="nav nav-sm flex-column">
                                @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter / Update Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="bis-listing" class="nav-link {{((Request::is('admin/bis-listing')) || (Request::is('admin/bis-listing')) )?'active':''}}">Enter BIS Report</a>
                                    </li>
                                    @endif
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Assembly Checklist</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Checkgate Three & Update Task Status</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View BIS Report</a>
                                    </li>
                                </ul>
                        @endif
                        <!--- END OF ENG ASSEMBLY & TESTING SECTION MENU -->

                        </div>

                    </li>
                    <!-- THIS IS FOR TRANSMISSION ASSEMBLY -->
                    @if (request()->session()->get('user')['section_id'] == '12')
                        <ul class="nav nav-sm flex-column">
                        @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter / Update Assembly Checklist</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter Checkgate Three & Update Task Status</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter BIS Report</a>
                            </li>
                            @endif
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Assembly Checklist</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Checkgate Three & Update Task Status</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View BIS Report</a>
                            </li>
                        </ul>
                    @endif
                <!--- END OF TRANSMISSION ASSEMBLY -->



                    <!-- THIS IS FOR HYDRAULIC COMPONENT -->
                    @if (request()->session()->get('user')['section_id'] == '13')
                        <ul class="nav nav-sm flex-column">
                        @if(request()->session()->get('user')['role_id'] == '1')<!--Engineer-->
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter / Update Assembly Checklist</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter Checkgate Three & Update Task Status</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Enter BIS Report</a>
                            </li>
                            @endif
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Assembly Checklist</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View Checkgate Three & Update Task Status</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">View BIS Report</a>
                            </li>
                        </ul>
                @endif
                <!--- END OF HYDRAULIC COMPONENT -->





            </div>
            <!-- Menu structure end -->
            </li>
        </ul>
    </div>
    </ul>
    </div>
</nav>

























{{--@if(request()->session()->get('user')['role_id'] == '1')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/check-gate-form-one')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Check Gate One</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endif--}}
{{----}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/service-request-latest-list')}}" class="nav-link"><i class="ni ni-briefcase-24 text-orange"></i>Check gate 1 view</a>--}}
{{--</li>--}}
{{----}}
{{----}}
{{--@hasrole('branch_engineer')--}}
{{----}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link {{(Request::is('admin/service-request*')) ?'active':''}}" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="{{(Request::is('admin/service-request*')) ?'true':'false'}}"--}}
{{--aria-controls="navbar-examples">--}}
{{--<i class="ni ni-briefcase-24 text-orange"></i>--}}
{{--<span class="nav-link-text">Service request</span>--}}
{{--</a>--}}
{{--<div class="collapse {{(Request::is('admin/service-request*')) ?'show':''}}" id="navbar-examples">--}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/service-request-add')}}" class="nav-link {{((Request::is('admin/service-request-add')) || (Request::is('admin/service-request-add-save')) )?'active':''}}">New service request</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/service-request-list')}}" class="nav-link {{url('admin/service-request-add')}}" class="nav-link {{((Request::is('admin/service-request-list'))  )?'active':''}}">All service request</a>--}}
{{--</li>--}}

{{--</ul>--}}

















{{--</a>--}}
{{--</div>--}}















{{--</li>--}}































{{--<li class="nav-item">--}}





























{{--<div class="collapse {{(Request::is('admin/service-request*')) ?'show':''}}" id="navbar-examples">--}}
{{--<ul class="nav nav-sm flex-column">--}}













{{--</ul>--}}
{{--</div>--}}
{{--</li>--}}















































{{--<li class="nav-item">--}}
{{--<a class="nav-link " href="{{url('admin/quotation-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Quotations</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link {{(Request::is('admin/*')) ?'active':''}}" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="{{(Request::is('admin/*')) ?'true':'false'}}"--}}
{{--aria-controls="navbar-examples">--}}
{{--<i class="ni ni-briefcase-24 text-orange"></i>--}}
{{--<span class="nav-link-text">Master</span>--}}
{{--</a>--}}
{{--<div class="collapse {{(Request::is('admin/branch-request*')) ?'show':''}}" id="navbar-examples">--}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/branch-list')}}" class="nav-link {{((Request::is('admin/branch-list')) || (Request::is('admin/branch-list')) )?'active':''}}">Branch</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/segment-list')}}" class="nav-link {{url('admin/segment-list')}}" class="nav-link {{((Request::is('admin/segment-list'))  )?'active':''}}">Segment</a>--}}
{{--</li>--}}
{{--</ul>--}}
{{--</div>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link " href="{{url('admin/branch-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Branch</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link " href="{{url('admin/segment-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Segment</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{----}}

{{--@hasrole('super_admin')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link active" href="#navbar-examples-mas" data-toggle="collapse" role="button" aria-expanded="false"--}}
{{--aria-controls="navbar-examples-mas">--}}
{{--<i class="ni ni-briefcase-24 text-orange"></i>--}}
{{--<span class="nav-link-text">Master</span>--}}
{{--</a>--}}
{{--<div class="collapse show" id="navbar-examples-mas">--}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/user-list')}}" class="nav-link">User List</a>--}}
{{--</li>--}}
{{--<a href="{{url('admin/master-customer')}}" class="nav-link">Customer</a>--}}

{{--<a href="{{url('admin/master-branch')}}" class="nav-link">Branch</a>--}}
{{--<a href="{{url('admin/master-machine')}}" class="nav-link">Machine details</a>--}}
{{--<a href="{{url('admin/fetchmodelwisetask')}}" class="nav-link">Task Details</a>--}}


{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/employee-detsils-list')}}" class="nav-link">Employee Details</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/employee-section-desig-role-list')}}" class="nav-link">Section Designation</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/branch-list')}}" class="nav-link {{((Request::is('admin/branch-list')) || (Request::is('admin/branch-list')) )?'active':''}}">Branch</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/segment-list')}}" class="nav-link {{url('admin/segment-list')}}" class="nav-link {{((Request::is('admin/segment-list'))  )?'active':''}}">Segment</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/fetch')}}" class="nav-link">Component Model List</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/fetchserial')}}" class="nav-link">Component Serial List</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/fetchmachinemodel')}}" class="nav-link">Machine Model List</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/fetch-machine-serial')}}" class="nav-link">Machine Serial List</a>--}}
{{--</li>--}}

{{--</ul>--}}
{{--</div>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link active" href="#navbar-examples-pro" data-toggle="collapse" role="button" aria-expanded="false"--}}
{{--aria-controls="navbar-examples">--}}
{{--<i class="ni ni-briefcase-24 text-orange"></i>--}}
{{--<span class="nav-link-text">Projects</span>--}}
{{--</a>--}}
{{--<div class="collapse show" id="navbar-examples-pro">--}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/projects-open-list')}}" class="nav-link">Open projects</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/projects-completed-list')}}" class="nav-link active">Completed projects</a>--}}
{{--</li>--}}
{{--</ul>--}}
{{--</div>--}}
{{--</li>--}}
{{--@endrole--}}

{{--@hasrole('service_engineer')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/check-sheet-entry')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Check Sheet Entry</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/service-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Service List</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('support')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/support-quotation-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Upload Quotation</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}


{{--@hasrole('dept_eng')--}}
{{--@if(request()->session()->get('user')['role_id'] == '1' && request()->session()->get('user')['section_id'] == '4')--}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{----}}
{{--<a href="{{url('admin/servirequest')}}" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">aaaaaa</a>--}}
{{--</li>--}}
{{--@endif--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/engine-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Engine Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="#">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Engine Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--</ul>--}}
{{--@endrole--}}

{{--@hasrole('dept_eng_disassembly')--}}
{{----}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link {{(Request::is('admin/service-request')) ?'active':''}}" href="#navbar-examples" data-toggle="collapse" role="button" aria-expanded="{{(Request::is('admin/service-request*')) ?'true':'false'}}"--}}
{{--aria-controls="navbar-examples">--}}
{{--<i class="ni ni-briefcase-24 text-orange"></i>--}}
{{--<span class="nav-link-text">Menu</span>--}}
{{----}}
{{--</a>--}}
{{----}}
{{--<!-- Menu structure -->--}}
{{----}}
{{----}}
{{--<div class="collapse {{(Request::is('admin/service-request*')) ?'show':''}}" id="navbar-examples">--}}
{{----}}
{{----}}
{{--<ul class="nav nav-sm flex-column">--}}
{{--<li class="nav-item">--}}
{{----}}
{{--<a href="{{url('admin/servirequest')}}" class="nav-link {{((Request::is('admin/servirequest')) || (Request::is('admin/servirequest')) )?'active':''}}">Create Service Request</a>--}}
{{--</li>--}}
{{----}}
{{--<!--@if(request()->session()->get('user')['role_id'] == '1' && request()->session()->get('user')['section_id']=='4')--}}
{{----}}
{{--<li class="nav-item">--}}
{{--<a href="{{url('admin/engine-diss-list')}}" class="nav-link {{((Request::is('admin/engine-diss-list')) || (Request::is('admin/engine-diss-list')) )?'active':''}}">Engine Disassembly</a>--}}
{{--</li>--}}
{{----}}
{{----}}
{{--@endif-->--}}
{{----}}
{{--@endrole--}}

{{--@hasrole('dept_eng_assembly')--}}
{{--@if(request()->session()->get('user')['role_id'] == '1') && ['section_id']=='10')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="#">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Engine Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endif--}}
{{--@endrole--}}

{{--@hasrole('dept_trans')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/trans-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Trans Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Trans Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_trans_assembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Trans Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_trans_disassembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/trans-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Trans Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{--@hasrole('dept_hyd')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/hyd-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Hyd Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Hyd Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_hyd_assembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Hyd Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_hyd_disassembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/hyd-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Hyd Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{--@hasrole('dept_mor')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/mor-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">MOR Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">MOR Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{--@hasrole('dept_mor_asembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">MOR Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_mor_disasembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/mor-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">MOR Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{--@hasrole('dept_undercarriage')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/undercarg-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Undercarriage Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Undercarriage Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_undercarriage_assembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Undercarriage Assembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}
{{--@hasrole('dept_undercarriage_disassembly')--}}
{{--<li class="nav-item">--}}
{{--<a class="nav-link" href="{{url('admin/undercarg-diss-list')}}">--}}
{{--<i class="ni ni-archive-2 text-green"></i>--}}
{{--<span class="nav-link-text">Undercarriage Disassembly</span>--}}
{{--</a>--}}
{{--</li>--}}
{{--@endrole--}}

{{--</ul>--}}

{{--</div>--}}
{{--</div>--}}
{{--</div>--}}
{{--</nav>--}}

