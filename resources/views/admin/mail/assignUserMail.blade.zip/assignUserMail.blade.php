Dear Sir,<br>

You are assigned for this Service Request Number:<br>
and Work Order Number:<br>


@php
//echo'<pre>';print_r($serviceno);print_r($workorder);exit;--}}
@endphp
<br>
Thanks,