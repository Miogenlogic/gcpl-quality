@extends('admin.include.layout')
@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Edit BIS Checksheet</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Edit BIS Checksheet</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    @php
       // print_r($servicerequest);
       // die;
	 // $bischeck=App\Helpers\UserHelper::bis();
    @endphp

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{ url('/admin/save-bis')}}" enctype="multipart/form-data">
                <div class="row">
						<input type ="hidden" name="bisid" value="{{Request::segment(3)}}">
                      <!-- <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Job No</label>
							
                            <input type="text" name="job_no" class="form-control" id="service" value="{{old('job_no')?old('job_no'):$servicerequest->job_no}}" readonly>
                           
                        </div>
                    </div>-->
                      <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Department</label>
							<!--<input name="dept_id" id="dept_id" class="form-control"  readonly-->
                               
                                @foreach( $department as  $dept)
									<option selected="selected" name="dept_id" id="dept_id" class="form-control value="{{$dept->id}}" readonly>
                                        {{ $dept->name}}
										</option>
                                   @endforeach

                               

                        </div>
                    </div>

                       <div class="col-sm-6 col-md-3">
                        <div class="form-group">
						<lable for="name">Technician</lable>
                        <input type="text" class="form-control" id="service"  name="technician" value="{{old('technician')?old('technician'): $servicerequest->technician}}">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Model</label>
                            <input type="text" name="model" class="form-control" id="model" value="{{old('model')?old('model'):$servicerequest->model}}">
                            
                        </div>
                    </div>


                  <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label component_sl" for="component_sl_no">COMPONENT SL NO.</label>
							  <input name="component_sl_no" id="component_sl" class="form-control" value="{{  $compsl[0]['serial_no'] }}" readonly>
										
                                   
							
							</div>
								 </div>





                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">

                            <label class="form-control-label" for="service">Customer</label>
                            <input type="text" name="customer" class="form-control" id="service" value="{{old('customer')?old('customer'):$servicerequest->customer}}" readonly>
                           
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Test Smu</label>
                            <input type="text" name="test_smu" class="form-control" id="service" value="{{old('test_smu')?old('test_smu'): $servicerequest->test_smu}}" >
                            
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Engine Enter Date Time In The Test Bench</label>
                            <input type="date" name="engine_enter_date_time_in_the_test_bench" class="form-control" id="service" value="{{old('engine_enter_date_time_in_the_test_bench')?old('engine_enter_date_time_in_the_test_bench'):$servicerequest->engine_enter_date_time_in_the_test_bench}}" >
                           
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Month</label>
                            <input type="text" name="month" class="form-control" id="service" value="{{old('	month')?old('month'):$servicerequest->month}}" >
                           
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Problem During Testing</label>
                            <input type="text" name="problem_during_testing" class="form-control" id="service" value="{{old('problem_during_testing')?old('problem_during_testing'):$servicerequest->problem_during_testing}}" >
                          

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label roanalysis" for="service">Root Cause Analysis</label>
							<select name="root_cause_analysis" id="roanalysis" class="form-control">
							 
                            @foreach($rootanalysis  as  $root)
							
							     @php
                                     if($servicerequest->root_cause_analysis == $root->root_cause_analysis)
									{
                                        $select = 'selected';
                                    }
									 else  
								    {
                                        $select = '';
                                     }
                                     @endphp
									 <option value="{{$root->root_cause_analysis}}" {{$select}} >
                                         {{$root->root_cause_analysis}}
									 </option>
                            @endforeach
                             </select>
                        </div>
                    </div>
                         <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label why" for="service">Why</label>
                            <input type="text" name="why" class="form-control" id="why" value="{{old('why')?old('why'):$servicerequest->why}}" >
                          
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Solution</label>
                            <input type="text" name="solution" class="form-control" id="service" value="{{old('solution')?old('solution'):$servicerequest->solution}}" >
                            @if($errors->has('solution'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('solution')}}</div>
                            @endif

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Date</label>
                            <input type="date" name="engine_out_date_time" class="form-control" id="service" value="{{old('engine_out_date_time')?old('engine_out_date_time'):$servicerequest->	engine_out_date_time}}" >
                            @if($errors->has('engine_out_date_time'))
                                <div class="invalid-feedback" style="display:block;">{{$engineoutdate->first('engine_out_date_time')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Impact</label>
                            <input type="text" name="impact" class="form-control" id="service" value="{{old('impact')?old('impact'):$servicerequest->impact}}" >
                           
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label  typprblm" for="arnumber">Type of Problem</label>
                            <select name="type_of_problem" id="typprblm" class="form-control">
                                @foreach($typeofproblem  as  $typeproblem)
							
							     @php
                                     if($servicerequest->type_of_problem == $typeproblem->type_of_problem)
									{
                                        $select = 'selected';
                                    }
									 else  
								    {
                                        $select = '';
                                     }
                                     @endphp
									 <option value="{{$typeproblem->type_of_problem}}" {{$select}} >
                                         {{$typeproblem->type_of_problem}}
									 </option>
                            @endforeach
							   
							   
							   
                           </select>

                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label areaproblem" for="arnumber">Area Of Problem</label>
                            <select name="area_of_problem" id="areaproblem" class="form-control">
                            @foreach($areaproblem  as  $arprblm)
							
							     @php
                                     if($servicerequest->area_of_problem == $arprblm->area_of_problem)
									{
                                        $select = 'selected';
                                    }
									 else  
								    {
                                        $select = '';
                                     }
                                     @endphp
									 <option value="{{$arprblm->area_of_problem}}" {{$select}} >
                                         {{$arprblm->area_of_problem}}
									 </option>
                            @endforeach
                           </select>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label portionprb" for="arnumber">Portion of Problem</label>
                            <select name="portion_of_problem" id="portionprb" class="form-control">
                           @foreach( $portionproblem  as  $porprblm)
							
							     @php
                                     if($servicerequest->portion_of_problem == $porprblm->portion_of_problem)
									{
                                        $select = 'selected';
                                    }
									 else  
								    {
                                        $select = '';
                                     }
                                     @endphp
									 <option value="{{$porprblm->portion_of_problem}}" {{$select}} >
                                         {{$porprblm->portion_of_problem}}
									 </option>
                            @endforeach
							   </select>
                           
                        </div>
                    </div>



                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Further Action</label>
                            <input type="text" name="further_action" class="form-control" id="service" value="{{old('further_action')?old('further_action'):$servicerequest->further_action}}" >
                           
                        </div>
                    </div>
                  


                </div><!-- /row -->
                <input type="hidden" name="id" value="{{$errors->id}}">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Edit</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>
           <!-- <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="{{URL::asset('public/assets/download/sampleexcel.xlsx')}}">Sample excel File</a></div>
        </div>-->
    </div>



@endsection
@section('after_script')

    <!-- Optional JS -->
    {{--<script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>--}}
    <script src="{{URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/machine-serial-list-show") }}',

                type: 'POST',

                data: {model:model,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-model-list-show") }}',

                type: 'POST',

                data: {commodel:commodel,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-serial-list-show") }}',

                type: 'POST',

                data: {coserial:coserial,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });

    </script>



@endsection

