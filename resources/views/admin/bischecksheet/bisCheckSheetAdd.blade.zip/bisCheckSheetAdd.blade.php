@extends('admin.include.layout')
<!-- Project List -->


@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Create BisCheckSheet</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service requeust</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

@php
//echo '<pre>';print_r($modelno['model_no']);exit;
@endphp
    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
		
		
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{url('admin/bis-add-save')}}" enctype="multipart/form-data">
                <div class="row">
                  <!--<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="technician">Department</label>
                             <input type="text" name="technician" class="form-control" id="service" value="" >
                        </div>
                    </div>-->
					
					

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="technician">TECHNICIAN</label>
                            <input type="text" name="technician" class="form-control" id="service" value="" >
                        </div>
                    </div>
					
					 <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Workorder no</label>
                            <input type="text" name="job_no" class="form-control" id="job_no" value="{{old('work_orderno')?old('work_orderno'):$servicereq[0]['work_orderno']}}" readonly>
                            @if($errors->has('job_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('job_no')}}</div>
                            @endif
                        </div>
                    </div>
					
					
					
					
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label mod" for="model">Model</label>
							
						 <input name="model" id="mod" class="form-control" value="@if(!empty($modelno[0]['model_no'])) {{$modelno[0]['model_no']}} @endif" readonly>
								 
					</div>
				 </div>
							
				
					<div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label component_sl" for="component_sl_no">COMPONENT SL NO.</label>
							
						 <input name="component_sl_no" id="component_sl" class="form-control" value="@if(!empty($servicereq[0]['comp_serial_no'])) {{$servicereq[0]['comp_serial_no']}} @endif" readonly>
								 
					</div>
				 </div>
							
							

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Customer</label>
                            <input type="text" name="customer" class="form-control" id="customer" value=" @if(!empty($customer[0]['name'])) {{$customer[0]['name']}} @endif" readonly>
                            @if($errors->has('customer'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('customer')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label machserial" for="Component">Test SMU</label>
                            <textarea rows="2" cols="20"class="" name="test_smu" value="">
                            </textarea>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compmodel" for="model">Engine enter date & time in the test bench</label>
                            <input type="date" name="engine_enter_date_time_in_the_test_bench" class="form-control" id="" placeholder="Engine enter date & time in the test bench" value="">

                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Date</label>
                            <input type="date" name="month" class="form-control" id="" placeholder="month" value="">

                        </div>
                    </div>


                    <div class="col-sm-7 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compname" for="Component">Problem during testing</label>
                            <textarea rows="2" cols="20"class="" name="problem_during_testing" value="">
                            </textarea>
                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="root_cause_analysis">Root cause Analysis</label>
                            
                                <textarea rows="2" cols="20"class="" name="root_cause_analysis" value=""></textarea>

                            
                            @if($errors->has('root_cause_analysis'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('root_cause_analysis')}}</div>
                            @endif
                        </div>
                    </div>
					
					 <div class="col-sm-1 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label why" for="Component">Why</label>
                            <textarea rows="2" cols="20"class="" name="why" value="">
                            </textarea>
                        </div>
                    </div>
					
				

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Solution</label>
                            <textarea rows="2" cols="25"class="" name="solution" value="">
                            </textarea>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Engine out date & time</label>
                            <input type="date" name="engine_out_date_time" class="form-control" id="" placeholder="engine_out_date_time" value="">
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="impact">Impact</label>
                            <textarea rows="2" cols="25"class="" name="impact" value="">
                            </textarea>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Type of Problem</label>
                            
                                <textarea rows="2" cols="25"class="" name="type_of_problem" value=""></textarea>
                            @if($errors->has('type_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('type_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Area of Problem</label>
                            
                                <textarea rows="2" cols="25"class="" name="area_of_problem" value=""></textarea>
                            @if($errors->has('area_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('area_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Portion of Problem</label>
                            
                                <textarea rows="2" cols="25"class="" name="portion_of_problem" ></textarea>
                            @if($errors->has('portion_of_problem'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('portion_of_problem')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="solution">Further action</label>
                            <textarea rows="2" cols="50"class="" name="further_action" value="">
                            </textarea>
                        </div>
                    </div>
                    </div>
                    
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="question">Actual Start Date <span style="color:red">*</span></label>
                            <input type="text" class="form-control" id="actualdate1" placeholder="" name="actual_start_date" value=""  required>

                        </div>
                    </div>
                    <!--</div>-->



              <!-- /row -->
                <input type="hidden" name="_token" value="{{csrf_token()}}">
				<input type="hidden" name="service_request_id" value="{{$servicereq[0]['id']}}">
                <button class="btn btn-primary" type="submit">Save</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>

        </div>

    </div>
    <!-- Project List -->




@endsection

@section('after_script')

    <!-- Optional JS -->
    <script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>

     <script src="{{URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
     
      <script type="text/javascript">
    $('#actualdate1').datepicker({
    format: "dd/mm/yyyy",
    autoclose: true,
    orientation: "down",
    endDate: "today"

    });
    </script>

@endsection






