@extends('admin.include.layout')
<!-- Project List -->

@section('after_styles')
    <link rel="stylesheet" href="{{URL::asset('public/assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">
@endsection

@section('head')
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">BIS Listing</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">BIS Listing</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

    <div class="row">
        <div class="col-xl-12">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <!-- Card header -->
                        <div class="card-header border-0">
                            <h3 class="mb-0">All Branch Details</h3>
                        </div>

                        <div class="table-responsive">
                            <table class="table align-items-center table-flush" id="tabe1">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort" data-sort="number">Id</th>

                                   
                                    <th scope="col" class="sort" data-sort="name">TECHNICIAN</th>
                                    <th scope="col" class="sort" data-sort="name">Model</th>
                                    <th scope="col" class="sort" data-sort="name">COMPONENT SL NO.</th>
                                    <th scope="col" class="sort" data-sort="name">Customer</th>
                                    <th scope="col" class="sort" data-sort="name">Test SMU</th>
                                    <th scope="col" class="sort" data-sort="name">Engine enter date & time in the test bench</th>
                                    <th scope="col" class="sort" data-sort="name">Month</th>
                                    <th scope="col" class="sort" data-sort="name">Problem during testing</th>
                                    <th scope="col" class="sort" data-sort="name">Root cause Analysis</th>
                                    <th scope="col" class="sort" data-sort="name">Why</th>
                                    <th scope="col" class="sort" data-sort="name">Solution</th>
                                    <th scope="col" class="sort" data-sort="name">Engine out date & time</th>
                                    <th scope="col" class="sort" data-sort="name">Impact</th>
                                    <th scope="col" class="sort" data-sort="name">Type of Problem</th>
                                    <th scope="col" class="sort" data-sort="name">Area of Problem</th>
                                    <th scope="col" class="sort" data-sort="name">Portion of Problem</th>
                                    <th scope="col" class="sort" data-sort="name">Further action</th>

                                     <th scope="col" class="sort" data-sort="name">Action</th>
                                </tr>
                                </thead>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('after_script')

    <script src="{{URL::asset('public/assets/vendor/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{URL::asset('public/assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#tabe1').DataTable({
                processing: true,
                serverSide: true,
                ajax:{
                    url: '{{ url("admin/bischecksheet-get-table") }}',
                },
                columns: [
                    {data: 'id', name: 'id',orderable: false, searchable: false},

                   
                    {data: 'technician', name: 'technician'},
                    {data: 'model', name: 'model'},
                    {data: 'component_sl_no', name: 'component_sl_no'},
                    {data: 'customer', name: 'customer'},
                    {data: 'test_smu', name: 'test_smu'},
                    {data: 'engine_enter_date_time_in_the_test_bench', name: 'engine_enter_date_time_in_the_test_bench'},
                    {data: 'month', name: 'month'},
                    {data: 'problem_during_testing', name: 'problem_during_testing'},
                    {data: 'root_cause_analysis', name: 'root_cause_analysis'},
                    {data: 'why', name: 'why'},
                    {data: 'solution', name: 'solution'},
                    {data: 'engine_out_date_time', name: 'engine_out_date_time'},
                    {data: 'impact', name: 'impact'},
                    {data: 'type_of_problem', name: 'type_of_problem'},
                    {data: 'area_of_problem', name: 'area_of_problem'},
                    {data: 'portion_of_problem', name: 'portion_of_problem'},
                    {data: 'further_action', name: 'further_action'},


                    {data: 'action', name: 'action', orderable: false, searchable: false} ,
                ],
                // pageLength: 25,
                // order: [[ 2, "asc" ]]
            });

        });
    </script>


@endsection
