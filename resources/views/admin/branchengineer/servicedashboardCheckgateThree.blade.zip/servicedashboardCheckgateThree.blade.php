    @extends('admin.include.layout')
    <!-- Project List -->
    @section('head')
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 font-weight-400 text-white d-inline-block mb-0">Project Dashboard</h6>

                    </div>
                </div>

                <!-- Card stats -->
                <div class="row">

                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Total<br> number</h5>
                                        <span class="h2 font-weight-bold mb-0">350,897</span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-default text-white rounded-circle shadow">
                                            <i class="ni ni-briefcase-24"></i>
                                        </div>
                                    </div>
                                </div>
                                <p class="mt-3 mb-0 text-sm">
                                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                                    <span class="text-nowrap">Since last month</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">With small deviation</h5>
                                        <span class="h2 font-weight-bold mb-0">2,356</span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                            <i class="ni ni-briefcase-24"></i>
                                        </div>
                                    </div>
                                </div>
                                <p class="mt-3 mb-0 text-sm">
                                    <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 1.48%</span>
                                    <span class="text-nowrap">Since last month</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">With high deviation</h5>
                                        <span class="h2 font-weight-bold mb-0">924</span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                            <i class="ni ni-briefcase-24"></i>
                                        </div>
                                    </div>
                                </div>
                                <p class="mt-3 mb-0 text-sm">
                                    <span class="text-danger mr-2"><i class="fa fa-arrow-down"></i> 3.48%</span>
                                    <span class="text-nowrap">Since last month</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6">
                        <div class="card card-stats">
                            <!-- Card body -->
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title text-uppercase text-muted mb-0 font-weight-500">Without deviation</h5>
                                        <span class="h2 font-weight-bold mb-0">5,000</span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                            <i class="ni ni-briefcase-24"></i>
                                        </div>
                                    </div>
                                </div>
                                <p class="mt-3 mb-0 text-sm">
                                    <span class="text-danger mr-2"><i class="fa fa-arrow-down"></i> 3.48%</span>
                                    <span class="text-nowrap">Since last month</span>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    @endsection
    @section('body')




        <!-- Project List -->
        <div class="row">
            <div class="col-xl-12">
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <!-- Card header -->




                        </div>




                        <div class="row">
                            <div class="col-xl-12">
                                <div class="row">
                                    <div class="col">
                                        <div class="card">
                                            <!-- Card header -->
                                            <div class="card-header border-0">
                                                <h3 class="mb-0">All Users Details</h3>
                                            </div>









                                            <div class="table-responsive">





                                                <div class="table-responsive">
                                                    <table class="table align-items-center table-flush" id="tabe1">
                                                        <thead class="thead-light">
                                                        <tr>
                                                             <th scope="col" class="sort" data-sort="number">#</th>
                                                        <th scope="col" class="sort" data-sort="name">Service Request No</th>
                                                        <th scope="col" class="sort" data-sort="name">Customer</th>
                                                        <th scope="col" class="sort" data-sort="name">Branch</th>
                                                        <th scope="col" class="sort" data-sort="name">Component Name</th>
                                                        <th scope="col" class="sort" data-sort="name">Status</th>
                                                        {{--<th scope="col" class="sort" data-sort="name">Action</th>--}}

                                                        </tr>
                                                        </thead>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    @endsection

    @section('after_script')

        <script src="{{URL::asset('public/assets/vendor/datatables.net/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{URL::asset('public/assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>

        <script type="text/javascript">
            $(document).ready(function(){
                $('#tabe1').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax:{
                        url: '{{ url("admin/fetchservicheckgatethree-get-table") }}',
                    },
                    columns: [
                     
                        {data: 'id', name: 'id',orderable: false, searchable: false},
                    {data: 'service_request_no', name: 'service_request_no'},
                    {data: 'customer', name: 'customer'},
                    {data: 'branch_name', name: 'branch_name'},
                    {data: 'component_name', name: 'component_name'},
                    {data: 'cg3_status', name: 'cg3_status'},
                    // {data: 'action', name: 'action', orderable: false, searchable: false} ,

                       // {data: 'action', name: 'action', orderable: false, searchable: false}
                    ],
                    "language": {
                         "paginate": {
                            "previous": "Prev"
                        }
                    }
                });


            });
        </script>
    @endsection
