@extends('admin.include.layout')
@section('head')

    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <h6 class="h2 font-weight-400 text-white d-inline-block mb-0"> Edit service request</h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="{{url('admin/branch-dashboard')}}"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">New service request</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('body')

@php
//print_r($servicerequest);
//die;
@endphp

    <!-- Project List -->
    <div class="card mb-4">
        <!-- Card header -->
        <div class="card-header">
            <h3 class="mb-0">Please fill the form below</h3>
        </div>
        <!-- Card body -->
        <div class="card-body">
            <!-- Form groups used in grid -->
            <form method="post" action="{{ url('/admin/update-servicerequest')}}" enctype="multipart/form-data">
                <div class="row">

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Service Request Number</label>
                            <input type="text" name="service_request_no" class="form-control" id="service" value="{{old('service_request_no')?old('service_request_no'):$servicerequest->service_request_no}}" readonly>
                            @if($errors->has('service_request_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('service_request_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Customer Name</label>

                            <input type="text" name="customer" class="form-control" id="service" value="{{old('customer')?old('customer'):$servicerequest->customer}}">
                            @if($errors->has('customer'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('customer')}}</div>
                            @endif



                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Job No</label>
                            <input type="text" name="job_no" class="form-control" id="service" value="{{old('job_no')?old('job_no'):$servicerequest->job_no}}" >
                            @if($errors->has('job_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('job_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Ar No</label>
                            <input type="text" name="ar_no" class="form-control" id="service" value="{{old('ar_no')?old('ar_no'):$servicerequest->ar_no}}" >
                            @if($errors->has('ar_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('ar_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Model number</label>
                            <select name="machine_modelno" id="machmodel" class="form-control">
                                

                                    @foreach($machinemodel as $mod)
									<option selected="selected" value="{{$mod->id}}" >
                                        {{$mod->model_no}}
										</option>
                                    @endforeach

                               
                                @php
                                    $mchmodel=App\Helpers\UserHelper::machinemodelno();
                                @endphp

                                @foreach($mchmodel as $cmodel)

                                    <option value="{{$cmodel->id}}">{{$cmodel->model_no}}</option>

                                @endforeach

                            </select>
                            @if($errors->has('model_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('model_no')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Machine Serial number</label>
                            <select name="machine_serialno" id="compserial" class="form-control">
							@foreach( $machserial as $macserial)
                                <option selected="selected" value="{{$macserial->id}}">

                                    
                                    {{$macserial->serial_no}}
										</option>
                                    @endforeach

                                </option>
                                @php
                                    $mchserial=App\Helpers\UserHelper::mastermachineserialno();
                                @endphp

                                @foreach($mchserial as $mserial)

                                    <option selected="selected" value="{{$mserial->id}}">{{$mserial->serial_no}}</option>

                                @endforeach

                            </select>
                            @if($errors->has('serial_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('serial_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Component Model number</label>
                            <select name="comp_model_no" id="compmodel" class="form-control">
                                <option selected="selected">

                                    @foreach( $compmodelno as  $compmodno)
									<option selected="selected" value="{{$compmodno->id}}">
                                        {{ $compmodno->model_no}}
										</option>
                                    @endforeach

                                </option>
                                @php
                                     $compmodel=App\Helpers\UserHelper::componentmodelno();
                                @endphp

                                @foreach($compmodel as $cmodel)

                                    <option value="{{$cmodel->id}}">{{$cmodel->model_no}}</option>

                                @endforeach

                            </select>
                            @if($errors->has('model_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('model_no')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label  machmodel" for="model">Component Serial number</label>
                            <select name="component_serial_no" id="compserial" class="form-control">
                                <option selected="selected" >

                                    @foreach($compserialno as $coserial)
									<option selected="selected" value={{"$coserial->id"}}>
                                        {{$coserial->serial_no}}
										</option>
                                    @endforeach

                                </option>
                                @php
                                   $compserial =App\Helpers\UserHelper::componentserialno();
                                @endphp

                                @foreach($compserial as $comserial)

                                    <option value="{{$comserial->id}}">{{$comserial->serial_no}}</option>

                                @endforeach

                            </select>
                            @if($errors->has('serial_no'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('serial_no')}}</div>
                            @endif
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Component Name</label>
                            <select name="component_name" id="compname" class="form-control"  >
                                <option selected="selected" id="service" >
                                    {{old('component_name')?old('component_name'):$servicerequest->component_name}}
                                    </option>
                            @if($errors->has('component_name'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('component_name')}}</div>
                            @endif
                            @php
                                $comptype=App\Helpers\UserHelper::componenttype();
                            @endphp

                            @foreach($comptype as $ctype)

                                <option value="{{$ctype->type}}">{{$ctype->type}}</option>

                            @endforeach
                            </select>
                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Branch Name</label>
                            <select name="branch_name" id="branch_name" class="form-control"  >
                                <option>
                             {{old('branch_name')?old('branch_name'):$servicerequest->branch_name}}
                                    </option>
                                @if($errors->has('branch_name'))
                                    <div class="invalid-feedback" style="display:block;">{{$errors->first('branch_name')}}</div>
                                @endif

                                @php
                                    $branch=App\Helpers\UserHelper:: branchname();
                                @endphp


                                @foreach($branch as $bran)

                                    <option value="{{$bran->sales_ofc}}">{{$bran->sales_ofc}}</option>

                                @endforeach
                                </select>

                        </div>
                    </div>



                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Segment</label>
                            <select name="segment" id="segment" class="form-control"  >
                                <option selected="selected" id="service" >
                             {{old('segment')?old('segment'):$servicerequest->segment}}
                                 </option>
                            @if($errors->has('segment'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('segment')}}</div>
                            @endif

                            @php
                                $segment=App\Helpers\UserHelper::segment();
                            @endphp


                            @foreach($segment as $seg)

                                <option value="{{$seg->name}}">{{$seg->name}}</option>

                            @endforeach
                            </select>

                    </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">Branch location</label>
                            <input type="text" name="branch_location" class="form-control" id="service" value="{{old('branch_location')?old('branch_location'):$servicerequest->branch_location}}" >
                            @if($errors->has('branch_location'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('branch_location')}}</div>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label compserial" for="serial">Work order no</label>
                            <input type="text" name="work_orderno" class="form-control" id="service" value="" >

                        </div>
                    </div>


                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="service">date</label>
                            <input type="text" name="date" class="form-control" id="service" value="{{old('date')?old('date'):$servicerequest->date}}" >
                            @if($errors->has('date'))
                                <div class="invalid-feedback" style="display:block;">{{$errors->first('date')}}</div>
                            @endif
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload pre-history</label>
                            <div class="custom-file">
                                <input type="file" name="import_file" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                        </div>
                    </div>

                    <!--<div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="arnumber">Upload PO</label>
                            <div class="custom-file">
                                <input type="file" name="po_upload" class="custom-file-input" id="customFileLang" lang="en">
                                <label class="custom-file-label" for="customFileLang">Select file</label>
                            </div>
                            <h6>upload pdf file</h6>
                        </div>
                    </div>-->


                </div><!-- /row -->
                <input type="hidden" name="id" value="{{$servicerequest->id}}">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <button class="btn btn-primary" type="submit">Edit</button>

                <button type="reset" class="btn btn-warning" onclick='location.href ="{{url('admin/service-request-list')}}"'>Cancel</button>
            </form>
            <div class="mt-2">Download Prehistory Sample Excel<a class="badge badge-primary" href="{{URL::asset('public/assets/download/sampleexcel.xlsx')}}">Sample excel File</a></div>
        </div>
    </div>



@endsection
@section('after_script')

    <!-- Optional JS -->
    {{--<script src="{{URL::asset('public/assets/vendor/select2/dist/js/select2.min.js')}}"></script>--}}
    <script src="{{URL::asset('public/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>

    <script type="text/javascript">
        /*Model serial no*/
        $('#machmodel').change(function(event) {
            var model = $(this).val();
            //alert(model);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/machine-serial-list-show") }}',

                type: 'POST',

                data: {model:model,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);



                    $('.machserial').show();

                    $('#machserial').html(response);




                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component model no*/
        $('#machmodel').change(function(event) {
            var commodel = $(this).val();
            //alert(commodel);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-model-list-show") }}',

                type: 'POST',

                data: {commodel:commodel,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);





                    $('.compmodel').show();

                    $('#compmodel').html(response);

                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });
    </script>


    <script type="text/javascript">
        /*component serial no*/
        $('#machmodel').change(function(event) {
            var coserial = $(this).val();
            //alert(coserial);
            //console.log(model);

            $.ajax({

                url: '{{ url("/admin/component-serial-list-show") }}',

                type: 'POST',

                data: {coserial:coserial,'_token':'{{csrf_token()}}'},

            })

                .done(function(response) {
                    //console.log(response);







                    $('.compserial').show();

                    $('#compserial').html(response);

                    //mctype= jQuery.parseJSON(response);

                    console.log("success");

                })

                .fail(function() {

                    console.log("error");

                })

                .always(function() {

                    console.log("complete");

                });



        });

    </script>



@endsection

