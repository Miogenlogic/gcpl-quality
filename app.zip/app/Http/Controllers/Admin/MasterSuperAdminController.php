<?php

namespace App\Http\Controllers\admin;


use App\Http\Controllers\Controller;
//use App\Http\Requests\CustomerRequest;
use App\Http\Requests\BisRequest;
use App\Http\Requests\DepartmentRequest;
use App\Http\Requests\MasterTaskRequest;
use App\Models\AisChecksheet;
use App\Models\MasterBis;
use App\Models\MasterDesignation;
use App\Models\MasterEmployee;
use App\Models\MasterMCModel;
use App\Models\MasterTask;
use App\Models\Service;
use Illuminate\Http\Request;
use PHPUnit\Util\Color;
use Rap2hpoutre\FastExcel\FastExcel;
use Box\Spout\Writer\Style\StyleBuilder;

use App\Models\MasterComponentModelNo;
use App\Models\MasterComponentDetails;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterBranch;
use App\Models\Menu;
use App\Models\Menuaccess;
use App\Models\MasterCustomer;
use App\Models\WorkFlow;
//use response;
//use App\Models\MasterEmployee;

//use App\Models\MasterMCModel;


use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;


use App\Http\Requests\CustomerRequest;

use App\Http\Requests\BranchRequest;
class MasterSuperAdminController extends Controller
{
    public function addcustomer()
    {
        return view('admin.master.addCustomer');

    }

    public function mastercustomerStore(CustomerRequest $request)
    {
        $obj = new MasterCustomer();
        $obj->name = ['name'];
        $obj->customer_code = ['customer_code'];
        $obj->address = ['address'];
        $obj->address2 = ['address2'];
        $obj->address3 = ['address3'];
        $obj->phone_no = ['phone_no'];
        $obj->email = ['email'];

        $obj->save();
        return redirect('admin/master-customer');
    }

    public function customerexcel()
    {
        (new FastExcel)->import('C:\Users\User\Downloads\SAP_Integration_Data.xls', function ($line) {
            if ($line['Name1']) {
                $mcModel = MasterCustomer::where('name', '=', $line['Name1'])->get()->first();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterCustomer();
                    $mcModel->name = $line['Name 1'];
                    $mcModel->customer_code = $line['Customer ID'];
                    $mcModel->address = $line['Customer Address 1'];
                    $mcModel->address2 = $line['Customer Address 2'];
                    $mcModel->address3 = $line['Customer Address 3'];
                    $mcModel->phone_no = $line['Customer Phone No.'];
                    $mcModel->email = $line['Customer email'];
                    $mcModel->region = $line['Region'];
                    //  $mcModel->guard_name = 'web';
                    $mcModel->save();

                }
            }
        });
    }

    public function mastercustomer()
    {
        return view('admin.master.masterCustomer');
    }

    public function fetchcustomerGetTable(Request $request)
    {
        $table = MasterCustomer::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editcustomer/' . $table->id) . '">Edit</a>
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editcustomer($id)
    {

        $errors = MasterCustomer::find($id);


        return view('admin.master.editcustomer')
            ->with('errors', $errors);
    }

    public function updatecustomer(Request $request)
    {
        $obj = MasterCustomer::find($request['id']);

        $obj->name = $request['name'];
        $obj->customer_code = $request['customer_code'];
        $obj->address = $request['address'];
        $obj->contact_details = $request['contact_details'];
        $obj->region = $request['region'];
        $obj->branch = $request['branch'];
        $obj->save();
        return redirect('admin/master-customer');
    }

    public function downloadcustomer()
    {
        $table = MasterCustomer::select('gw_master_customer.name', 'gw_master_customer.customer_code', 'gw_master_customer.address',
            'gw_master_customer.address2', 'gw_master_customer.address3', 'gw_master_customer.phone_no', 'gw_master_customer.email',
            'gw_master_customer.region')->get();
        $style = (new StyleBuilder())
            ->setFontBold()
            //  ->setBackgroundColor(Color::YELLOW)
            ->build();
        $path = 'C:\Users\User\Downloads\SAP_Integration_Data.xls';
        (new FastExcel($table))->headerStyle($style)->export($path, function ($table) {
            return [
                'Name1' => $table['name'],
                'Customer ID' => $table['customer_code'],
                'Customer Address 1' => $table['address'],
                'Customer Address 2' => $table['address2'],
                'Customer Address 3' => $table['address3'],
                'Customer Phone No.' => $table['phone_no'],
                'Customer email' => $table['email'],
                'Region' => $table['region'],
            ];
        });
        $file = $path;
        $name = basename($file);
        return response()->download($file, $name);
    }


    public function downloadtemplatecustomer()
    {


        $style = (new StyleBuilder())
            ->setFontBold()
            //  ->setBackgroundColor(Color::YELLOW)
            ->build();
        $path = 'C:\Apache24\htdocs\gcpl-quality\template files\Customer Template download.xlsx';


        $file = $path;
        $name = basename($file);
        return response()->download($file, $name);
    }


    public function uploadcustomer()
    {
        (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\SAP_Integration_Data.xls', function ($line) {
            if ($line['Name 1']) {
                $mcModel = MasterCustomer::where('name', '=', $line['Name 1'])->get()->first();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterCustomer();
                    $mcModel->name = $line['Name 1'];
                    $mcModel->customer_code = $line['Customer ID'];
                    $mcModel->address = $line['Customer Address 1'];
                    $mcModel->address2 = $line['Customer Address 2'];
                    $mcModel->address3 = $line['Customer Address 3'];
                    $mcModel->phone_no = $line['Customer Phone No.'];
                    $mcModel->email = $line['Customer email'];
                    $mcModel->region = $line['Region'];
                    $mcModel->save();
                    return redirect('admin/master-customer');

                }
            }
        });
    }

    public function uploadtemplatecustomer()
    {
        (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\Customer Template download.xlsx', function ($line) {

            $mcModel = MasterCustomer::where('name', '=', $line['Name1'])->get()->first();
            if (!isset($mcModel->id)) {
                $mcModel->save();
                return redirect('admin/master-customer');


            }
        });
    }

    public function masterbranch()
    {
        return view('admin.master.masterbranch');
    }

    public function fetchbranchGetTable(Request $request)
    {
        $table = MasterBranch::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/edit-branch/' . $table->id) . '">Edit</a>
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editbranch($id)
    {

        $errors = MasterBranch::find($id);


        return view('admin.master.editbranch')
            ->with('errors', $errors);
    }

    public function updatebranch(Request $request)
    {
        $obj = MasterBranch::find($request['id']);

        $obj->sales_ofc = $request['sales_ofc'];
        $obj->sales_ofc_code = $request['sales_ofc_code'];
        $obj->save();
        return redirect('admin/master-branch');
    }


    public function addbranch()
    {
        $title = 'Add Branch';


        return view('admin.master.addBranch');
    }

    public function masterbranchStore(BranchRequest $request)
    {
        //  $myrequest=$request->all();
        //dd($myrequest);

        $obj = new MasterBranch();
        $obj->sales_ofc = $request['sales_ofc'];
        $obj->sales_ofc_code = $request['sales_ofc_code'];
        $obj->save();
        return redirect('admin/master-branch');
    }


    public function downloadbranch()
    {
        $table = MasterCustomer::select('gw_master_customer.name', 'gw_master_customer.customer_code', 'gw_master_customer.address',
            'gw_master_customer.address2', 'gw_master_customer.address3', 'gw_master_customer.phone_no', 'gw_master_customer.email',
            'gw_master_customer.region')->get();
        $style = (new StyleBuilder())
            ->setFontBold()
            //  ->setBackgroundColor(Color::YELLOW)
            ->build();
        $path = 'C:\Users\User\Downloads\SAP_Integration_Data.xls';
        (new FastExcel($table))->headerStyle($style)->export($path, function ($table) {
            return [
                'Name1' => $table['name'],
                'Customer ID' => $table['customer_code'],
                'Customer Address 1' => $table['address'],
                'Customer Address 2' => $table['address2'],
                'Customer Address 3' => $table['address3'],
                'Customer Phone No.' => $table['phone_no'],
                'Customer email' => $table['email'],
                'Region' => $table['region'],
            ];
        });
        $file = $path;
        $name = basename($file);
        return response()->download($file, $name);
    }

    public function downloadtemplatebranch()
    {


        $style = (new StyleBuilder())
            ->setFontBold()
            //  ->setBackgroundColor(Color::YELLOW)
            ->build();
        $path = 'C:\Apache24\htdocs\gcpl-quality\template files\Branch Template download.xlsx';


        $file = $path;
        $name = basename($file);
        return response()->download($file, $name);
    }

    public function uploadbranch()
    {
        /*  (new FastExcel)->import('C:\Users\User\Downloads\SAP_Integration_Data.xls', function ($line) {
              if ($line['Name1']) {
                  $mcModel = MasterCustomer::where('name', '=', $line['Name1'])->get()->first();
                  if (!isset($mcModel->id)) {
                      $mcModel = new MasterCustomer();
                      $mcModel->name = $line['Name1'];
                      $mcModel->customer_code = $line['Customer ID'];
                      $mcModel->address = $line['Customer Address 1'];
                      $mcModel->address2 = $line['Customer Address 2'];
                      $mcModel->address3 = $line['Customer Address 3'];
                      $mcModel->phone_no = $line['Customer Phone No.'];
                      $mcModel->email = $line['Customer email'];
                      $mcModel->region = $line['Region'];
                      //  $mcModel->guard_name = 'web';
                      $mcModel->save();*/

        (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\examplebranch.xlsx', function ($line) {
            if ($line['sales ofc']) {
                $mcModel = MasterBranch::where('sales_ofc', '=', $line['sales ofc'])->get()->first();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterBranch();
                    $mcModel->sales_ofc = $line['sales ofc'];
                    $mcModel->sales_ofc_code = $line['sales ofc code'];
                    $mcModel->save();
                }
            }
        });
    }

    public function rollmenu()
    {
        //$masterrole = Masterrole::find($id);
        //$mastermenu = Menu::select('menu');
        $items = Menu::all();
        return view('admin.superadmin.rollmenuadd', compact('items'));
        //  ->with('mastermenu', $mastermenu);
        //->with('masterrole', $masterrole);
    }

    public function rollmenusave(Request $request)
    {
        $rollmenulist = $request->all();
        //echo'<pre>';print_r($rollmenulist);exit;
        //dd($rollmenulist);exit;
        //$rollmenu=$request->all('menu');
        $obj = new Menuaccess();
        //$obj->role = json_encode($rollmenulist);
        $obj->role = $rollmenulist['role'];
        // echo '<pre>';print_r($request['rolemenu']);exit;
        $obj->rolemenu = implode(',', $request['rolemenu']);
        // echo '<pre>';print_r($obj->rolemenu);exit;
        //  $obj->rolemenu = json_encode($rollmenulist['checked']);
        $obj->save();
        return redirect('admin/check-rollmenu-listing');
    }

    public function rollmenufetching()
    {

        $title = '';
        return view('admin.superadmin.rolemenulisting')
            ->with('title', $title);

    }

    public function rollmenulistinggettable(Request $request)

    {
        $rolemenu = Menuaccess::select('menu_access.role', 'menu_access.rolemenu', 'roles.name', 'menus.menu')->leftjoin('roles',
            'roles.id', '=', 'menu_access.role')->leftjoin('menus', 'menus.id', '=', 'menu_access.rolemenu')->get();
        //  $table = Menuaccess::select('*')->get();
        $datatables = Datatables::of($rolemenu)
            ->addColumn('action', function ($rolemenu) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="' . url('admin/editmachine/' . $rolemenu->id) . '">Edit</a>
                                   </div>
                            </div>';

                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function servicedashboardcheckgateone()
    {

        return view('admin.branchengineer.servicedashboardCheckgateOne');
    }

    public function fetchservicedashboardcheckgateone(Request $request)
    {
        $table = Service::select('*')->orderby('created_at','DESC')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">';
                if ($table->checkgate1 != Null) {
                    $btns .= '<a class="dropdown-item" href="' . url('admin/check-gate-form-one-listing/' . $table->id) . '">Edit</a>';
                } else {
                    $btns .= '<a class="dropdown-item" href="' . url('admin/check-gate-form-one-add/' . $table->id) . '">Add</a>';
                }

                $btns .= '             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function servicedashboardcheckgatetwo()
    {

        return view('admin.branchengineer.servicedashboardCheckgateTwo');
    }

    public function fetchservicedashboardcheckgatetwo(Request $request)
    {
        // $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'Approved')->get();
        $table = Service::Select('*')->WHERE('status', '=', 'Approved')->get();
        //echo '<pre>';
        // print_r($table);
        //   exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add/' . $table->id) . '">Add</a>
                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function servicedashboardpending()
    {

        return view('admin.branchengineer.servicedashboardPending');
    }

    public function fetchservicedashboardpending(Request $request)
    {
        $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'Pending')->get();
        //echo '<pre>';
        // print_r($table);
        //   exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add/' . $table->id) . '">Add</a>
                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function servicedashboardinprogress()
    {

        return view('admin.branchengineer.servicedashboardInprogress');
    }

    public function fetchservicedashboardinprogress(Request $request)
    {
        $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'Inprogress')->get();
        //echo '<pre>';
        // print_r($table);
        //   exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add/' . $table->id) . '">Add</a>
                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function servicedashboardsubmit()
    {

        return view('admin.branchengineer.servicedashboardSubmit');
    }

    public function fetchservicedashboardsubmit(Request $request)
    {
        $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'Submitted')->get();
        //echo '<pre>';
        // print_r($table);
        //   exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add/' . $table->id) . '">Add</a>
                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }


    public function servicedashboardreject()
    {

        return view('admin.branchengineer.servicedashboardReject');
    }

    public function fetchservicedashboardreject(Request $request)
    {
        $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'Rejected')->get();
        //echo '<pre>';
        // print_r($table);
        //   exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add/' . $table->id) . '">Add</a>
                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function servicerequest()
    {

        return view('admin.serviceengineer.servicerequest');
    }

    public function fetchservicerequest(Request $request)
    {
        $table = Service::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/listing/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function showchecksheet()
    {
        $title = '';

        return view('admin.serviceengineer.showCheckSheet')
            ->with('title', $title);
    }

    public function showchecksheetdetails(Request $request)

    {
        $table = Service::Select('service_request.id', 'service_request.service_request_no', 'service_request.status')->WHERE('status', '=', 'submitted')->get();
        //  $table = Service::Select('service_request.id', 'service_request.checkgate1', 'service_request.status')->WHERE('checkgate1', '!=', NULL)->get();
        // echo '<pre>';
        //print_r($table);
        //exit;
        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                 <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common/' . $table->id) . '">Show Checksheet</a>
                                                             </div>
                                                             
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    /* public function approvedchecksheet($id)
     {
         $service = Service::where('id', '=', $id)->first();

         if ($service) {
             $service->status = true;
             return redirect()->back()->with('info', 'The application was approved successfully');
         }
     }*/
    /* public function uploadbisreport()
     {

         (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\NEW FORMAT OF BIS REPORT 2019.xlsx', function ($line) {
            if ($line['Sl #']) {
                $mcBis = MasterBis::where('sl_no', '=', $line['Sl #'])->get()->first();
                if (!isset($mcBis->id)) {
                    $mcBis = new MasterBis();
                    $mcBis->sl_no = $line['Sl #'];
                    $mcBis->job_no = $line['Job No'];
                    $mcBis->technician = $line['TECHNICIAN'];
                    $mcBis->model = $line['Model'];
                    $mcBis->component_sl_no = $line['COMPONENT SL NO.'];
                    $mcBis->customer = $line['Customer'];
                    $mcBis->test_smu = $line['Test SMU'];
                    $mcBis->engine_enter_date_time_in_the_test_bench = $line['Engine enter date & time in the test bench'];
                    $mcBis->month = $line['Month'];
                    $mcBis->problem_during_testing = $line['Problem during testing'];
                    $mcBis->root_cause_analysis = $line['Root cause Analysis'];
                    $mcBis->why = $line['Why'];
                    $mcBis->solution = $line['Solution'];
                    $mcBis->engine_out_date_time = $line['Engine out date & time'];
                    $mcBis->impact = $line['Impact'];
                    $mcBis->type_of_problem = $line['Type of Problem'];
                    $mcBis->area_of_problem = $line['Area of Problem'];
                    $mcBis->portion_of_problem = $line['Portion of Problem'];
                    $mcBis->further_action = $line['Further action'];
                    $mcBis->save();
                    return redirect('admin/master-customer');

                }
            }
         });
     }*/
    /*public function uploadworkflow()


    {
        (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\Work Flow & Access Control 2019.xlsx', function ($line) {
          if ($line['Section'])
              {
               $mcwork = WorkFlow::where('section', '=', $line['Section'])->get()->first();
               if (!isset($mcwork->id)) {
         $mcwork = new WorkFlow();
         $mcwork->section= $line['Section'];
         $mcwork->details_entry=$line['Details Entry'];
          $mcwork->job_open=$line['Job Open/Allocate'];
           $mcwork->review=$line['Review '];
           $mcwork->parts_availability= $line['parts_availability'];
           $mcwork->review_approval_supervisor_level=$line['Review & Approval - Supervisor Level'];
            $mcwork->quality_check_pdi=$line['Quality Check & PDI'];
            $mcwork->initial_approval=$line['Intial Approval- Section Incharge Level'];
            $mcwork->final_approval_crc_head=$line['Final Approval CRC Head'];
            $mcwork->job_closing=$line['Job Closing/ Invoicing '];
            $mcwork->despatch_confirmation=$line['Despatch Confirmation'];
            $mcwork->save();
      }
           }

        }*/

    public function bisAdd($id)
    {
        $title = 'Add Bis';

        $masterbis = Service::find($id);
        $masterjobno = Service::find($id);

        return view('admin.bischecksheet.bisCheckSheetAdd')
            ->with('masterjobno', $masterjobno)
            ->with('masterbis', $masterbis);
    }

    public function bisAddSave(Request $request)
    {
        $obj = new MasterBis();
        // $obj->service_request_no = $ser.$request['date'];
        $obj->sl_no = $request['sl_no'];
        $obj->job_no = $request['job_no'];
        $obj->technician = $request['technician'];
        $obj->model = $request['model'];
        $obj->component_sl_no = $request['component_sl_no'];
        $obj->customer = $request['customer'];
        $obj->test_smu = $request['test_smu'];
        $obj->engine_enter_date_time_in_the_test_bench = $request['engine_enter_date_time_in_the_test_bench'];
        $obj->month = $request['month'];
        $obj->problem_during_testing = $request['problem_during_testing'];
        $obj->root_cause_analysis = $request['root_cause_analysis'];
        $obj->why = $request['why'];
        $obj->solution = $request['solution'];
        $obj->engine_out_date_time = $request['engine_out_date_time'];
        $obj->impact = $request['impact'];
        $obj->type_of_problem = $request['type_of_problem'];
        $obj->area_of_problem = $request['area_of_problem'];
        $obj->portion_of_problem = $request['portion_of_problem'];
        $obj->further_action = $request['further_action'];
        $obj->save();

        $id = $obj->id;

    }

    public function bislisting()
    {
        return view('admin.bischecksheet.bisCheckSheetListing');
    }

    public function fetchbischecksheet(Request $request)
    {
        $table = MasterBis::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/editbischecksheet/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editbischecksheet($id)
    {
        $servicerequest = MasterBis::find($id);
        $rootanalysis = MasterBis::Select('gw_master_bis_checksheet.root_cause_analysis')->where('gw_master_bis_checksheet.id', '=', $id)->get();
        $typeofproblem = MasterBis::Select('gw_master_bis_checksheet.type_of_problem')->where('gw_master_bis_checksheet.id', '=', $id)->get();
        $areaproblem = MasterBis::Select('gw_master_bis_checksheet.area_of_problem')->where('gw_master_bis_checksheet.id', '=', $id)->get();
        $portionproblem = MasterBis::Select('gw_master_bis_checksheet.portion_of_problem')->where('gw_master_bis_checksheet.id', '=', $id)->get();
        return view('admin.bischecksheet.editBisCheckSheet')
            ->with('rootanalysis', $rootanalysis)
            ->with('typeofproblem', $typeofproblem)
            ->with('areaproblem', $areaproblem)
            ->with('portionproblem', $portionproblem)
            ->with('servicerequest', $servicerequest);

    }

    public function editbissave(Request $request)
    {
        $obj = MasterBis::find($request['id']);

        $obj->sl_no = $request['sl_no'];
        //  $obj->job_no = $request['job_no'];
        $obj->technician = $request['technician'];
        $obj->model = $request['model'];
        $obj->component_sl_no = $request['component_sl_no'];
        //$obj->customer = $request['customer'];
        $obj->test_smu = $request['test_smu'];
        $obj->engine_enter_date_time_in_the_test_bench = $request['engine_enter_date_time_in_the_test_bench'];
        $obj->month = $request['month'];
        $obj->problem_during_testing = $request['problem_during_testing'];
        $obj->root_cause_analysis = $request['root_cause_analysis'];
        $obj->why = $request['why'];
        $obj->solution = $request['solution'];
        $obj->engine_out_date_time = $request['engine_out_date_time'];
        $obj->impact = $request['impact'];
        $obj->type_of_problem = $request['type_of_problem'];
        $obj->area_of_problem = $request['area_of_problem'];
        $obj->portion_of_problem = $request['portion_of_problem'];
        $obj->further_action = $request['further_action'];
        $obj->save();
        return redirect('admin/bis-listing');
    }

    public function aisAdd($id)
    {
        $masterais = Service::find($id);
        $masterjobno = Service::find($id);

        return view('admin.aischecksheet.aisCheckSheetAdd')
            ->with('masterais', $masterais)
            ->with('masterjobno', $masterjobno);
    }

    public function aisAddSave(Request $request)
    {
        $obj = new AisChecksheet();
        $obj->sl_no = $request['sl_no'];
        $obj->job_no = $request['job_no'];
        $obj->customer = $request['customer'];
        $obj->branch = $request['branch'];
        $obj->component = $request['component'];
        $obj->smu_hours = $request['smu_hours'];
        $obj->model = $request['model'];
        $obj->serial_no = $request['serial_no'];
        $obj->dispatch_date = $request['dispatch_date'];
        $obj->job_done_by = $request['job_done_by'];
        $obj->business_segment = $request['business_segment'];
        $obj->complain_receive_date = $request['complain_receive_date'];
        $obj->month = $request['month'];
        $obj->customer_complain = $request['customer_complain'];
        $obj->response_date = $request['response_date'];
        $obj->attainded_by = $request['attainded_by'];
        $obj->completion_date = $request['completion_date'];
        $obj->root_cause = $request['root_cause'];
        $obj->why_y1 = $request['why_y1'];
        $obj->why_y2 = $request['why_y2'];
        $obj->resolution = $request['resolution'];
        $obj->type_of_problem = $request['type_of_problem'];
        $obj->condition_details = $request['condition_details'];
        $obj->status = $request['status'];
        $obj->actual_resolution_date = $request['actual_resolution_date'];
        $obj->area_of_problem = $request['area_of_problem'];
        $obj->system = $request['system'];
        $obj->save();
        $id = $obj->id;


    }

    public function aislisting()
    {
        return view('admin.aischecksheet.aisCheckSheetListing');
    }

    public function fetchaischecksheet(Request $request)
    {
        $table = AisChecksheet::select('*')->get();

        $datatables = Datatables::of($table)
            ->addColumn('action', function ($table) {
                $btns = ' <div class="dropdown">
                              <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                               <a class="dropdown-item" href="' . url('admin/editaischecksheet/' . $table->id) . '">Edit</a>
                                
                                                             </div>
                            </div>';
                // $btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })
            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function editaischecksheet($id)
    {
        $servicerequest = AisChecksheet::find($id);
        return view('admin.aischecksheet.editAisCheckSheet')
            ->with('servicerequest', $servicerequest);
    }

    public function editaisave(Request $request)
    {
        $obj = AisChecksheet::find($request['id']);
        $obj->sl_no = $request['sl_no'];
        $obj->job_no = $request['job_no'];
        $obj->customer = $request['customer'];
        $obj->branch = $request['branch'];
        $obj->component = $request['component'];
        $obj->smu_hours = $request['smu_hours'];
        $obj->model = $request['model'];
        $obj->serial_no = $request['serial_no'];
        $obj->dispatch_date = $request['dispatch_date'];
        $obj->job_done_by = $request['job_done_by'];
        $obj->business_segment = $request['business_segment'];
        $obj->complain_receive_date = $request['complain_receive_date'];
        $obj->month = $request['month'];
        $obj->customer_complain = $request['customer_complain'];
        $obj->response_date = $request['response_date'];
        $obj->attainded_by = $request['attainded_by'];
        $obj->completion_date = $request['completion_date'];
        $obj->root_cause = $request['root_cause'];
        $obj->why_y1 = $request['why_y1'];
        $obj->why_y2 = $request['why_y2'];
        $obj->resolution = $request['resolution'];
        $obj->type_of_problem = $request['type_of_problem'];
        $obj->condition_details = $request['condition_details'];
        $obj->status = $request['status'];
        $obj->actual_resolution_date = $request['actual_resolution_date'];
        $obj->area_of_problem = $request['area_of_problem'];
        $obj->system = $request['system'];
        $obj->save();
        return redirect('admin/ais-listing');

    }

    public function uploadmodeldepartment(Request $request)
    {

        /*  (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\enginemodel.xlsx', function ($line) {
              $model_no = $line['Machine Model'];
              $dept_id = $line['CRC_SECTION'];
              $obj = MasterMCModel::where('model_no', '=', $model_no)->update(['dept_id' => $dept_id]);
              $obj->save();
  */
        (new FastExcel)->import('C:\Apache24\htdocs\gcpl-quality\template files\enginemodel.xlsx', function ($line) {
            if ($line['Machine Model']) {
                $mcModel = MasterMCModel::where('model_no', '=', $line['Machine Model'])->get()->first();
                if (!isset($mcModel->id)) {
                    $mcModel = new MasterMCModel();
                    $mcModel->model_no = $line['Machine Model'];
                    $mcModel->dept_id = $line['CRC_SECTION'];
                    $mcModel->save();
                }
            }
        });
    }}


