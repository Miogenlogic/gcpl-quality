<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UserHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CheckGateQuestionEditRequest;
use App\Http\Requests\CheckGateQuestionRequest;

use App\Http\Requests\DisassmblyAggregateRequest;
use App\Models\ChecksheetStatus;
use App\Models\ClutchPackThicknessValues;
use App\Models\ClutchPlateFlatnessValues;
use App\Models\ClutchPlateThicknessValues;
use App\Models\ComponentInspReport;
use App\Models\CoolerInspectionValues;
use App\Models\IdlerMeasuredAfterValues;
use App\Models\IdlerMeasuredBeforeValues;
use App\Models\IdlerspcClearShaftValues;
use App\Models\IdlerSpeciEndcolerValues;
use App\Models\IdlerSpecificationValues;
use App\Models\MasterConRodBushReplacementValues;
use App\Models\MasterCoolerInspection;
use App\Models\MasterDissamblyCleaningInspection;
use App\Models\MasterAggregate;
use App\Models\MasterCcinspectionExternalWashDetails;
use App\Models\MasterCcinspectionPartCleanDetails;
use App\Models\MasterCheckGate;
use App\Models\MasterCheckGateInspectionQuestion;
use App\Models\MasterCommercialValues;
use App\Models\MasterComponentDetails;

use App\Models\MasterFailedParts;
use App\Models\MasterListofSalvageDis;
use App\Models\MasterLoosepartDis;
use App\Models\MasterMCModel;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterMissingdamagePartDis;
use App\Models\MasterPartAirCompressorValues;
use App\Models\MasterPartCamshaftValue;
use App\Models\MasterPartConnectingRodValues;
use App\Models\MasterPartCrankshaftValue;
use App\Models\MasterPartCylinderHeadValues;
use App\Models\MasterPartFanDriveValues;
use App\Models\MasterPartinspectionCylinderHeadDetails;
use App\Models\MasterPartOilPumpValues;
use App\Models\MasterPartOthercomponentValues;
use App\Models\MasterPartsInspectionCylinderHeadValues;
use App\Models\MasterPartWaterPumpValues;
use App\Models\MasterPreHistoryDis;
use App\Models\PartCamshaftBushboreValues;
use App\Models\PartCylinderBlockBushboreValues;
use App\Models\PartCylinderBlockCamboreValues;
use App\Models\PartCylinderBlockCapNoValues;
use App\Models\PartCylinderBlockLinearValues;
use App\Models\PartCylinderBlockThreadValues;
use App\Models\PartCylinderBlockTopDeckValues;
use App\Models\PartLhCamshaftValue;
use App\Models\PartRhCamshaftValue;
use App\Models\RollerspcClearShaftValues;
use App\Models\RoolerMeasuredValues;
use App\Models\RoolerSpecificationValues;
use App\Models\RoolerSpecifiEndColValues;
use App\Models\Service;
use App\Models\MasterCCinspectionBeforeStartAssembly;
use App\Models\StatusRevision;
use App\Models\ChecksheetAssembly;
use App\Models\TorqueConverterValues;
use App\Models\TransmissionComponent;
use Illuminate\Http\Request;


use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

use Rap2hpoutre\FastExcel\FastExcel;
use Box\Spout\Writer\Style\StyleBuilder;

use Carbon\Carbon;
use DB;
use Hash;
use File;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
class CheckSheetController extends Controller
{
//engine

    public function engineDissList()
    {


        return view('admin.checksheet.disassembly.engineDissList');
    }

    public function engineDissgetTable(Request $request)
    {

        $table = Service::select('service_request.*','gw_master_aggregate.work_done')

            ->leftjoin('gw_master_aggregate','gw_master_aggregate.service_request_id','=','service_request.id')
            ->get();
//dd($table);exit;
        $datatables =  Datatables::of($table)

            ->addColumn('action', function ($table) {
                /*if(isset($table->checkgate1) && strlen($table->checkgate1) > 1 && $table->work_done==0){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Dissassembly Checksheet</a>
                                             <!--<a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-assembly-common')."/". "$table->id". '">Assembly Checksheet</a>-->
                                             </div>
                                        </div>';
                }
                elseif(isset($table->work_done) && $table->work_done==1){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <!--<a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>-->
                                            
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Dissassembly Checksheet</a>
                                            
                                            
                                                <!--a class="dropdown-item" href="' . url('admin/check-gate-form-two-add')."/"."$table->id". '">Check Gate 2</a>
                                            <a class="dropdown-item" href="' . url('admin/check-sheet-assembly-common')."/". "$table->id". '">Assembly Checksheet</a>-->
                                                
                                            </div>
                                        </div>';
                }else {
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-one-add')."/"."$table->id". '">Check Gate 1</a>
                                          
                                                
                                               
                                                
                                            </div>
                                        </div>';
                }*/
                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Disassembly Checksheet</a>
                                          
                                                
                                            </div>
                                        </div>';
                return $btns;

            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    public function engineAssList()
    {


        return view('admin.checksheet.disassembly.engineAssList');
    }

    public function engineAssgetTable(Request $request)
    {

        $table = Service::select('service_request.*','gw_master_aggregate.work_done')

            ->leftjoin('gw_master_aggregate','gw_master_aggregate.service_request_id','=','service_request.id')
            ->get();
//dd($table);exit;
        $datatables =  Datatables::of($table)

            ->addColumn('action', function ($table) {
               /* if(isset($table->checkgate1) && strlen($table->checkgate1) > 1 && $table->work_done==0){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                               <!--<a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Dissassembly Checksheet</a>
                                           <a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>-->
                                             <a class="dropdown-item" href="' . url('admin/check-sheet-assembly-common')."/". "$table->id". '">Assembly Checksheet</a>
                                             </div>
                                        </div>';
                }
                elseif(isset($table->work_done) && $table->work_done==1){
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <!--<a class="dropdown-item" href="'.url('admin/check-gate-form-one-listing')."/"."$table->id".'">Check Gate 1</a>-->
                                            
                                             <!--<a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Dissassembly Checksheet</a>
                                            
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-two-add')."/"."$table->id". '">Check Gate 2</a>-->
                                            <a class="dropdown-item" href="' . url('admin/check-sheet-assembly-common')."/". "$table->id". '">Assembly Checksheet</a>
                                                
                                            </div>
                                        </div>';
                }else {
                    $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                            
                                                <a class="dropdown-item" href="' . url('admin/check-gate-form-one-add')."/"."$table->id". '">Check Gate 1</a>
                                          
                                                
                                               
                                                
                                            </div>
                                        </div>';
                }*/

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-assembly-common')."/". "$table->id". '">Assembly Checksheet</a>
                                          
                                                
                                            </div>
                                        </div>';

                return $btns;

            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }



//trans
    public function transDissList()
    {


        return view('admin.checksheet.disassembly.transDissList');
    }

    public function transDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

//hyd
    public function hydDissList()
    {


        return view('admin.checksheet.disassembly.hydDissList');
    }

    public function hydDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }
//mor

    public function morDissList()
    {


        return view('admin.checksheet.disassembly.morDissList');
    }

    public function morDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }
//undercarraige
    public function undercargDissList()
    {


        return view('admin.checksheet.disassembly.undercarrigeDissList');
    }

    public function undercargDissgetTable(Request $request)
    {

        $table = Service::select('*')->get();


        $datatables =  Datatables::of($table)
            /*->addColumn('usertype', function ($table) {
                if(){

                }
                return $btns;
            })*/
            /*->addColumn('img', function ($table) {
                $img = ' <img src="' . asset('public/assets/uploads/service/image') . '/' . $table->image . '" style="width: 120px;height:100px">';
                return $img;
            })*/

            ->addColumn('action', function ($table) {

                $btns = ' <div class="dropdown">
                                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button"
                                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                             
                                           
                                                <a class="dropdown-item" href="' . url('admin/check-sheet-entry-common')."/". "$table->id". '">Checksheet entry</a>
                                          
                                                
                                            </div>
                                        </div>';
                //$btns .=' <a href="' . url('admin/service-delete/' . $table->id) . '" onclick="return confirm(\'Are you sure?\')" class="btn btn-outline-danger">DELETE</a>';
                return $btns;
            })

            ->rawColumns(['action']);


        return $datatables->make(true);
    }

    //super admin
    public function checkSheetEntryCommon($id)
    {
        $dept_id=1;

        $service = Service::find($id);
        // dd($service);exit;

        if(!empty($service)){

            //show reject comment
            $showrejectcom =ChecksheetStatus::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();

            //aggregation show

            $agrregate=MasterAggregate::where('service_request_id','=',$service->id)
                ->get()->first();
            //dd($agrregate);exit;
            $mcModel=MasterMCModel::find($service->machine_modelno);
            //$mcSerial=MasterMCSerialNumber::find($service['machine_serialno']);
            $mcSerial = Service::select('service_request.id','machine_serialno', 'gw_master_machine_serial_no.serial_no')
                ->leftjoin('gw_master_machine_serial_no','gw_master_machine_serial_no.id', '=', 'service_request.machine_serialno')
                ->where('service_request.id', '=' ,$id)->get();
            $componentSerial=MasterComponentDetails::find($service->component_serial_no);


            //prehistory show
            $prehist=MasterPreHistoryDis::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($prehist->id)) {
                $machSerial=MasterMCSerialNumber::find($service->machine_serialno);
                $comSerial=MasterComponentDetails::find($service->component_serial_no);

            }
            else{
                $machSerial=Null;
                $comSerial=Null;
            }

            //Commercial and logistics
            $commercialLogistic=MasterCommercialValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();

            if(isset($commercialLogistic->id)){
                $commercialLogistic=json_decode($commercialLogistic->values);
            }else{
                $commercialLogistic=Null;
            }


            $allvalcommercialLog=MasterCommercialValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            //dd($commercialLog);exit;

            //Conrod After Bush Replacement

            $showconrodbush=MasterConRodBushReplacementValues::where('service_request_id','=',$service->id)

                ->get()->first();

            if(isset($showconrodbush->id)){
                $showconrodbush=json_decode($showconrodbush->values);
            }else{
                $showconrodbush=Null;
            }

            $allvalconrodbush=MasterConRodBushReplacementValues::where('service_request_id','=',$service->id)

                ->get()->first();

            //ccinspection after external wash
            $externalWash=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($externalWash->id)){
                $externalWash=json_decode($externalWash->values);
            }else{
                $externalWash=Null;
            }

            $allvalexterwash=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            $beforestartccassembly=MasterCCinspectionBeforeStartAssembly::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();

            if(isset($beforestartccassembly->id)){
                $beforestartccassembly=json_decode($beforestartccassembly->ccvalues);
            }else{
                $beforestartccassembly=Null;
            }
            //echo"<pre>";
            //print_r($beforestartccassembly);
            //exit();

            $ccbeforestartassembly=MasterCCinspectionBeforeStartAssembly::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();

//Component Inspection report
            $cominspecreport=ComponentInspReport::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            if(isset( $cominspecreport->id)){
                $cominspecreport=json_decode( $cominspecreport->ccvalues);
            }else{
                $cominspecreport=Null;
            }
            $cccompinsp=ComponentInspReport::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();




            //cc inspection after parts clean
            $partsClean=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($partsClean->id)){
                $partsClean=json_decode($partsClean->values);
            }else{
                $partsClean=Null;
            }

            $allvalpartcln=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();

            //partsinspection cylinder head

            $cylinder=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($cylinder->id)){
                $cylinder=json_decode($cylinder->details);
            }else{
                $cylinder=Null;
            }


            $allvalcylinderheadoil=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //parts inspection cooler insp

            $showcooler=CoolerInspectionValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcooler->id)){
                $showcooler=json_decode($showcooler->values);
            }else{
                $showcooler=Null;
            }


            $allvalcooler=CoolerInspectionValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //partinspection other component

            $showothercomp=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showothercomp->id)){
                $showothercomp=json_decode($showothercomp->values);
            }else{
                $showothercomp=Null;
            }

            $allvalothercom=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

         //transmisssion component
            $showtransmission=TransmissionComponent::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showtransmission->id)){
                $showtransmission=json_decode($showtransmission->values);
            }else{
                $showtransmission=Null;
            }

            $allvaltrans=TransmissionComponent::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();



            // commponent inspection report
            $showcompinsp=ComponentInspReport::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcompinsp->id)){
                $showcompinsp=json_decode($showcompinsp->ccvalues);
            }else{
                $showcompinsp=Null;
            }

            $allvalinsprpt=ComponentInspReport::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();


            //parts rooler measured
            $showrolmea=RoolerMeasuredValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showrolmea->id)){
                $showrolmea=json_decode($showrolmea->values);
            }else{
                $showrolmea=Null;
            }

            $allvalrolmea=RoolerMeasuredValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //partsinspection connecting rod
            $showconrod=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showconrod->id)){
                $showconrod=json_decode($showconrod->values);
            }else{
                $showconrod=Null;
            }

            $allvalconrod=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();

            //partinspection cylinder block
            $showcylinderblock=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcylinderblock->id)){
                $showcylinderblock=json_decode($showcylinderblock->values);
            }else{
                $showcylinderblock=Null;
            }
            //$var = $showcylinderblock->frontcenter;
            if(isset($showcylinderblock->frontcenter)){
                $myArray = json_decode(json_encode($showcylinderblock->frontcenter), true);
            }
            else{
                $myArray=Null;
            }
            if(isset($showcylinderblock->frontresult)) {
                $frntreslt = json_decode(json_encode($showcylinderblock->frontresult), true);
            }else{
                $frntreslt=Null;
            }
            if(isset($showcylinderblock->mainfrontremarks)) {
                $frtmainrst = json_decode(json_encode($showcylinderblock->mainfrontremarks), true);
            }else{
                $frtmainrst=Null;
            }
            if(isset($showcylinderblock->centerresult)) {
                $rearcenteryes = json_decode(json_encode($showcylinderblock->centerresult), true);
            }else{
                $rearcenteryes=Null;
            }
            if(isset($showcylinderblock->rearresults)) {
                $rearresyes = json_decode(json_encode($showcylinderblock->rearresults), true);
            }else{
                $rearresyes=Null;
            }
            if(isset($showcylinderblock->rearresults)) {
                $rearremaryes = json_decode(json_encode($showcylinderblock->mainrearremarks), true);
            }else{
                $rearremaryes=Null;
            }
            $allvalcylinderblock=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //partinspection cylinder block linear
            $showcylblklinear=PartCylinderBlockLinearValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcylblklinear->id)){
                $showcylblklinear=json_decode($showcylblklinear->values);
            }else{
                $showcylblklinear=Null;
            }

            if(isset($showcylblklinear->frontcenter)){
                $linArray = json_decode(json_encode($showcylblklinear->frontcenter), true);
            }
            else{
                $linArray=Null;
            }
            if(isset($showcylblklinear->frontresult)) {
                $linfrntreslt = json_decode(json_encode($showcylblklinear->frontresult), true);
            }else{
                $linfrntreslt=Null;
            }
            if(isset($showcylblklinear->mainfrontremarks)) {
                $linfrtmainrst = json_decode(json_encode($showcylblklinear->mainfrontremarks), true);
            }else{
                $linfrtmainrst=Null;
            }
            if(isset($showcylblklinear->centerresult)) {
                $linrearcenteryes = json_decode(json_encode($showcylblklinear->centerresult), true);
            }else{
                $linrearcenteryes=Null;
            }
            if(isset($showcylblklinear->rearresults)) {
                $linrearresyes = json_decode(json_encode($showcylblklinear->rearresults), true);
            }else{
                $linrearresyes=Null;
            }
            if(isset($showcylblklinear->rearresults)) {
                $linrearremaryes = json_decode(json_encode($showcylblklinear->mainrearremarks), true);
            }else{
                $linrearremaryes=Null;
            }

            $allvalcylblkliner=PartCylinderBlockLinearValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //partinspection cylinder block cam bore
            $showcylblkcam=PartCylinderBlockCamboreValues::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcylblkcam->id)){
                $showcylblkcam=json_decode($showcylblkcam->values);
            }else{
                $showcylblkcam=Null;
            }
            if(isset($showcylblkcam->frontcenter)){
                $camArray = json_decode(json_encode($showcylblkcam->frontcenter), true);
            }
            else{
                $camArray=Null;
            }
            if(isset($showcylblkcam->frontresult)) {
                $camfrntreslt = json_decode(json_encode($showcylblkcam->frontresult), true);
            }else{
                $camfrntreslt=Null;
            }
            if(isset($showcylblkcam->mainfrontremarks)) {
                $camfrtmainrst = json_decode(json_encode($showcylblkcam->mainfrontremarks), true);
            }else{
                $camfrtmainrst=Null;
            }
            if(isset($showcylblkcam->centerresult)) {
                $camrearcenteryes = json_decode(json_encode($showcylblkcam->centerresult), true);
            }else{
                $camrearcenteryes=Null;
            }
            if(isset($showcylblkcam->rearresults)) {
                $camrearresyes = json_decode(json_encode($showcylblkcam->rearresults), true);
            }else{
                $camrearresyes=Null;
            }
            if(isset($showcylblkcam->rearresults)) {
                $camrearremaryes = json_decode(json_encode($showcylblkcam->mainrearremarks), true);
            }else{
                $camrearremaryes=Null;
            }

            $allvalcylblkcam=PartCylinderBlockCamboreValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();


            //parts inspection crankshaft inspection
            $showcrankshaft=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcrankshaft->id)){
                $showcrankshaft=json_decode($showcrankshaft->values);
            }else{
                $showcrankshaft=Null;
            }

            $allvalcranksft=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            //parts inspection camshaft inspection

            $showcamshaft=MasterPartCamshaftValue::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcamshaft->id)){
                $showcamshaft=json_decode($showcamshaft->values);
            }else{
                $showcamshaft=Null;
            }

            $allvalcamsft=MasterPartCamshaftValue::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //parts inspection lh camshaft inspection

            $showlhcamshaft=PartLhCamshaftValue::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showlhcamshaft->id)){
                $showlhcamshaft=json_decode($showlhcamshaft->values);
            }else{
                $showlhcamshaft=Null;
            }

            $allvallLhcamsft=PartLhCamshaftValue::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //parts inspection rh camshaft inspection

            $showrhcamshaft=PartRhCamshaftValue::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showrhcamshaft->id)){
                $showrhcamshaft=json_decode($showrhcamshaft->values);
            }else{
                $showrhcamshaft=Null;
            }

            $allvalrLhcamsft=PartRhCamshaftValue::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //parts inspection camshaft bushbore inspection

            $showrhcambush=PartCamshaftBushboreValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showrhcambush->id)){
                $showrhcambush=json_decode($showrhcambush->values);
            }else{
                $showrhcambush=Null;
            }

            $allvalcamsftbush=PartCamshaftBushboreValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //missingdamagepart
            $showmissing_1=MasterMissingdamagePartDis::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get();
            //dd($showmissing_1);exit;
            if(isset($showmissing_1)){
                $showmissing=$showmissing_1;
                //dd($showmissing);exit;

            }else{
                $showmissing=Null;
                // echo "Rim";exit;
            }
            //status of revision
            $showmissingstatus_1=StatusRevision::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get();
            //dd($showmissingstatus_1);exit;
            if(isset($showmissingstatus_1)){
                $showmissingstatus=$showmissingstatus_1;
                //dd($showmissingstatus);exit;

            }else{
                $showmissingstatus=Null;

            }
            //Assembly checksheet
           /* $showcheckassembly_1=ChecksheetAssembly::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get();
            //dd($showcheckassembly_1);exit;
            if(isset($showcheckassembly_1)){
                $showcheckassembly=$showcheckassembly_1;
                //dd($showcheckassembly);exit;

            }else{
                $showcheckassembly=Null;

            }*/

            //disassembly cleaning inspection
            $showdissambly_1=MasterDissamblyCleaningInspection::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get();
            //dd($showdissambly_1);exit;
            if(isset($showdissambly)){
                $showdissambly=$showdissambly_1;
                //dd($showdissambly);exit;

            }else{
                $showdissambly=Null;

            }
            //list of salvage

            $showsalvage_1=MasterListofSalvageDis::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get();
            //dd($showmissing_1);exit;
            if(isset($showsalvage_1)){
                $showsalvage=$showsalvage_1;
                //dd($showmissing);exit;

            }else{
                $showsalvage=Null;
            }

            //loose parts
            $showloosepat_1=MasterLoosepartDis::where('service_request_id','=',$service->id)
                //->where('dept_id','=',1)
                ->get();
            // dd($showloosepat_1);exit;
            if(isset($showloosepat_1)){
                $showloosepat=$showloosepat_1;
                //dd($showmissing);exit;

            }else{
                $showloosepat=Null;
            }

            //Failed Parts

            $showfailed_1=MasterFailedParts::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showfailed_1)){
                $showfailed=$showfailed_1;


            }else{
                $showfailed=Null;

            }

            //rooler spe endcol
            $showrolspcend_1=RoolerSpecifiEndColValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showrolspcend_1)){
                $showrolspcend=$showrolspcend_1;


            }else{
                $showrolspcend=Null;

            }


            //parts rooler specification
            $showrolspec_1=RoolerSpecificationValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showrolspec_1)){
                $showrolspec=$showrolspec_1;


            }else{
                $showrolspec=Null;

            }

            //parts idler specification
            $showidlerpec_1=IdlerSpecificationValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showidlerpec_1)){
                $showidlerpec=$showidlerpec_1;


            }else{
                $showidlerpec=Null;

            }

            //parts idler measured before
            $showidlermesbef_1=IdlerMeasuredBeforeValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showidlermesbef_1)){
                $showidlermesbef=$showidlermesbef_1;


            }else{
                $showidlermesbef=Null;

            }

            //parts idler measured after
            $showidlermesaft_1=IdlerMeasuredAfterValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showidlermesaft_1)){
                $showidlermesaft=$showidlermesaft_1;


            }else{
                $showidlermesaft=Null;

            }

            //parts clutch pack thickness
            $showcluthick_1=ClutchPackThicknessValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showcluthick_1)){
                $showcluthick=$showcluthick_1;


            }else{
                $showcluthick=Null;

            }

            //parts clutch plate thickness
            $showcluplatethi_1=ClutchPlateThicknessValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showcluplatethi_1)){
                $showcluplatethi=$showcluplatethi_1;


            }else{
                $showcluplatethi=Null;

            }

            //parts clutch plate flatness
            $showcluplateflt_1=ClutchPlateFlatnessValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showcluplateflt_1)){
                $showcluplateflt=$showcluplateflt_1;


            }else{
                $showcluplateflt=Null;

            }

            //parts torque converter

            $showtorque_1=TorqueConverterValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showtorque_1)){
                $showtorque=$showtorque_1;


            }else{
                $showtorque=Null;

            }

            //parts idler spec endcol

            $showidlerspend_1=IdlerSpeciEndcolerValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showidlerspend_1)){
                $showidlerspend=$showidlerspend_1;


            }else{
                $showidlerspend=Null;

            }

            //parts idler clear shaft

            $showidleclr_1=IdlerspcClearShaftValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showidleclr_1)){
                $showidleclr=$showidleclr_1;


            }else{
                $showidleclr=Null;

            }

            //parts roller clear shaft

            $showrollclr_1=RollerspcClearShaftValues::where('service_request_id','=',$service->id)

                ->get();

            if(isset($showrollclr_1)){
                $showrollclr=$showrollclr_1;


            }else{
                $showrollclr=Null;

            }

            //Parts Fan Drive
            $showfandrive=MasterPartFanDriveValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showfandrive->id)){
                $showfandrive=json_decode($showfandrive->values);
            }else{
                $showfandrive=Null;
            }

            $allvalfandrive=MasterPartFanDriveValues::where('service_request_id','=',$service->id)
                ->where('dept_id','=',1)
                ->get()->first();

            //Parts Oil Pump
            $showoilpump=MasterPartOilPumpValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showoilpump->id)){
                $showoilpump=json_decode($showoilpump->values);
            }else{
                $showoilpump=Null;
            }

            $allvaloilpump=MasterPartOilPumpValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //air compressor
            $showaircomp=MasterPartAirCompressorValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showaircomp->id)){
                $showaircomp=json_decode($showaircomp->values);
            }else{
                $showaircomp=Null;
            }

            $allvalaircomp=MasterPartAirCompressorValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //water pump
            $showwaterpump=MasterPartWaterPumpValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showwaterpump->id)){
                $showwaterpump=json_decode($showwaterpump->values);
            }else{
                $showwaterpump=Null;
            }

            $allvalwaterpump=MasterPartWaterPumpValues::where('service_request_id','=',$service->id)
               // ->where('dept_id','=',1)
                ->get()->first();

            //cylinder block top deck
            $showcytopdk=PartCylinderBlockTopDeckValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcytopdk->id)){
                $showcytopdk=json_decode($showcytopdk->values);
            }else{
                $showcytopdk=Null;
            }

            $allvalcytopdk=PartCylinderBlockTopDeckValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //cylinder block thread
            $showcythread=PartCylinderBlockThreadValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcythread->id)){
                $showcythread=json_decode($showcythread->values);
            }else{
                $showcythread=Null;
            }

            $allvalcythread=PartCylinderBlockThreadValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //cylinder block bush bore
            $showcybush=PartCylinderBlockBushboreValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcybush->id)){
                $showcybush=json_decode($showcybush->values);
            }else{
                $showcybush=Null;
            }

            $allvalcybush=PartCylinderBlockBushboreValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            //cylinder block Cap no
            $showcycap=PartCylinderBlockCapNoValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();
            if(isset($showcycap->id)){
                $showcycap=json_decode($showcycap->values);
            }else{
                $showcycap=Null;
            }

            $allvalcyCap=PartCylinderBlockCapNoValues::where('service_request_id','=',$service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            return view('admin.include.checksheetCommon')
                ->with('service',$service)
                ->with('agrregate', $agrregate)
                ->with('mcModel', $mcModel)
                ->with('mcSerial', $mcSerial)
                ->with('componentSerial', $componentSerial)
                ->with('commercialLogistic',$commercialLogistic)
                ->with('prehist',$prehist)
                ->with('machSerial',$machSerial)
                ->with('comSerial',$comSerial)
                ->with('externalWash',$externalWash)
                ->with('partsClean',$partsClean)
                ->with('cylinder',$cylinder)
                ->with('showothercomp',$showothercomp)
                ->with('myArray',$myArray)
                ->with('showconrod',$showconrod)
                ->with('showconrodbush',$showconrodbush)
                ->with('frntreslt',$frntreslt)
                ->with('frtmainrst',$frtmainrst)
                ->with('rearcenteryes',$rearcenteryes)
                ->with('rearresyes',$rearresyes)
                ->with('rearremaryes',$rearremaryes)
                ->with('showcrankshaft',$showcrankshaft)
                ->with('showcamshaft',$showcamshaft)
                ->with('showcylinderblock',$showcylinderblock)
                ->with('showmissing',$showmissing)
                ->with('showoilpump',$showoilpump)
                ->with('showaircomp',$showaircomp)
                ->with('showsalvage',$showsalvage)
                ->with('showcooler',$showcooler)
                ->with('showloosepat',$showloosepat)
                ->with('showfailed',$showfailed)
                ->with('showfandrive',$showfandrive)
                ->with('showwaterpump',$showwaterpump)
                ->with('showcompinsp',$showcompinsp)
                ->with('showcluthick',$showcluthick)
                ->with('allvalcommercialLog',$allvalcommercialLog)
                ->with('allvalexterwash',$allvalexterwash)
                ->with('allvalpartcln',$allvalpartcln)
                ->with('allvalconrod',$allvalconrod)
                ->with('allvaloilpump',$allvaloilpump)
                ->with('allvalcylinderblock',$allvalcylinderblock)
                ->with('allvalcranksft',$allvalcranksft)
                ->with('allvalcamsft',$allvalcamsft)
                ->with('allvalothercom',$allvalothercom)
                ->with('allvalinsprpt',$allvalinsprpt)
                ->with('allvalcooler',$allvalcooler)
                ->with('allvalconrodbush',$allvalconrodbush)
                ->with('allvalfandrive',$allvalfandrive)
                ->with('allvalaircomp',$allvalaircomp)
                ->with('allvalwaterpump',$allvalwaterpump)
                ->with('showrejectcom',$showrejectcom)
                ->with('showmissingstatus',$showmissingstatus)
                //->with('showcheckassembly', $showcheckassembly)
                ->with('showdissambly',$showdissambly)
                //->with('beforestart',$beforestart)
                ->with('beforestartccassembly', $beforestartccassembly)
                ->with('allvalcylinderheadoil',$allvalcylinderheadoil)
               ->with('cominspecreport',$cominspecreport)
               ->with('showcluplatethi',$showcluplatethi)
               ->with('showcluplateflt',$showcluplateflt)
               ->with('showtorque',$showtorque)
               ->with('showtransmission',$showtransmission)
               ->with('allvaltrans',$allvaltrans)
               ->with('showrolspec',$showrolspec)
               ->with('showrolmea',$showrolmea)
               ->with('showidlerpec',$showidlerpec)
               ->with('allvalrolmea',$allvalrolmea)
               ->with('showrolspcend',$showrolspcend)
               ->with('showidlermesbef',$showidlermesbef)
               ->with('showidlermesaft',$showidlermesaft)
               ->with('showidlerspend',$showidlerspend)
               ->with('showidleclr',$showidleclr)
               ->with('showrollclr',$showrollclr)
               ->with('showlhcamshaft',$showlhcamshaft)
               ->with('showrhcamshaft',$showrhcamshaft)
               ->with('showrhcambush',$showrhcambush)
               ->with('allvallLhcamsft',$allvallLhcamsft)
               ->with('allvalrLhcamsft',$allvalrLhcamsft)
               ->with('allvalcamsftbush',$allvalcamsftbush)
               ->with('showcylblklinear',$showcylblklinear)
               ->with('allvalcylblkliner',$allvalcylblkliner)
               ->with('showcylblkcam',$showcylblkcam)
               ->with('allvalcylblkcam',$allvalcylblkcam)
               ->with('linArray',$linArray)
               ->with('linfrntreslt',$linfrntreslt)
               ->with('linfrtmainrst',$linfrtmainrst)
               ->with('linrearcenteryes',$linrearcenteryes)
               ->with('linrearresyes',$linrearresyes)
               ->with('linrearremaryes',$linrearremaryes)
                ->with('camArray',$camArray)
                ->with('camfrntreslt',$camfrntreslt)
                ->with('camfrtmainrst',$camfrtmainrst)
                ->with('camrearcenteryes',$camrearcenteryes)
                ->with('camrearresyes',$camrearresyes)
                ->with('camrearremaryes',$camrearremaryes)
                ->with('showcytopdk',$showcytopdk)
                ->with('allvalcytopdk',$allvalcytopdk)
                ->with('showcythread',$showcythread)
                ->with('allvalcythread',$allvalcythread)
                ->with('showcybush',$showcybush)
                ->with('allvalcybush',$allvalcybush)
                ->with('allvalcyCap',$allvalcyCap)
                ->with('showcycap',$showcycap)
                ->with('ccbeforestartassembly',$ccbeforestartassembly)
               ->with('cccompinsp',$cccompinsp);

        }
        else{
            $service=Null;
            $agrregate=Null;
            $mcModel=Null;
            $mcSerial=Null;
            $componentSerial=Null;
            $commercialLogistic=Null;
            $prehist=Null;
            $machSerial=Null;
            $comSerial=Null;
            $externalWash=Null;
            $beforestartccassembly=Null;
            $partsClean=Null;
            $cylinder=Null;
            $showothercomp=Null;
            $myArray=Null;
            $showconrod=Null;
            $showconrodbush=Null;
            $frntreslt=Null;
            $rearcenteryes=Null;
            $rearresyes=Null;
            $rearremaryes=Null;
            $showcrankshaft=Null;
            $showcamshaft=Null;
            $showcylinderblock=Null;
            $frtmainrst=Null;
            $showfandrive=Null;
            $showoilpump=Null;
            $showaircomp=Null;
            $showwaterpump=Null;
            $showcompinsp=Null;
            $beforestartassembly=Null;
            $showcooler=Null;
            $showrolmea=Null;
            $showlhcamshaft=Null;
            $showrhcamshaft=Null;
            $showrhcambush=Null;
            $showcylblklinear=Null;
            $showcylblkcam=Null;
            $linArray=Null;
            $linfrntreslt=Null;
            $linfrtmainrst=Null;
            $linrearcenteryes=Null;
            $linrearresyes=Null;
            $linrearremaryes=Null;
            $camArray=Null;
            $camfrntreslt=Null;
            $camfrtmainrst=Null;
            $camrearcenteryes=Null;
            $camrearresyes=Null;
            $camrearremaryes=Null;
            $showcytopdk=Null;
            $showcythread=Null;
            $showcybush=Null;
            $showcycap=Null;
            //$showcluthick=Null;
            //$showcluplatethi=Null;

            return view('admin.include.checksheetCommon')
                ->with('service',$service)
                ->with('agrregate', $agrregate)
                ->with('mcModel', $mcModel)
                ->with('mcSerial', $mcSerial)
                ->with('componentSerial', $componentSerial)
                ->with('commercialLogistic',$commercialLogistic)
                ->with('prehist',$prehist)
                ->with('machSerial',$machSerial)
                ->with('comSerial',$comSerial)
                ->with('externalWash',$externalWash)
                ->with('partsClean',$partsClean)
                ->with('cylinder',$cylinder)
                ->with('showothercomp',$showothercomp)
                ->with('showcompinsp',$showcompinsp)
                ->with('myArray',$myArray)
                ->with('showconrod',$showconrod)
                ->with('showconrodbush',$showconrodbush)
                ->with('showfandrive',$showfandrive)
                ->with('showoilpump',$showoilpump)
                ->with('showaircomp',$showaircomp)
                ->with('showwaterpump',$showwaterpump)
                //->with('showcluthick',$showcluthick)
                ->with('frntreslt',$frntreslt)
                ->with('frtmainrst',$frtmainrst)
                ->with('rearcenteryes',$rearcenteryes)
                ->with('rearresyes',$rearresyes)
                ->with('rearremaryes',$rearremaryes)
                ->with('showcrankshaft',$showcrankshaft)
                ->with('showcamshaft',$showcamshaft)
                ->with('showcooler',$showcooler)
                ->with('showrolmea',$showrolmea)
                 ->with('showrhcamshaft',$showrhcamshaft)
                 ->with('showrhcambush',$showrhcambush)
                 ->with('showcylblklinear',$showcylblklinear)
                 ->with('showcylblkcam',$showcylblkcam)
                ->with('linArray',$linArray)
                ->with('linfrntreslt',$linfrntreslt)
                ->with('linfrtmainrst',$linfrtmainrst)
                ->with('linrearcenteryes',$linrearcenteryes)
                ->with('linrearresyes',$linrearresyes)
                ->with('linrearremaryes',$linrearremaryes)
                ->with('camArray',$camArray)
                ->with('camfrntreslt',$camfrntreslt)
                ->with('camfrtmainrst',$camfrtmainrst)
                ->with('camrearcenteryes',$camrearcenteryes)
                ->with('camrearresyes',$camrearresyes)
                ->with('camrearremaryes',$camrearremaryes)
                ->with('showcytopdk',$showcytopdk)
                ->with('showcythread',$showcythread)
                ->with('showcybush',$showcybush)
                ->with('showcycap',$showcycap)
                //->with('showcluplatethi',$showcluplatethi)
                ->with('beforestartassembly',$beforestartassembly)

                ->with('showcylinderblock',$showcylinderblock);



        }
        //dd($frtmainrst);
        //echo '<pre>';print_r($myArray[3]);exit;
        //dd($showcylinderblock);exit;


    }

   //aggregate
    public function checkGateAggregateSave(DisassmblyAggregateRequest $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);exit;
        //echo $request['service_id'];exit;
        $service = Service::find($request['service_id']);
        // dd($service);
        $aggregate=MasterAggregate::where('service_request_id','=',$request['service_id'])
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset($aggregate->service_request_id)){
            //echo "rimpi";exit;
            $aggregate =new MasterAggregate();
        }

        $aggregate->service_request_id = $request['service_id'];
        $aggregate->dept_id = $request['dept_id'];
        $aggregate->aggr_type = $request['aggr_type'];
        // $aggregate->machine_modelno = $service->machine_modelno;
        // $aggregate->machine_serialno = $service->machine_serialno;
        $aggregate->arrangement_no = $request['arrangement_no'];
        // $aggregate->customer = $service->customer;
        $aggregate->customer_contact = $request['customer_contact'];
        // $aggregate->servicing_branch = $service->branch_name;
        $aggregate->branch_contact = $request['branch_contact'];
        $aggregate->crc_supervisor = $request['crc_supervisor'];
        $aggregate->crc_job_no = $request['crc_job_no'];
        $aggregate->branch_job_no = $request['branch_job_no'];
        $aggregate->date_arrival = $request['date_arrival'];
        $aggregate->date_dispatch = $request['date_dispatch'];
        $aggregate->machine_modelno = $request['machine_modelno'];
        $aggregate->machine_serialno = $request['machine_serialno'];
        $aggregate->customer = $request['customer'];
        $aggregate->servicing_branch = $request['servicing_branch'];

        $aggregate->save();


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }
   //pre
    public function checkGatePreHisDisSave(Request $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $prehist=MasterPreHistoryDis::where('service_request_id','=',$request['service_id'])
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset($prehist->id)){
            $prehist =new MasterPreHistoryDis();
        }

        $prehist->service_request_id = $request['service_id'];
        $prehist->dept_id = $request['dept_id'];
        $prehist->repair_mode = $request['repair_mode'];
        $prehist->engine_serial_no = $request['engine_serial_no'];
        $prehist->engine_arrange_no =$request['engine_arrange_no'];
        $prehist->machine_type = $request['machine_type'];
        $prehist->machine_serial_no= $request['machine_serial_no'];
        $prehist->smu=$request['smu'];
        $prehist->no_of_overhauls_done=$request['no_of_overhauls_done'];
        $prehist->last_overhaul_smu=$request['last_overhaul_smu'];
        $prehist->failure_details=$request['failure_details'];
        $prehist->major_cylinder_head=$request['major_cylinder_head'];
        $prehist->major_injector=$request['major_injector'];
        $prehist->major_oil_pump=$request['major_oil_pump'];
        $prehist->major_fuel_injection_pump=$request['major_fuel_injection_pump'];
        $prehist->save();


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
    //commercial
    public function checkGateCommerciallogisticDisSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $cmmercial=MasterCommercialValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cmmercial)){
            $cmmercial =new MasterCommercialValues();
        }
        // if(isset($cmmercial->id))
        $commercial=$request->all();

        //$obj = new MasterCommercialValues();



        if(isset($service->id)) {
            $cmmercial->service_request_id = $service->id;
            $cmmercial->dept_id = $request['dept_id'];
            $cmmercial->values = json_encode($commercial);
            $cmmercial->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
    //cc external
    public function checkGateCcexternalwashDisSave(Request $request)
    {
        //$myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $externalwas=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($externalwas)){
            $externalwas =new MasterCcinspectionExternalWashDetails();
        }

        $exterwash=$request->all();

        // $obj = new MasterCcinspectionExternalWashDetails();

        if(isset($service->id)) {
            $externalwas->service_request_id = $service->id;
            $externalwas->dept_id = $request['dept_id'];
            $externalwas->values = json_encode($exterwash);
            $externalwas->save();

            //send Notification

        }

        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

     //MasterCcinspectionBeforeStartAssembly
    public function inspectionbeforestartassembly(Request $request)
    {
        /*$service = Service::find($request['service_id']);
        $externalwas=MasterCCinspectionBeforeStartAssembly::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();*/

        $service = Service::find($request['service_id']);
        $beforeassembly=MasterCCinspectionBeforeStartAssembly::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset($beforeassembly)){
            $beforeassembly =new MasterCCinspectionBeforeStartAssembly();
        }
        $beforestart=$request->all();

        if(isset($service->id)) {
            $beforeassembly->service_request_id = $service->id;
            $beforeassembly->dept_id = $request['dept_id'];
            $beforeassembly->ccvalues = json_encode($beforestart);
            $beforeassembly->save();

        }
        // echo '<pre>';print_r($beforestart);
        //exit;
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

   //cc parts clean
    public function checkGateCcpartcleanDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $cleaning=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cleaning)){
            $cleaning =new MasterCcinspectionPartCleanDetails();
        }
        $partclean=$request->all();

        //$obj = new MasterCcinspectionPartCleanDetails();

        if(isset($service->id)) {
            $cleaning->service_request_id = $service->id;
            $cleaning->dept_id = $request['dept_id'];
            $cleaning->values = json_encode($partclean);
            $cleaning->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

   //loose parts
    public function checkGateLoosepartsDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        // $file=$request->file('photograph');
        $file=$request['part_description'];
        if(isset($service->id)){
            MasterLoosepartDis::where('service_request_id',$request['service_id'])->delete();
            foreach($file as $key=>$val){
                // echo'<pre>';print_r($val);echo'<pre>';
                //$obj->photograph=$request['photograph'];

                $txt= $val;
                /*  $imgfile = $val;


                  $save_imgfile = time(). $imgfile->getClientOriginalName();
                  $destinationPath = 'public/assets/uploads/engdisassembly/looseparts';
                  $imgfile->move($destinationPath, $save_imgfile);
                  //move_uploaded_file($val,$destinationPath.'/'.$save_imgfile);


                   $image = $save_imgfile;
*/
                //$obj->photograph = $image;
                /*if($file = $request->file('photograph')) {

                    $fileName = time().$file->getClientOriginalName() ;
                    $destinationPath = 'public/assets/uploads/engdisassembly/looseparts' ;
                    $file->move($destinationPath, $fileName);


                }die;*/

                $loosepart=new MasterLoosepartDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->part_no=$request['part_no'][$key];
                $loosepart->part_description=$txt;
                $loosepart->qty=$request['qty'][$key];
                $loosepart->part_condition=$request['part_condition'][$key];
                $loosepart->photograph = Null ;
                $loosepart->save();

            }



        }

        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
   //missing parst
    public function checkGateMissingdamagepartDisSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $missing=$request['missing_damage'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            MasterMissingdamagePartDis::where('service_request_id',$request['service_id'])->delete();
            foreach ($missing as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $loosepart = new MasterMissingdamagePartDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->description = $request['description'][$key];
                $loosepart->qty = $request['qty'][$key];
                $loosepart->missing_damage = $txt;
                $loosepart->photo = $request['photo'][$key];
                $loosepart->damage_details = $request['damage_details'][$key];
                $loosepart->action_taken = $request['action_taken'][$key];


                $loosepart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
    //status revision
    public function statusrevision(Request $request)
    {
        $service = Service::find($request['service_id']);
        $status=$request['details_of_amendment'];
        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            StatusRevision::where('service_request_id',$request['service_id'])->delete();
            foreach ($status as $key => $val) {
                //echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;
                $statusrevision = new StatusRevision();
                $statusrevision->service_request_id = $service->id;
                $statusrevision->dept_id = $request['dept_id'];
                $statusrevision->details_of_amendment= $txt;
                $statusrevision->revision_no = $request['revision_no'][$key];
                $statusrevision->page_no= $request['page_no'][$key];
                $statusrevision->reason_for_amendment = $request['reason_for_amendment'][$key];
                $statusrevision->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
      //disassembly cleaning
    public function checkgatedisassembly(Request $request)
    {
        $service = Service::find($request['service_id']);
        $disassembly=$request['comp_dissambly_start_date'];
        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            MasterDissamblyCleaningInspection::where('service_request_id',$request['service_id'])->delete();
            foreach ($disassembly as $key => $val) {
                // echo'<pre>';//print_r($val);
                $txt= $val;
                $masterdissambly = new MasterDissamblyCleaningInspection();
                $masterdissambly->service_request_id = $service->id;

                $masterdissambly->dept_id = $request['dept_id'];

                $masterdissambly->comp_model_no = $txt;
                $masterdissambly->comp_dissambly_start_date = $txt;
                $masterdissambly->comp_dissambly_end_date = $request['comp_dissambly_end_date'][$key];
                $masterdissambly->comp_cleaning_start_date = $request['comp_cleaning_start_date'][$key];
                $masterdissambly->comp_cleaning_end_date = $request['comp_cleaning_end_date'][$key];
                $masterdissambly->comp_inspection_assessment_start_date = $request['comp_inspection_assessment_start_date'][$key];
                $masterdissambly->comp_inspection_assessment_end_date = $request['comp_inspection_assessment_end_date'][$key];
                $masterdissambly->comp_offer_send_date = $request['comp_offer_send_date'][$key];
                $masterdissambly->save();
            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function engineassemblychecksheet(Request $request)
    {

        $service = Service::find($request['service_id']);
        $engineassemblychecksheet=$request['operation_desp'];
        if(isset($service->id)) {
            ChecksheetAssembly::where('service_request_id',$request['service_id'])->delete();
            foreach ($engineassemblychecksheet as $key => $val) {
                $txt=$val;
                $engineassembly=new ChecksheetAssembly();
                $engineassembly->service_request_id = $service->id;
                $engineassembly->dept_id = $request['dept_id'];
                $engineassembly->operation_desp=$txt;
                $engineassembly->specification=$request['specification'][$key];
                $engineassembly->actual_value=$request['actual_value'][$key];
                $engineassembly->save();
            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //list of sal
    public function checkGateListofsalvageDisSave(Request $request)
    {
        //$myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $salvage=$request['vendor_name'];



        if(isset($service->id)) {
            MasterListofSalvageDis::where('service_request_id',$request['service_id'])->delete();
            foreach ($salvage as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $loosepart = new MasterListofSalvageDis();
                $loosepart->service_request_id = $service->id;
                $loosepart->dept_id = $request['dept_id'];
                $loosepart->component_name =$request['component_name'][$key];
                $loosepart->description = $request['description'][$key];
                $loosepart->qty = $request['qty'][$key];
                $loosepart->out_date = $request['out_date'][$key];
                $loosepart->in_date = $request['in_date'][$key];
                $loosepart->vendor_name = $txt;
                $loosepart->inspected_by = $request['inspected_by'][$key];


                $loosepart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }
     //parts cylinder head
    public function checkGatePartinspectionCylinderheadDisSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new MasterPartsInspectionCylinderHeadValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->details = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //Parts Cooler Inspection
    public function partinspectionCoolerInspSave(Request $request)
    {
        //$myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=CoolerInspectionValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new CoolerInspectionValues();
        }
        $partscooler=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->values = json_encode($partscooler);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    public function checkGatePartinspectionOthercomponentDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partothercomp=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partothercomp)){
            $partothercomp =new MasterPartOthercomponentValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partothercomp->service_request_id = $service->id;
            $partothercomp->dept_id = $request['dept_id'];
            $partothercomp->values = json_encode($othercomp);
            $partothercomp->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //PartsFanDrive
    public function checkGatePartinspectionFandriveDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partfan=MasterPartFanDriveValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partfan)){
            $partfan =new MasterPartFanDriveValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partfan->service_request_id = $service->id;
            $partfan->dept_id = $request['dept_id'];
            $partfan->values = json_encode($othercomp);
            $partfan->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts Oil Pump
    public function checkGatePartinspectionOilpumpDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partoil=MasterPartOilPumpValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partoil)){
            $partoil =new MasterPartOilPumpValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partoil->service_request_id = $service->id;
            $partoil->dept_id = $request['dept_id'];
            $partoil->values = json_encode($othercomp);
            $partoil->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts Air Compressor
    public function checkGatePartinspectionAircompressorDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partair=MasterPartAirCompressorValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partair)){
            $partair =new MasterPartAirCompressorValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partair->service_request_id = $service->id;
            $partair->dept_id = $request['dept_id'];
            $partair->values = json_encode($othercomp);
            $partair->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts Water Pump
    public function checkGatePartinspectionwaterpumpDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partwater=MasterPartWaterPumpValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partwater)){
            $partwater =new MasterPartWaterPumpValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partwater->service_request_id = $service->id;
            $partwater->dept_id = $request['dept_id'];
            $partwater->values = json_encode($othercomp);
            $partwater->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    public function checkGatePartinspectionConnectingrodDisSave(Request $request)
    {
        $myrequest=$request->all();
        // dd($myrequest);
        $service = Service::find($request['service_id']);
        $connectingrod=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($connectingrod)){
            $connectingrod =new MasterPartConnectingRodValues();
        }
        $partconrod=$request->all();

        //$obj = new MasterCcinspectionPartCleanDetails();

        if(isset($service->id)) {
            $connectingrod->service_request_id = $service->id;
            $connectingrod->dept_id = $request['dept_id'];
            $connectingrod->values = json_encode($partconrod);
            $connectingrod->save();

            //send Notification

        }


        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

// parts cylinder block main
    public function checkGatePartinspectionCylinderblockDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcylinderblock=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcylinderblock)){
            $partcylinderblock =new MasterPartCylinderHeadValues();
        }


        $cyblockdetails = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcylinderblock->service_request_id = $service->id;
            $partcylinderblock->dept_id = $request['dept_id'];
            $partcylinderblock->values = json_encode($cyblockdetails);
            $partcylinderblock->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    // parts cylinder block linear
    public function checkGatePartinspectionCylinderblockLinearSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcylinderblock=PartCylinderBlockLinearValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcylinderblock)){
            $partcylinderblock =new PartCylinderBlockLinearValues();
        }


        $cyblockdetails = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcylinderblock->service_request_id = $service->id;
            $partcylinderblock->dept_id = $request['dept_id'];
            $partcylinderblock->values = json_encode($cyblockdetails);
            $partcylinderblock->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    // parts cylinder block cam bore
    public function checkGatePartinspectionCylinderblockCamboreSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcylinderblock=PartCylinderBlockCamboreValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcylinderblock)){
            $partcylinderblock =new PartCylinderBlockCamboreValues();
        }


        $cyblockdetails = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcylinderblock->service_request_id = $service->id;
            $partcylinderblock->dept_id = $request['dept_id'];
            $partcylinderblock->values = json_encode($cyblockdetails);
            $partcylinderblock->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts cylinder block top deck
    public function checkGatePartinspectionCylinderblockTopdeckSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=PartCylinderBlockTopDeckValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new PartCylinderBlockTopDeckValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->values = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts cylinder block thread
    public function checkGatePartinspectionCylinderblockThreadSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=PartCylinderBlockThreadValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new PartCylinderBlockThreadValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->values = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts cylinder block bush bore
    public function checkGatePartinspectionCylinderblockBushboreSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=PartCylinderBlockBushboreValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new PartCylinderBlockBushboreValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->values = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts cylinder block bush bore
    public function checkGatePartinspectionCylinderblockCapnoSave(Request $request)
    {
        $myrequest=$request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);

        $cylhead=PartCylinderBlockCapNoValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
//dd($cmmercial);exit;
        if(!isset($cylhead)){
            $cylhead =new PartCylinderBlockCapNoValues();
        }
        $partscylinder=$request->all();

        // $obj = new MasterPartsInspectionCylinderHeadValues();

        if(isset($service->id)) {
            $cylhead->service_request_id = $service->id;
            $cylhead->dept_id = $request['dept_id'];
            $cylhead->values = json_encode($partscylinder);
            $cylhead->save();

            //send Notification

        }



        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }


    //crankshaft
    public function checkGatePartinspectionCrankshaftDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcrankshaft=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcrankshaft)){
            $partcrankshaft =new MasterPartCrankshaftValue();
        }


        $pcrankshaft = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcrankshaft->service_request_id = $service->id;
            $partcrankshaft->dept_id = $request['dept_id'];
            $partcrankshaft->values = json_encode($pcrankshaft);
            $partcrankshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

   //parts camshaft
    public function checkGatePartinspectionCamshaftDisSave(Request $request)
    {
        // $myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcamshaft=MasterPartCamshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcamshaft)){
            $partcamshaft =new MasterPartCamshaftValue();
        }


        $parcamshaftput = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcamshaft->service_request_id = $service->id;
            $partcamshaft->dept_id = $request['dept_id'];
            $partcamshaft->values = json_encode($parcamshaftput);
            $partcamshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts lh camshaft
    public function checkGatePartinspectionLhCamshaftDisSave(Request $request)
    {
        // $myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcamshaft=PartLhCamshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcamshaft)){
            $partcamshaft =new PartLhCamshaftValue();
        }


        $parcamshaftput = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcamshaft->service_request_id = $service->id;
            $partcamshaft->dept_id = $request['dept_id'];
            $partcamshaft->values = json_encode($parcamshaftput);
            $partcamshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts rh camshaft
    public function checkGatePartinspectionRhCamshaftDisSave(Request $request)
    {
        // $myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcamshaft=PartRhCamshaftValue::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcamshaft)){
            $partcamshaft =new PartRhCamshaftValue();
        }


        $parcamshaftput = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcamshaft->service_request_id = $service->id;
            $partcamshaft->dept_id = $request['dept_id'];
            $partcamshaft->values = json_encode($parcamshaftput);
            $partcamshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }
    //parts rh camshaft
    public function checkGatePartinspectionRhCamshaftBushboreDisSave(Request $request)
    {
        // $myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partcamshaft=PartCamshaftBushboreValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partcamshaft)){
            $partcamshaft =new PartCamshaftBushboreValues();
        }


        $parcamshaftput = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partcamshaft->service_request_id = $service->id;
            $partcamshaft->dept_id = $request['dept_id'];
            $partcamshaft->values = json_encode($parcamshaftput);
            $partcamshaft->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //failed parts
    public function checkGateFailedPartsDisSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['qty'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            MasterFailedParts::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new MasterFailedParts();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->qty = $txt;
                $failedpart->description = $request['description'][$key];
                $failedpart->part_no = $request['part_no'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts rooler specific end cooler
    public function rollerSpcendcoolSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['description'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            RoolerSpecifiEndColValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new RoolerSpecifiEndColValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];

                $failedpart->description = $txt;
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->specification = $request['specification'][$key];
                $failedpart->measured = $request['measured'][$key];
                $failedpart->remarks = $request['remarks'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts clutch pack thickness

    public function partinspectionClutchpackThicknessSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['qty'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            ClutchPackThicknessValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new ClutchPackThicknessValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->qty = $txt;
                $failedpart->description = $request['description'][$key];
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->actual_val = $request['actual_val'][$key];
                $failedpart->measured_val = $request['measured_val'][$key];
                $failedpart->section = $request['section'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts clutch plate thickness
    public function partinspectionClutchplateThicknessSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['qty'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            ClutchPlateThicknessValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new ClutchPlateThicknessValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->qty = $txt;
                $failedpart->description = $request['description'][$key];
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->actual_val = $request['actual_val'][$key];
                $failedpart->measured_val = $request['measured_val'][$key];
                $failedpart->section = $request['section'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts clutch plate flatness
    public function partinspectionClutchplateFlatnessSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['qty'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            ClutchPlateFlatnessValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new ClutchPlateFlatnessValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->qty = $txt;
                $failedpart->description = $request['description'][$key];
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->actual_val = $request['actual_val'][$key];
                $failedpart->measured_val = $request['measured_val'][$key];
                $failedpart->section = $request['section'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts torque converter
    public function partinspectionTorqueConverterSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['clearance_component'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            TorqueConverterValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new TorqueConverterValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->clearance_component = $txt;
                $failedpart->turbine_diameter = $request['turbine_diameter'][$key];
                $failedpart->stator_diameter = $request['stator_diameter'][$key];
                $failedpart->max_worn = $request['max_worn'][$key];
                $failedpart->measured_val = $request['measured_val'][$key];
               // $failedpart->section = $request['section'][$key];

                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }


   //component inspection report

    public function componentinspectionreport(Request $request)
    {
       /* $service = Service::find($request['service_id']);
        $externalwas=ComponentInspReport::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();*/

        $service = Service::find($request['service_id']);
        $component=ComponentInspReport::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset( $component)){
            $component =new ComponentInspReport();
        }
        $cominspreport=$request->all();



        if(isset($service->id)) {
            $component->service_request_id = $service->id;
            $component->dept_id = $request['dept_id'];
            $component->ccvalues = json_encode($cominspreport);
            $component->save();

        }

        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    // parts roller specification
    public function rollerSpecificationSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['out_spd'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            RoolerSpecificationValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new RoolerSpecificationValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->out_spd = $txt;
                $failedpart->tread = $request['tread'][$key];
                $failedpart->inside_flade = $request['inside_flade'][$key];
                $failedpart->shell_bore = $request['shell_bore'][$key];
                $failedpart->tread_diameter = $request['tread_diameter'][$key];
                $failedpart->outside_flg = $request['outside_flg'][$key];
                $failedpart->total_flage = $request['total_flage'][$key];
                $failedpart->tread_diahund = $request['tread_diahund'][$key];


                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts roller measured
    public function rollerMeasuredSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $partoil=RoolerMeasuredValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($partoil)){
            $partoil =new RoolerMeasuredValues();
        }


        $othercomp = $request->all();

        // $obj = new MasterPartOthercomponentValues();

        if (isset($service->id)) {
            $partoil->service_request_id = $service->id;
            $partoil->dept_id = $request['dept_id'];
            $partoil->values = json_encode($othercomp);
            $partoil->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    //parts roller clear shaft salvage
    public function rollerClearBtwsftSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['description'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            RollerspcClearShaftValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new RollerspcClearShaftValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];

                $failedpart->specification = $request['specification'][$key];
                $failedpart->description = $txt;
                $failedpart->specification = $request['specification'][$key];
                $failedpart->measured = $request['measured'][$key];
                $failedpart->remarks = $request['remarks'][$key];



                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    // parts idler specification
    public function idlerSpecificationSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['width1'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            IdlerSpecificationValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new IdlerSpecificationValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->width2 = $request['width2'][$key];
                $failedpart->width1 = $txt;
                $failedpart->hub1 = $request['hub1'][$key];
                $failedpart->diameter1 = $request['diameter1'][$key];
                $failedpart->diameter2 = $request['diameter2'][$key];
                $failedpart->height1 = $request['height1'][$key];
                $failedpart->diameter3 = $request['diameter3'][$key];
                $failedpart->radious1 = $request['radious1'][$key];
                $failedpart->install1 = $request['install1'][$key];


                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts idler before salvage
    public function idlerMeasuredBeforeSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['width1'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            IdlerMeasuredBeforeValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new IdlerMeasuredBeforeValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->idler_no = $request['idler_no'][$key];
                $failedpart->width2 = $request['width2'][$key];
                $failedpart->width1 = $txt;
                $failedpart->hub1 = $request['hub1'][$key];
                $failedpart->diameter1 = $request['diameter1'][$key];
                $failedpart->diameter2 = $request['diameter2'][$key];
                $failedpart->height1 = $request['height1'][$key];
                $failedpart->diameter3 = $request['diameter3'][$key];
                $failedpart->radious1 = $request['radious1'][$key];
                $failedpart->install1 = $request['install1'][$key];


                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

  //parts idler after salvage
    public function idlerMeasuredAfterSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['width1'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            IdlerMeasuredAfterValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new IdlerMeasuredAfterValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->idler_no = $request['idler_no'][$key];
                $failedpart->width2 = $request['width2'][$key];
                $failedpart->width1 = $txt;
                $failedpart->hub1 = $request['hub1'][$key];
                $failedpart->diameter1 = $request['diameter1'][$key];
                $failedpart->diameter2 = $request['diameter2'][$key];
                $failedpart->height1 = $request['height1'][$key];
                $failedpart->diameter3 = $request['diameter3'][$key];
                $failedpart->radious1 = $request['radious1'][$key];
                $failedpart->install1 = $request['install1'][$key];


                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

  //parts idler spc end coler salvage
    public function idlerSpecEndcoolerSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['description'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            IdlerSpeciEndcolerValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new IdlerSpeciEndcolerValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->part_no = $request['part_no'][$key];
                $failedpart->specification = $request['specification'][$key];
                $failedpart->description = $txt;
                $failedpart->idler1 = $request['idler1'][$key];
                $failedpart->idler2 = $request['idler2'][$key];
                $failedpart->idler3 = $request['idler3'][$key];
                $failedpart->idler4 = $request['idler4'][$key];
                $failedpart->idler5 = $request['idler5'][$key];
                $failedpart->idler6 = $request['idler6'][$key];
                //$failedpart->install1 = $request['install1'][$key];


                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //parts idler clear shaft salvage
    public function idlerClearBtwsftSave(Request $request)
    {
        // $myrequest=$request->all();
        // dd($myrequest);


        $service = Service::find($request['service_id']);


        $failed=$request['description'];

        if(isset($service->id)) {
            // $missing=MasterMissingdamagePartDis::find($request['service_id']);
            // $missing=delete();
            IdlerspcClearShaftValues::where('service_request_id',$request['service_id'])->delete();
            //echo '<pre>';print_r($request['part_no']);exit;
            foreach ($failed as $key => $val) {
                // echo'<pre>';print_r($val);echo'<pre>';
                $txt= $val;

                $failedpart = new IdlerspcClearShaftValues();
                $failedpart->service_request_id = $service->id;
                $failedpart->dept_id = $request['dept_id'];
                $failedpart->idler_no = $request['idler_no'][$key];
                $failedpart->specification = $request['specification'][$key];
                $failedpart->description = $txt;
                $failedpart->specification = $request['specification'][$key];
                $failedpart->measured = $request['measured'][$key];
                $failedpart->remarks = $request['remarks'][$key];



                $failedpart->save();

            }
        }
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //transmission & tc component
    public function transmissionComponentSave(Request $request)
    {


        $service = Service::find($request['service_id']);
        $component=TransmissionComponent::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset( $component)){
            $component =new TransmissionComponent();
        }
        $cominspreport=$request->all();

        if(isset($service->id)) {
            $component->service_request_id = $service->id;
            $component->dept_id = $request['dept_id'];
            $component->values = json_encode($cominspreport);
            $component->save();

        }

        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }


    //Con Rod After Bush Replacement
    public function checkGateConrodBushReplacementDisSave(Request $request)
    {
        //$myrequest = $request->all();
        //dd($myrequest);
        $service = Service::find($request['service_id']);
        $conrodbusrep=MasterConRodBushReplacementValues::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();
        //dd($cmmercial);exit;
        if(!isset($conrodbusrep)){
            $conrodbusrep =new MasterConRodBushReplacementValues();
        }


        $othercomp = $request->all();

        if (isset($service->id)) {
            $conrodbusrep->service_request_id = $service->id;
            $conrodbusrep->dept_id = $request['dept_id'];
            $conrodbusrep->values = json_encode($othercomp);
            $conrodbusrep->save();
        }
        //send Notification
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);

    }

    // engine assembly checksheet
    public function checkSheetAssemblyCommon($id)
    {
        $dept_id = 1;

        $service = Service::find($id);
        // dd($service);exit;

        if (!empty($service)) {

            //engine assembly checksheet

            $showassembly = ChecksheetAssembly::where('service_request_id', '=', $service->id)
                //->where('dept_id','=',1)
                ->get()->first();
            if (isset($showassembly->id)) {
                $showassembly = json_decode($showassembly->cc_value);
            } else {
                $showassembly = Null;
            }

            $allvalassembly = ChecksheetAssembly::where('service_request_id', '=', $service->id)
                // ->where('dept_id','=',1)
                ->get()->first();

            return view('admin.include.checksheetAssemblyCommon')
                ->with('service', $service)
                ->with('showassembly', $showassembly)
                ->with('allvalassembly', $allvalassembly);
        }
        else{
                $service=Null;
                $showassembly=Null;

                return view('admin.include.checksheetAssemblyCommon')
                    ->with('service',$service)
                    ->with('showassembly', $showassembly);
        }

    }

    public function engineassembly(Request $request)
    {
        $service = Service::find($request['service_id']);
        $engine=ChecksheetAssembly::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        $service = Service::find($request['service_id']);
        $engineassemly=ChecksheetAssembly::where('service_request_id','=',$service->id)
            ->where('dept_id','=',$request['dept_id'])->get()->first();

        if(!isset(  $engineassemly)){
            $engineassemly =new ChecksheetAssembly();
        }
        $engineassemblyreport=$request->all();
        if(isset($service->id)) {
            $engineassemly->service_request_id = $service->id;
            $engineassemly->dept_id = $request['dept_id'];
            $engineassemly->cc_value = json_encode($engineassemblyreport);
            $engineassemly->save();

        }

        return redirect('admin/check-sheet-assembly-common/'.$request['service_id']);
    }


    public function checkSheetTotalFormSave(Request $request)
    {

        $service = Service::find($request['service_id']);
        //dd($service);exit;

        //Aggregate Freeze
        $agreesubmit = MasterAggregate::where('service_request_id', '=', $service->id)->get()->first();
        //dd($agreesubmit);exit;
        if (isset($agreesubmit->id)){
            $agreesubmit->work_done = 1;
            $agreesubmit->save();
        }
        //pre history freeze

        $presubmit=MasterPreHistoryDis::where('service_request_id','=',$service->id)->get()->first();
        if (isset($presubmit->id)) {
            $presubmit->work_done = 1;
            $presubmit->save();
        }
        //commercial freeze
        $commercialsubmit=MasterCommercialValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($commercialsubmit->id)) {
            $commercialsubmit->work_done = 1;
            $commercialsubmit->save();
        }
        //loose part
        $loosesubmit=MasterLoosepartDis::where('service_request_id','=',$service->id)->get()->first();
        if (isset($loosesubmit->id)) {
            $loosesubmit->work_done = 1;
            $loosesubmit->save();
        }

        //cc external wash
        $externalwashsubmit=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$service->id)->get()->first();
        if (isset($externalwashsubmit->id)) {
            $externalwashsubmit->work_done = 1;
            $externalwashsubmit->save();
        }
//cc inspection before start assembly

        $beforestartassembly=MasterCCinspectionBeforeStartAssembly::where('service_request_id','=',$service->id)->get()->first();
        if (isset($beforestartassembly->id)) {
            $beforestartassembly->work_done = 1;
            $beforestartassembly->save();
        }
//component inspection report
        $compinspectionreport=ComponentInspReport::where('service_request_id','=',$service->id)->get()->first();
        if (isset( $compinspectionreport->id)) {
            $compinspectionreport->work_done = 1;
            $compinspectionreport->save();
        }
        //status_revision
        $statusrevision=StatusRevision::where('service_request_id','=',$service->id)->get()->first();
        if (isset($statusrevision->id)) {
            $statusrevision->work_done = 1;
            $statusrevision->save();
        }
        //disassembly checksheet inspection checksheet
        $showdiss=MasterDissamblyCleaningInspection::where('service_request_id','=',$service->id)->get()->first();
        if (isset($showdiss->id)) {
            $showdiss->work_done = 1;
            $showdiss->save();
        }


        //cc part clean
        $partcleansubmit=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$service->id)->get()->first();
        if (isset($partcleansubmit->id)) {
            $partcleansubmit->work_done = 1;
            $partcleansubmit->save();
        }

        //missing damage
        $partcleansubmit=MasterMissingdamagePartDis::where('service_request_id','=',$service->id)->get()->first();
        if (isset($partcleansubmit->id)) {
            $partcleansubmit->work_done = 1;
            $partcleansubmit->save();
        }

        //parts-cylinder block
        $cylinderblocksubmit=MasterPartCylinderHeadValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cylinderblocksubmit->id)) {
            $cylinderblocksubmit->work_done = 1;
            $cylinderblocksubmit->save();
        }

        //parts-cranshaft
        $cranshaftsubmit=MasterPartCrankshaftValue::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cranshaftsubmit->id)) {
            $cranshaftsubmit->work_done = 1;
            $cranshaftsubmit->save();
        }

        //parts-camshaft
        $camshaftsubmit=MasterPartCamshaftValue::where('service_request_id','=',$service->id)->get()->first();
        if (isset($camshaftsubmit->id)) {
            $camshaftsubmit->work_done = 1;
            $camshaftsubmit->save();
        }

        //parts-connectingrod
        $connrodsubmit=MasterPartConnectingRodValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($connrodsubmit->id)) {
            $connrodsubmit->work_done = 1;
            $connrodsubmit->save();
        }

        //parts-fandrive
        $partsfandrive=MasterPartFanDriveValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($partsfandrive->id)) {
            $partsfandrive->work_done = 1;
            $partsfandrive->save();
        }

        //parts-oil pump
        $partsoilpump=MasterPartOilPumpValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($partsoilpump->id)) {
            $partsoilpump->work_done = 1;
            $partsoilpump->save();
        }
        //parts-water pump
        $partswaterpump=MasterPartWaterPumpValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($partswaterpump->id)) {
            $partswaterpump->work_done = 1;
            $partswaterpump->save();
        }
        //parts-cylinder head &oil
        $cyheadsubmit=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cyheadsubmit->id)) {
            $cyheadsubmit->work_done = 1;
            $cyheadsubmit->save();
        }

        //parts-othercomp
        $othersubmit=MasterPartOthercomponentValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($othersubmit->id)) {
            $othersubmit->work_done = 1;
            $othersubmit->save();
        }

        //list of salvage
        $listsalsubmit=MasterListofSalvageDis::where('service_request_id','=',$service->id)->get()->first();
        if (isset($listsalsubmit->id)) {

            $listsalsubmit->work_done = 1;
            $listsalsubmit->save();
        }

        //Failed parts
        $listsalsubmit=MasterFailedParts::where('service_request_id','=',$service->id)->get()->first();
        if (isset($listsalsubmit->id)) {

            $listsalsubmit->work_done = 1;
            $listsalsubmit->save();
        }

        //Conrod bush
        $listcon=MasterConRodBushReplacementValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($listcon->id)) {

            $listcon->work_done = 1;
            $listcon->save();
        }

        //Transmission
        $trans=TransmissionComponent::where('service_request_id','=',$service->id)->get()->first();
        if (isset($trans->id)) {

            $trans->work_done = 1;
            $trans->save();
        }
        //parts cylinder linear
        $lin=PartCylinderBlockLinearValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($lin->id)) {

            $lin->work_done = 1;
            $lin->save();
        }
        //parts cylinder linear
        $cambre=PartCylinderBlockCamboreValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cambre->id)) {

            $cambre->work_done = 1;
            $cambre->save();
        }
        //parts cylinder top deck
        $topdk=PartCylinderBlockTopDeckValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($topdk->id)) {

            $topdk->work_done = 1;
            $topdk->save();
        }
        //parts cylinder thred
        $tred=PartCylinderBlockThreadValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($tred->id)) {

            $tred->work_done = 1;
            $tred->save();
        }
        //parts cylinder bush bore
        $bush=PartCylinderBlockBushboreValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($bush->id)) {

            $bush->work_done = 1;
            $bush->save();
        }
        //parts cylinder cap width
        $cap=PartCylinderBlockCapNoValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cap->id)) {

            $cap->work_done = 1;
            $cap->save();
        }
        //parts camshaft lh
        $camlh=PartLhCamshaftValue::where('service_request_id','=',$service->id)->get()->first();
        if (isset($camlh->id)) {

            $camlh->work_done = 1;
            $camlh->save();
        }
        //parts camshaft rh
        $camrh=PartRhCamshaftValue::where('service_request_id','=',$service->id)->get()->first();
        if (isset($camrh->id)) {

            $camrh->work_done = 1;
            $camrh->save();
        }
        //parts camshaft cam bush
        $cambush=PartCamshaftBushboreValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($cambush->id)) {

            $cambush->work_done = 1;
            $cambush->save();
        }
        //parts air
        $air=MasterPartAirCompressorValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($air->id)) {

            $air->work_done = 1;
            $air->save();
        }
        //parts cooler
        $coleer=CoolerInspectionValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($coleer->id)) {

            $coleer->work_done = 1;
            $coleer->save();
        }
        //parts clutch pack
        $clupck=ClutchPackThicknessValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($clupck->id)) {

            $clupck->work_done = 1;
            $clupck->save();
        }
        //parts clutch plate thi
        $plathi=ClutchPlateThicknessValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($plathi->id)) {

            $plathi->work_done = 1;
            $plathi->save();
        }
        //parts clutch plate flat
        $plaflt=ClutchPlateFlatnessValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($plaflt->id)) {

            $plaflt->work_done = 1;
            $plaflt->save();
        }
        //parts torque
        $torque=TorqueConverterValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($torque->id)) {

            $torque->work_done = 1;
            $torque->save();
        }
        //parts roller spci
        $rollpcs=RoolerSpecificationValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($rollpcs->id)) {

            $rollpcs->work_done = 1;
            $rollpcs->save();
        }
        //parts roller meas
        $rollmea=RoolerMeasuredValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($rollmea->id)) {

            $rollmea->work_done = 1;
            $rollmea->save();
        }
        //parts roller end col
        $rollend=RoolerSpecifiEndColValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($rollend->id)) {

            $rollend->work_done = 1;
            $rollend->save();
        }
        //parts roller clr shft
        $rolshft=RollerspcClearShaftValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($rolshft->id)) {

            $rolshft->work_done = 1;
            $rolshft->save();
        }

        //parts idler spc
        $idlerspc=IdlerSpecificationValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($idlerspc->id)) {

            $idlerspc->work_done = 1;
            $idlerspc->save();
        }
        //parts idler mea before
        $idlebf=IdlerMeasuredBeforeValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($idlebf->id)) {

            $idlebf->work_done = 1;
            $idlebf->save();
        }
        //parts idler mea after
        $idleaaf=IdlerMeasuredAfterValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($idleaaf->id)) {

            $idleaaf->work_done = 1;
            $idleaaf->save();
        }
        //parts idler end col
        $idleend=IdlerSpeciEndcolerValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($idleend->id)) {

            $idleend->work_done = 1;
            $idleend->save();
        }
        //parts idler clear
        $idlclr=IdlerspcClearShaftValues::where('service_request_id','=',$service->id)->get()->first();
        if (isset($idlclr->id)) {

            $idlclr->work_done = 1;
            $idlclr->save();
        }



        //return redirect()->to('admin/check-sheet-entry-common/'.$request['service_id'])
        return redirect('admin/check-sheet-entry-common/'.$request['service_id']);
    }

    //checksheet download in excel

    public function excelDownload(Request $request)
    {
        $service = Service::find($request['service_id']);

        //excel download

        $loosedownload = MasterLoosepartDis::select('gw_master_disa_loose_part.*')

            ->where('gw_master_disa_loose_part.service_request_id', '=', $service->id)->get();




        /* $com[]=$commerdownload->toArray();
           $com[] =  (array) $commerdownload;
           function groupArray($com, $commerdownload, $preserveGroupKey = false, $preserveSubArrays = false)
           {
               $temp = array();
               foreach ($com as $key => $value) {
                   $groupValue = $value[$commerdownload];
                   if (!$preserveGroupKey) {
                       unset($com[$key][$commerdownload]);
                   }
                   if (!array_key_exists($groupValue, $temp)) {
                       $temp[$groupValue] = array();
                   }

                   if (!$preserveSubArrays) {
                       $data = count($com[$key]) == 1 ? array_pop($com[$key]) : $com[$key];
                   } else {
                       $data = $com[$key];
                   }
                   $temp[$groupValue][] = $data;
               }
               return $temp;

       //dd($temp);exit;
       }
           $newArray = array();
           foreach($com as $array) {
               foreach($commerdownload as $k=>$v) {
                   $newArray[$k] = $v;
               }
           }
           //echo"<pre>";print_r($newArray);exit;
               foreach ($com as $commer){

               $log=$new[] = $commer;
           }
               $commercial=array_push($new);



         $var=[];

           $var=array_push($arrays,$commercial);

           //$var= ;
         //echo"<pre>";print_r($var);exit;*/

        $style = (new StyleBuilder())
            ->setFontBold()
            //->setBackgroundColor(Color::YELLOW)
            ->build();
        $path='/home/vhruqiyfkeq2/public_html/gcpl-quality/';
        //$path='C:/Apache24/htdocs/gcpl-quality/';
        (new FastExcel($loosedownload))->headerStyle($style)->export($path.'test.xlsx', function ($loosedownload) {
            return [


                'Part NO' => $loosedownload['part_no'],
                'QTY' => $loosedownload['qty'],

            ];

        });


        $file=$path.'test.xlsx';
        $name = basename($file);
        return response()->download($file, $name);


    }


    //disassembly chechsheet approved/reject by det head
    public function headApproveChecksheetSave(Request $request)
    {
        $service = Service::find($request['service_id']);
        //$obj = Service::find($request['id']);

        //dd($obj);exit;
        $obj = new ChecksheetStatus();

        $obj->service_request_id=$service->id;

        $obj->disassembly_status=$request['status'];
        $obj->disassembly_comment=$request['comment_for_approve'];
        $obj->save();
        $id=$obj->id;

        //rejected checksheet will be reopen for fillup



        //mail send to dept for approve/reject


        return redirect('admin/eng-head-dashboard/');
    }

    //assembly chechsheet approved/reject by det head
    public function headApproveAssemblyChecksheetSave(Request $request)
    {
        $service = Service::find($request['service_id']);
        //$obj = Service::find($request['id']);

        //dd($obj);exit;
        $obj = new ChecksheetStatus();

        $obj->service_request_id=$service->id;

        $obj->assembly_status=$request['status'];
        $obj->assembly_comment=$request['comment_for_approve'];
        $obj->save();
        $id=$obj->id;

        //rejected checksheet will be reopen for fillup

        /*if($obj->status=='Rejected'){
           // dd(1);
            $agreesubmit = MasterAggregate::where('service_request_id', '=', $id)->get()->first();
            //dd($agreesubmit);exit;
            if (isset($agreesubmit->id)){
                $agreesubmit->work_done = 0;
                $agreesubmit->save();
            }

            //pre history freeze open
            $presubmit=MasterPreHistoryDis::where('service_request_id','=',$id)->get()->first();
            if (isset($presubmit->id)) {
                $presubmit->work_done = 1;
                $presubmit->save();
            }
            //commercial freeze
            $commercialsubmit=MasterCommercialValues::where('service_request_id','=',$id)->get()->first();
            if (isset($commercialsubmit->id)) {
                $commercialsubmit->work_done = 1;
                $commercialsubmit->save();
            }
            //loose part
            $loosesubmit=MasterLoosepartDis::where('service_request_id','=',$id)->get()->first();
            if (isset($loosesubmit->id)) {
                $loosesubmit->work_done = 1;
                $loosesubmit->save();
            }

            //cc external wash
            $externalwashsubmit=MasterCcinspectionExternalWashDetails::where('service_request_id','=',$id)->get()->first();
            if (isset($externalwashsubmit->id)) {
                $externalwashsubmit->work_done = 1;
                $externalwashsubmit->save();
            }

            //cc part clean
            $partcleansubmit=MasterCcinspectionPartCleanDetails::where('service_request_id','=',$id)->get()->first();
            if (isset($partcleansubmit->id)) {
                $partcleansubmit->work_done = 1;
                $partcleansubmit->save();
            }

            //missing damage
            $partcleansubmit=MasterMissingdamagePartDis::where('service_request_id','=',$id)->get()->first();
            if (isset($partcleansubmit->id)) {
                $partcleansubmit->work_done = 1;
                $partcleansubmit->save();
            }

            //parts-cylinder block
            $cylinderblocksubmit=MasterPartCylinderHeadValues::where('service_request_id','=',$id)->get()->first();
            if (isset($cylinderblocksubmit->id)) {
                $cylinderblocksubmit->work_done = 1;
                $cylinderblocksubmit->save();
            }

            //parts-cranshaft
            $cranshaftsubmit=MasterPartCrankshaftValue::where('service_request_id','=',$id)->get()->first();
            if (isset($cranshaftsubmit->id)) {
                $cranshaftsubmit->work_done = 1;
                $cranshaftsubmit->save();
            }

            //parts-camshaft
            $camshaftsubmit=MasterPartCamshaftValue::where('service_request_id','=',$id)->get()->first();
            if (isset($camshaftsubmit->id)) {
                $camshaftsubmit->work_done = 1;
                $camshaftsubmit->save();
            }

            //parts-connectingrod
            $connrodsubmit=MasterPartConnectingRodValues::where('service_request_id','=',$id)->get()->first();
            if (isset($connrodsubmit->id)) {
                $connrodsubmit->work_done = 1;
                $connrodsubmit->save();
            }

            //parts-cylinder head &oil
            $cyheadsubmit=MasterPartsInspectionCylinderHeadValues::where('service_request_id','=',$id)->get()->first();
            if (isset($cyheadsubmit->id)) {
                $cyheadsubmit->work_done = 1;
                $cyheadsubmit->save();
            }

            //parts-othercomp
            $othersubmit=MasterPartOthercomponentValues::where('service_request_id','=',$id)->get()->first();
            if (isset($othersubmit->id)) {
                $othersubmit->work_done = 1;
                $othersubmit->save();
            }

            //list of salvage
            $listsalsubmit=MasterListofSalvageDis::where('service_request_id','=',$id)->get()->first();
            if (isset($listsalsubmit->id)) {

                $listsalsubmit->work_done = 1;
                $listsalsubmit->save();
            }



        }*/

        //mail send to dept for approve/reject


        return redirect('admin/eng-head-dashboard/');
    }

}
