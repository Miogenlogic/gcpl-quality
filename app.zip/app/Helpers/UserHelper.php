<?php

namespace App\Helpers;

use App\Models\CcInspectionAfterExternalwashDis;
use App\Models\CcInspectionAfterPartCleaningDis;
use App\Models\ChecksheetChildSection;
use App\Models\ChecksheetColumn;
use App\Models\ChecksheetSectionWiseColumn;
use App\Models\ChecksheetSubChildSection;
use App\Models\EngineAssembly;
use App\Models\MasterAggregate;
use App\Models\MasterBranch;
use App\Models\MasterCcinspectionExternalWashDetails;
use App\Models\MasterCheckGate;
use App\Models\MasterCheckGateInspectionQuestion;
use App\Models\MasterCheckSheetSection;
use App\Models\MasterCommercialLogisticDetails;
use App\Models\MasterCommercialValues;
use App\Models\MasterComponentArrangementNo;
use App\Models\MasterComponentDetails;
use App\Models\MasterComponentModelNo;
use App\Models\MasterComponentSerialNo;
use App\Models\MasterComponentType;
use App\Models\MasterConRodBushReplacementDetails;
use App\Models\MasterCoolerInspection;
use App\Models\MasterCustomer;
use App\Models\MasterDepartment;
use App\Models\MasterEmployee;
use App\Models\MasterDesignation;
use App\Models\MasterJobType;
use App\Models\MasterListofSalvageDis;
use App\Models\MasterLoosepartDis;
use App\Models\MasterMachine;
use App\Models\MasterMachineModelNo;
use App\Models\MasterMachineSerialNo;
use App\Models\MasterMCModel;
use App\Models\MasterMCSerialNumber;
use App\Models\MasterMissingdamagePartDis;
use App\Models\MasterPartAirCompressorDetails;
use App\Models\MasterPartCamshaftBushboreDetails;
use App\Models\MasterPartCamshaftDetails;
use App\Models\MasterPartCamshaftValue;
use App\Models\MasterPartConnectingRodDetails;
use App\Models\MasterPartConnectingRodValues;
use App\Models\MasterPartCrankshaftDetails;
use App\Models\MasterPartCrankshaftValue;
use App\Models\MasterPartCylinderBlockCapNODetails;
use App\Models\MasterPartCylinderBlockThreadDetails;
use App\Models\MasterPartCylinderBlockTopDeckDetails;
use App\Models\MasterPartCylinderHeadDetails;
use App\Models\MasterPartCylinderHeadValues;
use App\Models\MasterPartFanDriveDetails;
use App\Models\MasterPartinspectionCylinderHeadDetails;
use App\Models\MasterPartOilPumpDetails;
use App\Models\MasterPartOthercomponentBasicEngine;
use App\Models\MasterPartOthercomponentCoolingSystem;
use App\Models\MasterPartOthercomponentFuelSystem;
use App\Models\MasterPartOthercomponentLubricationSystem;
use App\Models\MasterPartOthercomponentValues;
use App\Models\MasterPartsInspectionCylinderHeadValues;
use App\Models\MasterPartWaterPumpDetails;
use App\Models\MasterPreHistoryDis;
use App\Models\MasterSection;
use App\Models\MasterSegment;
use App\Models\ModelWiseCheecksheet;
use App\Models\PdiChecksheetDetails;
use App\Models\Roles;
use App\Models\Masterrole;
use App\Models\MasterTask;
use App\Models\Menu;
use App\Models\Menuaccess;
use App\Models\RoolerMeasuredDetails;
use App\Models\Service;
use App\Models\InspectionBeforeStartAssembly;
use App\Models\ComponentInspectionReport;
use App\Models\TransmissionComponentDetails;
use App\Models\ProjectPlanMaster;
use App\Models\ProjectTask;
use App\Models\ProjectUser;
use App\Models\TaskUser;
use Carbon\Carbon;
use DB;
use Hash;
use Auth;
use Mail;
use DataTables;
use Session;
use Redirect;
use Alert;
use Input;
use Illuminate\Support\Facades\Crypt;
use App\Providers\HelperServiceProvider;
use Spatie\Permission\Models\Role;


class UserHelper extends HelperServiceProvider{


    static function role()
    {
        $role=Role::where('name','!=','super_admin')->get();

        return $role;
    }
    static function checkgate()
    {
        $checkgate=MasterCheckGate::get();

        return $checkgate;
    }
    static function checkgatejobtype()
    {
        $checkjob=MasterJobType::select('*')->where('status','=','Active')->get();

        return $checkjob;
    }

    static function customer()
    {
        $customer = MasterCustomer::get();
        return $customer;
    }
    static function componentserialno()
    {
        $compserial = MasterComponentSerialNo::get();
        return $compserial;
    }

    static function componenttype()
    {
        $comptype = MasterComponentType::get();
        return $comptype;
    }

    static function componentmodelno()
    {
        $compmodel=MasterComponentModelNo::get();

        return $compmodel;
    }
    static function getComponentModelNoById($id)
    {
        $compmodel=MasterComponentModelNo::find($id);
        return $compmodel;
    }

    static function branchname()
    {
        $branchnme=MasterBranch::get();

        return $branchnme;
    }

    static function segment()
    {
        $segment=MasterSegment::get();

        return $segment;
    }

    static function checkgatequestion()
    {
        $question=MasterCheckGateInspectionQuestion::select('*')->where('check_gate_id','=','1')->get();

        return $question;
    }
    static function checkgatequestiontwo()
    {
        $checktwoquestion=MasterCheckGateInspectionQuestion::select('*')->where('check_gate_id','=','2')->get();

        return $checktwoquestion;
    }
    static function checkgatequestionthree()
    {
        $checkthreequestion=MasterCheckGateInspectionQuestion::select('*')->where('check_gate_id','=','3')->get();

        return $checkthreequestion;
    }
    static function checkgatequestionfour()
    {
        $checkfourquestion=MasterCheckGateInspectionQuestion::select('*')->where('check_gate_id','=','4')->get();

        return $checkfourquestion;
    }


    static function servicerequest()
    {
        $servicereq=Service::get();

        return $servicereq;
    }

    static function arrangementno()
    {
        $arrno=MasterComponentArrangementNo::get();

        return $arrno;
    }
    static function machinemodelno()
    {
        $mchmodel=MasterMCModel::get();

        return $mchmodel;
    }
    static function mastermachineserialno()
    {
        $mchserial=MasterMachineSerialNo::get();

        return $mchserial;
    }

    static function machineserialno($model_no)
    {
        $mchserial=MasterMCSerialNumber::where('mc_model_id','=',$model_no)->get();
        return $mchserial;
    }
    static function getmachineserialnoById($id)
    {
        $mchserial=MasterMCModel::find($id);
        return $mchserial;
    }
    static function getmodelnoById($id)
    {
        $mchmodel=MasterComponentDetails::find($id);
        return $mchmodel;
    }


    static function componentdetails($comserial)
    {
        $compdet=MasterComponentDetails::where('mc_model_id','=',$comserial)->get();
        /*$compdet=MasterComponentDetails::select('gw_master_comp_details.*')
            ->leftjoin('gw_master_mc_model','gw_master_mc_model.id','=','gw_master_comp_details.mc_model_id')
            //->where('mc_model_id','=','gw_master_mc_model.id')
            ->get();
        //dd($mchserial);*/
        return $compdet;
    }

    static function componentserial($serialcomp)
    {
        $compse=MasterComponentDetails::where('mc_model_id','=',$serialcomp)->get();
        /*$compdet=MasterComponentDetails::select('gw_master_comp_details.*')
            ->leftjoin('gw_master_mc_model','gw_master_mc_model.id','=','gw_master_comp_details.mc_model_id')
            //->where('mc_model_id','=','gw_master_mc_model.id')
            ->get();
        //dd($mchserial);*/
        return $compse;
    }



    static function ccinspexternalwash()
    {
        $exterwash=CcInspectionAfterExternalwashDis::get();

        return $exterwash;
    }
    static function commertciallogistic()
    {
        $commercial=MasterCommercialLogisticDetails::get();

        return $commercial;
    }
    static function ccpartclean()
    {
        $ccpartclean=CcInspectionAfterPartCleaningDis::get();

        return $ccpartclean;
    }

    static function partinspectioncylinderhead()
    {
        $cylinderhead=MasterPartinspectionCylinderHeadDetails::get();

        return $cylinderhead;
    }

    static function partothercompbasicengine()
    {
        $basicengine=MasterPartOthercomponentBasicEngine::get();

        return $basicengine;
    }
    static function partothercomplubrication()
    {
        $lubri=MasterPartOthercomponentLubricationSystem::get();

        return $lubri;
    }
    static function partothercompcooler()
    {
        $cooler=MasterPartOthercomponentCoolingSystem::get();

        return $cooler;
    }
    static function partothercompfuel()
    {
        $fuel=MasterPartOthercomponentFuelSystem::get();

        return $fuel;
    }
    static function partconnectingrod()
    {
        $conrod=MasterPartConnectingRodDetails::get();

        return $conrod;
    }
    static function partcylinderhead()
    {
        $cylinhed=MasterPartCylinderHeadDetails::get();

        return $cylinhed;
    }

    static function partcrankshaft()
    {

        $camshaft=MasterPartCrankshaftDetails::get();

        return $camshaft;
    }
    static function partcamshaftdetails()
    {
        $cmsftdetails=MasterPartCamshaftDetails::get();

        return $cmsftdetails;
    }
    //cylinder block top deck
    static function partcylinderTop()
    {
        $cylindertop=MasterPartCylinderBlockTopDeckDetails::get();

        return $cylindertop;
    }

//cylinder block top deck
    static function partcylinderThread()
    {
        $cylinderthred=MasterPartCylinderBlockThreadDetails::get();

        return $cylinderthred;
    }
//cylinder block cap clear
    static function partcylinderCapClear()
    {
        $cylindercapclr=MasterPartCylinderBlockCapNODetails::get();

        return $cylindercapclr;
    }


    static function partcamshaftbushbore()
    {
        $bushbore=MasterPartCamshaftBushboreDetails::get();

        return $bushbore;
    }
    static function roles()

    {
        $roles=Masterrole::get();

        return $roles;
    }
    static function menus()
    {
        $menus = Menu::get();


        return $menus;
    }

    static function menuaccess()
    {
        $menuaccess=Menuaccess::get();
        return $menuaccess;
    }
    static function checkmenu()
    {
        $checkmenu=Menu::select('*');
        return $checkmenu;
    }

    static function machinemodeltask()
    {
        $machinemodeltask=MasterTask::get();
        return $machinemodeltask;



    }


    static function section()
    {
        $section=MasterSection::get();
        return $section;
    }
    static function beforestartassembly()
    {
        $beforestart=InspectionBeforeStartAssembly::get();
        return $beforestart;
    }

    static function ComponentInspectionReport()
    {
        $cominspreport=ComponentInspectionReport::get();
        return $cominspreport;
    }

    static function designation()
    {
        $designation=MasterDesignation::get();
        return $designation;
    }

    static function jobrole()
    {
        $jobrole=Role::get();
        //dd($jobrole);exit;
        return $jobrole;
    }

    //url encode
    static function urlEncode($str)
    {
        $encrypted = Crypt::encryptString($str);
        return $encrypted;
    }
    //url decode
    static function urlDecode($str)
    {
        $decrypted = Crypt::decryptString($str);
        return $decrypted;
    }


    static function servicedepartment($id)
    {
        $employee=MasterEmployee::find($id);

        return $employee;
    }

    static function designation1()
    {
        $masterdesignation=MasterDesignation::get();
        return $masterdesignation;

    }
    //transmission
    static function TransmissionComponent()
    {
        $transmiss=TransmissionComponentDetails::get();
        return $transmiss;
    }

    //rooler measured
    static function RoolerMeasued()
    {
        $roolermea=RoolerMeasuredDetails::get();
        return $roolermea;
    }



    static function authenticate()
    {
        //$login=session->user("logged_in");
        // $login=\Illuminate\Support\Facades\Session::get();
        // $value = session()->get('key');
        /*if (!function_exists('authenticate')) {

           function authenticate() {
               $CI = & get_instance();
               $empCode=$CI->session->userdata("logged_in");
               if(!$empCode['emp_code']){

                   echo "<script>window.parent.location.href='".base_url()."'</script>";
                   exit;
               }
           }
       }*/

    }

    static function dropdownpartnumber()
    {
        $partno=MasterComponentDetails::  get();
            //select('id','comp_serial_no')
            //->groupby('comp_serial_no')


        return $partno;
    }


    static function dropdownpartnumber_1()
    {
        $partno=MasterComponentDetails::get();

        return $partno;
    }


    static function mailnoti($to,$subj,$msg)
    {
        $url=url('/');
        $to = 'rimpi2019das@hotmail.com';
        $subj = 'Welcome';
        $msg = view('admin.mail.checkgateOneNotificationMail', ['url'=>$url])->render();
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From:' . \Config::get('env.service_mail')."\r\n";
        mail($to, $subj, $msg, $headers);

    }

    static function checkmenulisting()
    {
        $checkmenu=Menuaccess::select('*')->get();


        return $checkmenu;
    }

    //parts cooler inspection
    static function coolerinsp()
    {
        $cooler=MasterCoolerInspection::select('*')->get();

        return $cooler;
    }
    static function pdichecksheet()
    {
        $pdienginevisual=PdiChecksheetDetails::select('*')->get();


        return $pdienginevisual;
    }

    static function departmentforchecksheet()
    {
        $dept=MasterDepartment::get();


        return $dept;
    }
    static function sectionforchecksheet()
    {
        $sect=MasterCheckSheetSection::get();


        return $sect;
    }
    //fan drive
    static function partsfandrive()
    {
        $fandri=MasterPartFanDriveDetails::get();


        return $fandri;
    }
    //oil pump
    static function partsoilpump()
    {
        $oilpump=MasterPartOilPumpDetails::get();


        return $oilpump;
    }


    //air compressor
    static function partaircompressor()
    {
        $aircompressor=MasterPartAirCompressorDetails::get();


        return $aircompressor;
    }
    //water pump
    static function partwaterpump()
    {
        $waterpump=MasterPartWaterPumpDetails::get();


        return $waterpump;
    }
    //Con Rod After Bush Replacement
    static function conrodbushreplacemnt()
    {
        $conrodbush=MasterConRodBushReplacementDetails::get();


        return $conrodbush;
    }


    static function childsectionchecksheet($child)
    {
        $childsection=ChecksheetChildSection::where('section_id','=',$child)->get();

        //dd($childsection);
        return $childsection;
    }
    static function subChildsectionchecksheet($subchild)
    {
        $subchildsection=ChecksheetSubChildSection::where('child_id','=',$subchild)->get();
        //echo '<pre>';print_r($subchildsection);exit;
        //dd($childsection);
        return $subchildsection;
    }

    static function subchildpopulate ()
    {
        $subchildsecnew=ChecksheetSubChildSection::where('child_id','=',1)
            //->where('child_id','=',3)
            ->get();
        //echo '<pre>';print_r($subchilddemo);exit;
        //dd($childsection);
        return $subchildsecnew;
    }


    static function columnforchecksheet($chkshtcolumn)
    {
        $colfrchksht=ChecksheetSectionWiseColumn::where('section_id','=',$chkshtcolumn)->get()->toArray();

        /*$columnId = explode(',', $colfrchksht->section_id);

        $i=0;
        foreach($columnId as $columnIdArr){
            $section=ChecksheetColumn::find($columnIdArr);
            $column[$i]['column_id']=$section->id;
            $column[$i]['column_name']=$section->columns;

            $i++;
        }
        return $column;*/
        //$sectionId = explode(',', $colfrchksht->section_id);

       // $i=0;
        $j=0;
        //foreach($sectionId as $sectionIdArr){
            $section=ChecksheetSectionWiseColumn::find($colfrchksht);

           // echo '<pre>';print_r($section);exit;
            $columnId = explode(',', $section[0]['column_id']);

            if(isset($section)) {

                foreach ($columnId as $columnIdArr) {

                    $columnfind = ChecksheetColumn::find($columnIdArr);
                    $columnsection[$j]['column_id'] = $columnfind['id'];
                    $columnsection[$j]['column_name'] = $columnfind['columns'];
                    $j++;
                }
                //echo '<pre>';print_r($columnsection);exit;
            }
            //$i++;
       // }


        //echo "<pre>";print_r($section); exit;
        return $columnsection;



    }
    static function sectionname($secti){

        $sec=MasterCheckSheetSection::select('gw_master_checksheet_section.name as secname')
            ->leftjoin('model_wise_checksheet', 'model_wise_checksheet.section_id', '=', 'gw_master_checksheet_section.id')
//->where('model_wise_checksheet.section_id','=',$secti)
            ->get()->toArray();
        //dd($sec);
        return $sec;
    }
    static function deptName($dtname){
        $dept=MasterDepartment::select('gw_master_department.name as deptname')


            ->get();
        //dd($sec);
        return $dept;
    }
    static function dynamicchkshtdemo($model_id)
    {
        $compdet=[];
        $dychdemo = ModelWiseCheecksheet::where('model_id','=',$model_id)
            //->where('dept_id','=',$dept_id)

            ->get()->first();
            
            // echo '<pre>';print_r($dychdemo);exit;

        $sectionId = explode(',', $dychdemo->section_id);

        $i=0;
        foreach($sectionId as $sectionIdArr){
            $section=MasterCheckSheetSection::find($sectionIdArr);
            $compdet[$i]['section_id']=$section->id;
            $compdet[$i]['section_name']=$section->name;
            // $compdet[$i]=$section->name;
            $i++;
        }
        return $compdet;
    }
    static function assemblychecksheet()
    {
        $engineassembly=EngineAssembly::get();
        return $engineassembly;
    }
    static function dynamicchildsec($model_id)
    {

        $childsec=[];
        $dychild = ModelWiseCheecksheet::where('model_id','=',$model_id)
           // ->where('dept_id','=',$dept_id)

            ->get()->first();
        if(!empty($dychild->child_id)){
            $sectionId = explode(',', $dychild->child_id);

            $i=0;

            foreach($sectionId as $sectionIdArr){

                $section=ChecksheetChildSection::find($sectionIdArr);
                //echo "<pre>";print_r($section);exit;
                $childsec[$i]['child_id']=$section->id;
                $childsec[$i]['child_section']=$section->child_section;
                // $compdet[$i]=$section->name;
                $i++;
            }
        }
        return $childsec;
    }
    static function subchilddynamicsec($model_id)
    {

        $subchildsec=[];
        $dychild = ModelWiseCheecksheet::where('model_id','=',$model_id)
            // ->where('dept_id','=',$dept_id)

            ->get()->first();
        if(!empty($dychild->subsection_id)){
            $sectionId = explode(',', $dychild->subsection_id);

            $i=0;
            //echo '<pre>';print_r($sectionId);exit;
            foreach($sectionId as $sectionIdArr){

                $section=ChecksheetSubChildSection::find($sectionIdArr);
                //echo "<pre>";print_r($section);exit;
                $subchildsec[$i]['subsection_id']=$section['id'];
                $subchildsec[$i]['subchild_section']=$section['sub_child_section'];
                // $compdet[$i]=$section->name;
                $i++;
            }

        }
        return $subchildsec;
    }


    /* static function dynamiccolumns($dept_id,$model_id){

        $columnsection=[];


        $columndychk= ModelWiseCheecksheet::where('dept_id','=',$dept_id)
            ->where('model_id','=',$model_id)
            ->get()->first();

        $sectionId = explode(',', $columndychk->section_id);

        $i=0;
        foreach($sectionId as $sectionIdArr){
            $section=ChecksheetColumn::find($sectionIdArr);

            $columnsection[$i]['column_id']=$section->id;
           // $colum = explode(',', $section->columns);

            $columnsection[$i]['column_name']=$section->columns;
            //echo "<pre>";print_r($columnsection);exit;
            // $compdet[$i]=$section->name;
            $i++;
        }
        return $columnsection;
    }*/

    static function columndynamic($model_id,$section_id)
    {
        //$columnsection=[];
       /*$columndychk = ModelWiseCheecksheet::where('model_id','=',$model_id)
            //->where('dept_id','=',$dept_id)
            ->get()->first();
        //echo "<pre>";print_r($columndychk); exit;

        $sectionId = explode(',', $columndychk->section_id);*/

        $columnId=[];
      //foreach($sectionId as $sectionIdArr){
            $section=ChecksheetSectionWiseColumn::where('section_id','=',$section_id)
               ->where('model_id','=',$model_id)
                ->get()->toArray();
         //echo "<pre>";print_r($section);
            if(!empty($section)){
                $j =0;

                $columnId = explode(',', $section[0]['column_id']);
                //echo "<pre>";print_r($columnId);



           if(!empty($columnId)) {
               $columnsection=[];
               //$j=0;
                foreach ($columnId as $columnIdArr) {
                    //echo $j;
                   // echo "<pre>";print_r($columnIdArr);
                    $columnfind = ChecksheetColumn::find($columnIdArr);


                    $columnsection[$j]['column_id'] = $columnfind['id'];

                    $columnsection[$j]['column_name'] = $columnfind['columns'];

                    $j++;
                   //echo "<pre>"; print_r($columnsection);exit;
                }
//                exit;
                //echo "<pre>";print_r($columnsection);
            }

        }
            //$i++;
       // }
           // echo "<pre>";print_r($columnsection); exit;

//exit;
        //echo "<pre>";print_r($columnsection); exit;

        return $columnsection;
       //echo "<pre>";print_r($columnsection); exit;
   }


    // PROJECT PLAN

    // Get Department Name
    static function getDeptName($dept_id)
    {
        $dept_name = MasterDepartment::where('id','=',$dept_id)
            ->get()->toArray();
        return $dept_name;
    }

    // Get Department Wise Employee
    static function getDeptEmp($dept_id)
    {
        $emp_det = MasterEmployee::where('dept_id','=',$dept_id)
            ->get()->toArray();
        return $emp_det;
    }

    // Get Department Wise Tasks
    static function getDeptTask($dept_id)
    {
        $task_det = MasterTask::where('dept_id','=',$dept_id)
            ->get()->toArray();
        return $task_det;
    }

    // Get Employee Details

    static function checkParentTask($id){
        $child_task=MasterTask::where('parent','=',$id)
            ->get()->toArray();
        return $child_task;
    }

    // Task User Details
    static function taskUserDet($id,$prj_id){
        $task_det=TaskUser::where('task','=',$id)
            ->where('prj_id','=',$prj_id)
            ->get()->toArray();
        // echo "<pre>";print_r($task_det);exit;
        return $task_det;
    }
    // Task User Details
    static function empDetails($codes){
        $c=0;
        $emp_det=[];
        if(!empty($codes)){
            $codess = explode(',', $codes);
            foreach ($codess as $key => $code) {
                $emp_det[$c]=MasterEmployee::where('emp_code','=',$code)
                    ->get()->toArray()[0];
                $c++;
            }
            return $emp_det;
        }

    }
    
     static function countService(){
        $serviceCount=Service::all()->toArray();
        return $serviceCount;
    }
    
    static function totalservicecount(){
        $serCount=Service::select('service_request.id')->get()->count();
        return $serCount;
    }
     static function totalquotationcount(){
        $serquotation=Service::select('service_request.id')->where('service_request.quotation','!=','NULL')->get()->count();
        return $serquotation;
    }
    static function ongoingservice(){
        $onservice=Service::select('service_request.id')->where('service_request.status','!=','Closed')->get()->count();
        return $onservice;
    }

}



